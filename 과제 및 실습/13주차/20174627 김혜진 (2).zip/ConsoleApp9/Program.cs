﻿using System;
using System.Linq;
namespace ConsoleApp9
{
    //20174627 김혜진
    class Program
    {
 
        /*
        delegate int Calculate(int a, int b);
        static void Main(string[] args)
        {
            Calculate calc = (a, b) => a + b;
            Console.WriteLine("{0} + {1} : {2}", 3, 4, calc(3, 4));
        }
        */

        /*
        delegate void DoSomething();
        static void Main(string[] args)
        {
            DoSomething Dolt = () =>
            {
                Console.WriteLine("뭔가를");
                Console.WriteLine("출력해보자.");
                Console.WriteLine("이렇게!");
            };
            Dolt();
           
        }
        */

        /*
        delegate string Concatenate(string[] args);

        static void Main(string[] args)
        {
            Concatenate concat = (arr) =>
            {
                string result = "";
                foreach (string s in arr)
                    result += s;

                return result;
            };

            Console.WriteLine(concat(args));
        }
        */

        /*
        static void Main(string[] args)
        {
            Func<int> func1 = () => 10;
            Console.WriteLine("func1(): {0}", func1());

            Func<int, int> func2 = (x) => x * 2;
            Console.WriteLine("func2(4): {0}", func2(4));

            Func<double, double, double> func3 = (x, y) => x / y;
            Console.WriteLine("func3(22/7): {0}", func3(22, 7));
        }
        */

        /*
        static void Main(string[] args)
        {
            int[] array = { 11, 22, 33, 44, 55 };
            
                
                foreach (int a in array)
                {
                    Action action = () => Console.WriteLine(a * a);
                action.Invoke();
            } 
        }
        */

        
        static void Main(string[] args) 
        {
            int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };



            var result = from n in numbers
                         where n % 2 == 0
                         orderby n
                         select n;

            foreach (int n in result)
                Console.WriteLine("짝수 : {0}", n);


        }
        

    }
}
