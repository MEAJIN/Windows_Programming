﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;

// 20174627 김혜진
namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            /* 1번 예제
            SolidBrush b = new SolidBrush(Color.Lime);
            g.FillRectangle(b, ClientRectangle);
            b.Dispose();
            */

            /* 2번 예제
            Image img = new Bitmap("icons8-south-korea-96.jpg");      // 이미지 객체 생성
            TextureBrush b = new TextureBrush(img); // 이미지로 된 브러시 객체 생성
            g.FillRectangle(b, ClientRectangle);    // 사용자 영역을 이미지로 채움
            img.Dispose();                              // 이미지 객체를 해제
            b.Dispose();
            */

            /* 3번 예제
            LinearGradientBrush b = new LinearGradientBrush(
                                        new Point(0, 0), new Point(40, 30),
                                Color.Blue, Color.Red);
            g.FillRectangle(b, ClientRectangle);
            b.Dispose();
            */

            /* 4번 예제
            Point[] pts = {
                new Point(ClientRectangle.Width/2, 0),
                new Point(0, ClientRectangle.Height),
                new Point(ClientRectangle.Width, ClientRectangle.Height)
            };
            PathGradientBrush b = new PathGradientBrush(pts);
            g.FillRectangle(b, ClientRectangle);
            b.Dispose();
            */

            /* 5번 예제
            Pen p = new Pen(Color.Black);
            Point startPoint = new Point(45, 45);
            Point endPoint = new Point(180, 150);
            g.DrawLine(p, startPoint, endPoint);
            g.DrawLine(p, new Point(190, 60), new Point(65, 170));
            p.Dispose();
            */

            /* 6번 예제
            Point[] pts = {
                new Point(40, 40),   new Point(180, 40),
                new Point(180, 180), new Point(40, 180),
                new Point(40, 60),   new Point(160, 60),
                new Point(160, 160), new Point(60, 160),
                new Point(60, 80), new Point(140, 80),
                new Point(140, 140), new Point(80, 140),
                new Point(80, 100), new Point(120, 100),
                new Point(120, 120), new Point(100, 120)
            };
            g.DrawLines(new Pen(Color.BlueViolet), pts);
            */

            /* 7번 예제
            Rectangle r = new Rectangle(50, 50, 150, 100);
            g.FillRectangle(Brushes.Lime, r);
            g.DrawRectangle(new Pen(Color.Black), r);
            */

            /* 8번 예제
            Rectangle[] rects = {
                new Rectangle(40, 40, 40, 100),
                new Rectangle(100, 40, 100, 40),
                new Rectangle(100, 100, 100, 40)
            };
            g.FillRectangles(Brushes.Blue, rects);
            g.DrawRectangles(Pens.Red, rects);
            */

            /* 9번 예제
            Rectangle r = new Rectangle(50, 50, 150, 100);
            g.FillEllipse(Brushes.Cyan, r);
            g.DrawEllipse(Pens.Black, r);
            */

            /*10번 예제
            Rectangle r = new Rectangle(50, 50, 150, 100);
            g.DrawArc(Pens.Red, r, 45, 270);
            */

            /* 11번 예제
            Rectangle r = new Rectangle(50, 50, 150, 100);
            g.FillPie(Brushes.LightGreen, r, 45, 270);
            g.DrawPie(Pens.DarkGreen, r, 45, 270);
            */

            /* 12번 예제
            Point[] pts = {
                new Point(110, 40),  new Point(125, 91),
                new Point(180, 91), new Point(135, 123),
                new Point(152, 172), new Point(110, 141),
                new Point(66, 172),  new Point(82, 122),
                new Point(40, 91), new Point(95, 91)
            };
            g.FillPolygon(Brushes.Pink, pts);
            g.DrawPolygon(Pens.Purple, pts);
            */

            /* 13번 예제
            Point[] pts = {
                new Point(40, 100),  new Point(50, 60),
                new Point(60, 50), new Point(70, 60),
                new Point(80, 100),  new Point(90, 140),
                new Point(100, 150), new Point(110, 140),
                new Point(120, 100), new Point(130, 60),
                new Point(140, 50),  new Point(150, 60),
                new Point(160, 100), new Point(170, 140),
                new Point(180, 150), new Point(190, 140),
                new Point(200, 100)
            };
            g.DrawCurve(Pens.Red, pts);
            */

            /* 14번 예제
            Point[] pts = {
                new Point(115, 30), new Point(140, 90),
                new Point(200, 115), new Point(140, 140),
                new Point(115, 200), new Point(90, 140),
                new Point(30, 115),  new Point(90, 90)
            };
            g.FillClosedCurve(Brushes.Yellow, pts);
            g.DrawClosedCurve(Pens.Red, pts);
            */

            /* 15번 예제
            g.DrawBezier(Pens.Magenta,
                new Point(100, 50),         // start point
                new Point(0, 100),          // control point one
                new Point(200, 100),       // control point two
                new Point(100, 150));      // end point
            */

            /* 16번 예제
            Point[] pts = {
                new Point(30, 30),                        // 시작점
                new Point(60, 30), new Point(30, 60),     // 제어점
                new Point(60, 60),                        // 끝점 및 시작점
                new Point(90, 60), new Point(60, 90),     // 제어점
                new Point(90, 90),                        // 끝점 및 시작점
                new Point(120, 90), new Point(90, 120),   // 제어점
                new Point(120, 120),                      // 끝점 및 시작점
                new Point(150, 120), new Point(120, 150), // 제어점
                new Point(150, 150),                      // 끝점
            };
            g.DrawBeziers(Pens.DeepPink, pts);
            */

            /* 17번 예제 1
            Font f = new Font("Tahoma", 15);
            g.DrawString("Hello World!", f, Brushes.Black, 10, 10);
            f.Dispose();
            */

            /* 17번 예제 2
            string s = "This string is long enough to wrap.";
            s += " With a 250px-width rectangle, ";
            s += "it requires six lines to display the string in its entirety.";
            Font f = new Font("Tahoma", 15);
            Rectangle r = new Rectangle(10, 10, 250, 150);
            g.DrawRectangle(Pens.Black, r);
            g.DrawString(s, f, Brushes.Black, r);
            f.Dispose();
            */

            /* 18번 예제
            string s = "This is a long string that will wrap. ";
            s += "It will be centered both vertically and horizontally.";
            Font f = new Font("Tahoma", 15);
            StringFormat sf = new StringFormat();
            sf.Alignment = StringAlignment.Center;        // 수평 정렬
            sf.LineAlignment = StringAlignment.Center;    // 수직 정렬
            g.DrawString(s, f, Brushes.Black, ClientRectangle, sf);
            f.Dispose();
            */

            /* 19번 예제
            string s = "Hello World!";
            Font f = new Font("Tahoma", 15);
            SizeF sf = g.MeasureString(s, f);
            g.DrawString(s, f, Brushes.Black, 50, 50);
            g.DrawRectangle(Pens.Black, 50, 50, sf.Width, sf.Height);
            f.Dispose();
            */

            /* 20번 예제
            string s = "This string is long enough to wrap. ";  // 출력할 문자열
            s += "We'll use a 15pt font, and assume ";
            s += "the text string must fit into a width of 250 pixels. ";
            Font f = new Font("Tahoma", 15);       // 서체는 타호마, 글자 크기는 15.
            SizeF sf = g.MeasureString(s, f, 250); // 영역의 크기를 측정한다.
            RectangleF rf = new RectangleF(20, 20, sf.Width, sf.Height);
            Rectangle r = Rectangle.Ceiling(rf);   // 올림으로 변환
            g.DrawString(s, f, Brushes.Black, r);  // 문자열을 출력한다.
            g.DrawRectangle(Pens.Black, r);        // 외곽선을 그린다.
            f.Dispose();
            */

            /* 21번 예제 1
            Image img = new Bitmap("icons8-south-korea-96.jpg");
            g.DrawImage(img, 0, 0);  // g.DrawImage(img, new Point(0, 0));
            */

            /* 21번 예제 2
            Image img = new Bitmap("icons8-south-korea-96.jpg");
            g.DrawImage(img, ClientRectangle);
            */

            /* 22번 예제 1
            Image img = new Bitmap("icons8-south-korea-96.jpg");
            Point[] pts = {
                new Point(0, 0),    // 원본의 왼쪽 상단 모서리의 대상 위치
                new Point(200, 0),  // 원본의 오른쪽 상단 모서리의 대상 위치
                new Point(50, 100)  // 원본의 왼쪽 하단 모서리의 대상 위치
            };
            g.DrawImage(img, pts);
            */

            /* 22번 예제 2
            Image img = new Bitmap("icons8-south-korea-96.jpg");
            Point[] pts = {
                new Point(0, 100), new Point(200, 100), new Point(0, 0)

            };
            g.DrawImage(img, pts);
            */

            /* 22번 예제 3
            Image img = new Bitmap("icons8-south-korea-96.jpg");
            Point[] pts = {
                new Point(100, 0), new Point(100, 200), new Point(0, 0)
            };
            g.DrawImage(img, pts);
            */

            Image img = new Bitmap("icons8-south-korea-96.jpg");
            Rectangle sr = new Rectangle(0, 0, 80, 30);    // 원본의 부분적인 크기
            Rectangle dr = new Rectangle(0, 0, 200, 100);  // 그려질 영역 크기
            g.DrawImage(img, dr, sr, GraphicsUnit.Pixel);

        }

    }
}
