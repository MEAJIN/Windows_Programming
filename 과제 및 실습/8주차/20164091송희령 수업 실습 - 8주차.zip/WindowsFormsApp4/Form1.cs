﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        String txt;
        double savedValue;
        bool onFlag;
        char op;
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e) //텍스트박스
        {
            
        }

        private void button10_Click(object sender, EventArgs e) //0
        {
            textBox1.Text += "0";
        }

        private void button16_Click(object sender, EventArgs e) //AC
        {
            textBox1.Text = "";
            textBox2.Text = "";
            savedValue = 0;
        }

        private void button1_Click(object sender, EventArgs e) //1
        {
            if (onFlag)
            {
                textBox1.Text = "1";
                onFlag = false;
            }
            else
            {
                textBox1.Text += "1";
            }
        }

        private void button2_Click(object sender, EventArgs e) //2
        {
            if (onFlag)
            {
                textBox1.Text = "2";
                onFlag = false;
            }
            else
            {
                textBox1.Text += "2";
            }
        }

        private void button3_Click(object sender, EventArgs e) //3
        {
            if (onFlag)
            {
                textBox1.Text = "3";
                onFlag = false;
            }
            else
            {
                textBox1.Text += "3";
            }
        }

        private void button4_Click(object sender, EventArgs e) //4
        {
            if (onFlag)
            {
                textBox1.Text = "4";
                onFlag = false;
            }
            else
            {
                textBox1.Text += "4";
            }
        }

        private void button5_Click(object sender, EventArgs e) //5
        {
            if (onFlag)
            {
                textBox1.Text = "5";
                onFlag = false;
            }
            else
            {
                textBox1.Text += "5";
            }
        }

        private void button6_Click(object sender, EventArgs e) //6
        {
            if (onFlag)
            {
                textBox1.Text = "6";
                onFlag = false;
            }
            else
            {
                textBox1.Text += "6";
            }
        }

        private void button7_Click(object sender, EventArgs e) //7
        {
            if (onFlag)
            {
                textBox1.Text = "7";
                onFlag = false;
            }
            else
            {
                textBox1.Text += "7";
            }
        }

        private void button8_Click(object sender, EventArgs e) //8
        {
            if (onFlag)
            {
                textBox1.Text = "8";
                onFlag = false;
            }
            else
            {
                textBox1.Text += "8";
            }
        }

        private void button9_Click(object sender, EventArgs e) //9
        {
            if (onFlag)
            {
                textBox1.Text = "9";
                onFlag = false;
            }
            else
            {
                textBox1.Text += "9";
            }
        }

        private void button11_Click(object sender, EventArgs e) //=
        {
            onFlag = true;
            textBox2.Text += textBox1.Text;
            switch (op)
            {
                case '+':
                    textBox1.Text = (savedValue + double.Parse(textBox1.Text)).ToString();
                    break;
                case '-':
                    textBox1.Text = (savedValue + double.Parse(textBox1.Text)).ToString();
                    break;
                case 'X':
                    textBox1.Text = (savedValue * double.Parse(textBox1.Text)).ToString();
                    break;
                case '/':
                    textBox1.Text = (savedValue / double.Parse(textBox1.Text)).ToString();
                    break;
            }
        }
        bool onflag2;
        private void button15_Click(object sender, EventArgs e) //더하기
        {
            savedValue += double.Parse(textBox1.Text);
            op = '+';
            onFlag = true;
            textBox2.Text += textBox1.Text + " + ";
        }

        private void button14_Click(object sender, EventArgs e)  //빼기
        {
            savedValue = double.Parse(textBox1.Text);
            op = '-';
            onFlag = true;
            textBox2.Text += textBox1.Text + " - ";
        }

        private void button13_Click(object sender, EventArgs e) //곱하기
        {
            savedValue = double.Parse(textBox1.Text);
            op = 'X';
            onFlag = true;
            textBox2.Text += textBox1.Text + " X ";
        }

        private void button12_Click(object sender, EventArgs e) // 나누기
        {
            savedValue = double.Parse(textBox1.Text);
            op = '/';
            onFlag = true;
            textBox2.Text += textBox1.Text + " / ";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button17_Click(object sender, EventArgs e) //백스페이스
        {
            String tmp = textBox1.Text;
            if (tmp.Length != 0)
            {
                if (tmp[tmp.Length - 1].Equals(' '))
                    tmp = tmp.Remove(tmp.Length - 2);
                tmp = tmp.Remove(tmp.Length - 1);
            }
            textBox1.Text = tmp;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button18_Click(object sender, EventArgs e) //소수점
        {
            textBox1.Text += ".";
        }

        private void button19_Click(object sender, EventArgs e) //플마
        {
            textBox1.Text += "-";
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button20_Click(object sender, EventArgs e)
        {
            textBox5.Text = "Name : " + textBox3.Text + "\r\n" + "password : " + textBox4.Text;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button21_Click(object sender, EventArgs e)
        {
            if(textBox6.Text != "")
            {
                listBox2.Items.Add(textBox6.Text);
                textBox6.Text = "";
            }
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button22_Click(object sender, EventArgs e)
        {
            if (listBox2.SelectedIndex > -1)
                listBox2.Items.RemoveAt(listBox2.SelectedIndex);
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button24_Click(object sender, EventArgs e)
        {
            if (listBox3.SelectedItem != null)
            {
                comboBox1.Items.Add(listBox3.SelectedItem);
                listBox3.Items.Remove(listBox3.SelectedItem);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void button23_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem != null)
            {
                listBox3.Items.Add(comboBox1.SelectedItem);
                comboBox1.Items.Remove(comboBox1.SelectedItem);
            }
        }

        private void button25_Click(object sender, EventArgs e)
        {
            string strTmp = "";
            foreach(object obj in checkedListBox1.CheckedItems)
            {
                strTmp += obj.ToString();
                strTmp += " ";
            }
            MessageBox.Show("당신의 취미는 " + strTmp + "입니다.");
        }

        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
