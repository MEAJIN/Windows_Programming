﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
           /* if (listBox1.SelectedIndex > -1)
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);*/

            if(comboBox1.SelectedItem != null)
            {
                listBox1.Items.Add(comboBox1.SelectedItem);
                comboBox1.Items.Remove(comboBox1.SelectedItem);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /* if (textBox1.Text != "")
             {
                 listBox1.Items.Add(textBox1.Text);
                 textBox1.Text = "";
             }*/
            if (listBox1.SelectedItem != null)
            {
                comboBox1.Items.Add(listBox1.SelectedItem);
                listBox1.Items.Remove(listBox1.SelectedItem); 
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string strTemp = "";
            foreach (object obj in checkedListBox1.CheckedItems)
            {
                strTemp += obj.ToString();
                strTemp += "";
            }
            MessageBox.Show("당신의 취미는 " + strTemp + "입니다.");
            
        }
    }
}
