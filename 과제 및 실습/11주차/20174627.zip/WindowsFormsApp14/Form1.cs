﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp14
{
    //20174627 김혜진
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
                // 리스트 뷰의 항목을 큰 아이콘 형태로 보여준다. 
                listView1.View = View.LargeIcon;

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
                // 리스트 뷰의 항목을 작은 아이콘 형태로 보여준다. 
                listView1.View = View.SmallIcon;

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked)
                // 리스트 뷰의 항목을 간단한 리스트 형태로 보여준다. 
                listView1.View = View.List;

        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton4.Checked)
                // 리스트 뷰의 항목을 자세한 리스트 형태로 보여준다. 
                listView1.View = View.Details;

        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton5.Checked)
                // 리스트 뷰의 항목을 타일 형태로 보여준다. 
                listView1.View = View.Tile;

        }

        private void listView1_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem item in listView1.SelectedItems)
            {
                ListViewItem.ListViewSubItemCollection subItem = item.SubItems;
                // 각 항목에 대한 부항목을 얻기 위해 SubItems 프로퍼티를 사용 
                label1.Text = subItem[0].Text + "의 국가번호는 " + subItem[1].Text + "입니다.";
            }


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            treeView1.ExpandAll(); // 트리 뷰의 모든 노드를 펼침.

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && treeView1.SelectedNode != null) {
                // 선택된 노드가 있으면, 그 노드의 자식 노드로 추가한다.
                treeView1.SelectedNode.Nodes.Add(new TreeNode(textBox1.Text, 1, 1));
                textBox1.Text = "";
                textBox1.Focus();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            treeView1.Nodes.Remove(treeView1.SelectedNode);
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }
    }
}
