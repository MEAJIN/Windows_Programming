﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp16
    //20174627 김혜진
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(domainUpDown1.SelectedItem.ToString());
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            decimal d = numericUpDown1.Value;
            label1.Text = "Log" +d + " = ";
            textBox1.Text = System.Math.Log10((double)d).ToString();
            label2.Text = d + "*" +d + "=";
            textBox2.Text = System.Math.Pow((double)d,2).ToString();
            label3.Text = "√" + d + " = ";
            textBox3.Text =
            System.Math.Sqrt((double)d).ToString();
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (treeView1.SelectedNode != null) {
                textBox4.Text = treeView1.SelectedNode.Text;
                textBox5.Text = (treeView1.SelectedNode.Parent == null) ?
                    "" : treeView1.SelectedNode.Parent.Text;
                textBox6.Text = (treeView1.SelectedNode.PrevNode == null) ?
                    "" : treeView1.SelectedNode.PrevNode.Text;
                textBox7.Text = (treeView1.SelectedNode.NextNode == null) ?
                    "" : treeView1.SelectedNode.NextNode.Text;
                if (treeView1.SelectedNode.Nodes != null) {
                    listBox1.Items.Clear();
                    foreach (TreeNode node in treeView1.SelectedNode.Nodes)
                        listBox1.Items.Add(node.Text);
                }
            
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            numericUpDown2.Value = trackBar1.Value;
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            trackBar1.Value = (int)numericUpDown2.Value;
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            treeView1.ExpandAll();
        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = progressBar1.Minimum; i < progressBar1.Maximum; i++) 
            {
                progressBar1.Value = i;
            }

        }
        private int index = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            index %= imageList1.Images.Count;
            label1.Image = imageList1.Images[index++];
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }
    }
}
