﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp9
{
    //추상클래스
    abstract class Game                        
    {
        protected int userWin, computerWin, drawnMatch; //승, 무, 패
        
        //생성자
        public Game()                                       
        {
            userWin = computerWin = drawnMatch = 0;
        }

        //소멸자
        ~Game()                                             
        {
            recordPrint(); //승, 무, 패 출력
        }

        //추상 메소드 : 파생클래스에서 재정의 필수
        public abstract void result(); //결과 처리 메소드

        //승, 무, 패 출력 메소드
        public void recordPrint()                           
        {
            Console.WriteLine("당신은 컴퓨터와의 게임에서 " + userWin + "승 " + computerWin + "패 " + drawnMatch + "무승부 입니다.");
        }
    }
}
