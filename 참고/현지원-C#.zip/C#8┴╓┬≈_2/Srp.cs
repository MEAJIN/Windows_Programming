﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp9
{
    //Game 클래스로부터 상속받는 Srp 클래스
    class Srp : Game
    {
        protected const int MAX = 3;    //상수
        protected int user, computer;   //유저, 컴퓨터

        //게임 시작 메소드
        public void play()
        {
            do
            {
                if (input())
                {
                    com();
                    result();
                }
            } while (user != 0);
        }

        //사용자에게 입력받는 메소드
        public bool input()
        {
            Console.Write("입력하세요 [가위<1>, 바위<2>, 보<3>, 종료<0>]  : ");
            user = int.Parse(Console.ReadLine());

            //1,2,3 입력 : return true, 이외의 값 입력 : return false
            if (user == 1)            
                return true;
            else if (user == 2)
                return true;
            else if (user == 3)
                return true;

            return false;
        }

        //컴퓨터가 무엇을 낼지 결정하는 메소드
        public void com()
        {
            computer = new Random().Next(1, 4);
            comPrint();
        }

        // 컴퓨터가 무엇을 냈는지 출력하는 메소드
        public void comPrint()
        {
            if(computer == 1)
                Console.WriteLine("컴퓨터는 가위를 냈습니다.");
            else if (computer == 2)
                Console.WriteLine("컴퓨터는 바위를 냈습니다.");
            else
                Console.WriteLine("컴퓨터는 보를 냈습니다.");

        }

        //유저가 이겼는지, 졌는지, 비겼는지 판단하는 메소드
        public int judgment()
        {
            /* 
                * 무승부 : 0
                * 승 : 1
                * 패 : 2
            */
            int result = 0;
            int d = computer - user;
            if (computer == 1 && user == 3 || computer == 3 && user == 1)
                d = (-1) * d;

            if (checkDraw())
                result = 0;

            else if (d < 0)
                result = 1;

            else
                result = 2;

            return result;
        }

        // 유저와 컴퓨터가 비겼는지 확인하는 메소드
        public bool checkDraw()
        {
            if (computer == user)
                return true;
            return false;
        }

        public override void result()
        {
            if (judgment() == 0)
            {
                Console.WriteLine("비겼습니다.");
                drawnMatch++;
            }

            else if (judgment() == 1)
            {
                Console.WriteLine("이겼습니다.");
                userWin++;
            }
            else
            {
                Console.WriteLine("졌습니다.");
                computerWin++;
            }
        }
    }
}