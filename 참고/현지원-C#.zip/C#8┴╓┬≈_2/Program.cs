﻿using System;

namespace ConsoleApp9
{
    class Program
    {
        static public void game()
        {
            Console.Write("선택하세요 [가위바위보 게임<1>, 묵찌빠 게임<2>] : ");
            int i = Convert.ToInt32(Console.ReadLine());

            if (i == 1) new Srp().play(); //가위바위보 게임 시작
            else if (i == 2) new Mjb().play(); //묵찌빠 게임 시작
            else Console.WriteLine("잘못 입력하셨습니다.");
        }

        static void Main(string[] args)
        {
            game();
            GC.Collect();
        }
    }
}