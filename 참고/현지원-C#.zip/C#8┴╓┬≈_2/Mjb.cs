﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp9
{
    //Srp 클래스로부터 상속받는 Mjb 클래스
    class Mjb : Srp
    {
        private bool b = true;
        private int turn = 0, r = 0;
        //new 키워들르 사용하여 기존의 Srp에 있던 play() 메소드를 숨김
        public new void play()
        {
            do
            {
                while(b && turn == 0)
                {
                    //맨처음 사용자에게 입력 받기
                    b = input();
                    com();             

                    //가위바위보 결과 판정
                    /* 
                        * 무승부 : 0 반환
                        * 승 : 1 반환
                        * 패 : 2 반환
                    */
                    r = judgment();
                    if (r == 0)
                    {
                        Console.WriteLine("\n비겼습니다. 다시 입력 해주세요\n");
                        continue;
                    }

                    else
                    {                       
                        Console.WriteLine("\n묵찌빠 시작");
                        check_turn();
                        break;
                    }
                }

                b = input(); //사용자에게 입력 받기

                if (user == 0) //사용자가 0을 입력하면 종료
                {
                    Console.WriteLine();
                    break;
                }

                com(); //컴퓨터가 내기
                check_turn(); //순서 체크 

                //둘이 비겼으면
                if(r == 0)
                {
                    result(); //결과 판정
                    continue;
                }

            } while (b); //사용자가 0을 입력하면 종료
        }

        //차례 검사 함수
        public void check_turn()
        {
            r = judgment();
            if (r == 1)
            {
                Console.WriteLine("\n공격자는 유저 입니다.");
                turn = 1;
            }
            else if (r == 2)
            {
                Console.WriteLine("\n공격자는 컴퓨터 입니다.");
                turn = 2;
            }
        }

        //결과 출력 함수 : 재정의
        public override void result()
        {
            //사용자 차례였고 비겼을 경우 : 사용자 승
            if (turn == 1 && r == 0)
            {
                Console.WriteLine("이겼습니다.\n");
                userWin++;
            }
            //컴퓨터 차례였고 비겼을 경우 : 사용자 패 
            else if(turn == 2 && r == 0)
            {
                Console.WriteLine("졌습니다.\n");
                computerWin++;
            }
        }
    }
}