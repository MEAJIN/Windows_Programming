﻿using System;

//20174069 현지원
namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            string[,] info = new string[10, 10]; //도서를 저장하는 2차원 배열 선언
            string[] tmp_info;
            string input, search;
            int val, index = 0;
            bool check = true, check_search = false;

            for (int i = 0; i < 10; i++) {
                for (int j = 0; j < 10; j++) {
                    info[i, j] = "\n";
                }
            }

            //do-while문
            do
            {
                Console.WriteLine("\n************************************************************");
                Console.WriteLine("1 : 도서 추가, 2 : 도서 검색, 3 : 도서 리스트 출력, 0 : 종료");
                Console.WriteLine("************************************************************\n");

                //사용자로부터 동작을 입력 받는 문장
                val = Convert.ToInt32(Console.ReadLine());

                //switch를 통해 해당 메뉴로 넘어감
                switch (val)
                {
                    //프로그램 종료
                    case 0:
                        check = false; //사용자가 0을 입력하면 bool 변수 check를 false로 변경
                        break;
                    //도서 추가
                    case 1:
                        Console.WriteLine("입력할 도서(책이름, 저자)를 입력하시오 (최대 10개 입력 가능) : ex)무라카미 하루키, 상실의 시대");
                        input = Console.ReadLine();
                        for (int i = 0; i < 2; i++) {
                            tmp_info = input.Split(','); //split 메소드를 사용하여 ','기준으로 문장을 나눔
                            info[index, i] = tmp_info[i]; //나눈 문장을 info 배열에 저장
                        }
                        index++; //책이 추가될 때마다 인덱스를 증가 시킴
                        break;
                    
                    //도서 검색
                    case 2:
                        Console.WriteLine("찾고자 하는 도서의 이름이나 저자의 이름을 입력하시오");
                        search = Console.ReadLine();
                        //for-each문으로 찾고자하는 도서가 있는지 탐색
                        foreach (string v in info) {
                            if (v.Contains(search)) {
                                check_search = true;
                                break;
                            }
                        }

                        if (check_search == true)
                        {
                            Console.WriteLine("찾고자 하는 도서가 존재함");
                            break;
                        }

                        else
                        {
                            Console.WriteLine("찾고자 하는 도서가 존재하지 않음");
                            break;
                        }
                        break;
                    //전체 도서 목록 출력
                    case 3:
                        Console.WriteLine("==================== 전체 도서 목록 ====================");
                        for (int i = 0; i < index; i++) {
                            Console.WriteLine((i+1) + ". " + info[i, 0] + " " + info[i, 1]);
                        }
                        Console.WriteLine();
                        break;

                    default:
                        break;
                }
            } while (check != false); //check가 false로 되면 프로그램 종료
        }
    }
}