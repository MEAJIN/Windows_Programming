﻿//20174069 현지원
using System;

namespace ConsoleApp6
{
    //추상 클래스 Shape, 부모 클래스 
    abstract class Shape
    {
        protected double width, height, radius, a, b, c;

        public abstract double area(); //추상 메소드 area()
        public abstract double perimeter(); //추상 메소드 perimeter()
    }

    //부모 클래스 Shape를 상속받는 Triangle 클래스
    class Triangle : Shape
    {
        //너비, 길이가 1인 생성자
        public Triangle()
        {
            a = 1;
            b = 1;
            c = 1;
        }

        //너비, 길이를 매개변수로 받는 생성자
        public Triangle(double a, double b, double c)
        {
            this.a = a;
            this.b = b;
            this.c = c;
        }

        //추상 메소드 area() 메소드 override : 넓이 구하기
        public override double area()
        {
            double s = (a + b + c) / 2;
            return Math.Sqrt(s * (s - a) * (s - b) * (s - c));
        }

        //추상 메소드 perimeter 메소드 override : 둘레 구하기
        public override double perimeter()
        {
            return (a + b + c);
        }
    }

    //부모 클래스 Shape를 상속받는 Circle 클래스
    class Circle : Shape
    {
        //너비, 길이가 1인 생성자
        public Circle()
        {
            radius = 1;
        }

        //너비, 길이를 매개변수로 받는 생성자
        public Circle(double radius)
        {
            this.radius = radius;
        }

        //추상 메소드 area() 메소드 override : 넓이 구하기
        public override double area()
        {
            return Math.PI * radius * radius;
        }
        //추상 메소드 perimeter 메소드 override : 둘레 구하기
        public override double perimeter()
        {
            return Math.PI * 2 * radius;
        }
    }

    //부모 클래스 Shape를 상속받는 Rectangle 클래스
    class Rectangle : Shape
    {
        //너비, 길이가 1인 생성자
        public Rectangle()
        {
            width = 1;
            height = 1;
        }

        //너비, 길이를 매개변수로 받는 생성자
        public Rectangle(double width, double height)
        {
            this.width = width;
            this.height = height;
        }

        //추상 메소드 area() 메소드 override : 넓이 구하기
        public override double area()
        {
            return (width * height);
        }
        //추상 메소드 perimeter 메소드 override : 둘레 구하기
        public override double perimeter()
        {
            return ((width + height) * 2);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Shape rec = new Rectangle();
            Console.WriteLine("사각형 넓이 : " + rec.area() + ", 둘레 : " + rec.perimeter());
            Shape rect = new Rectangle(5, 7);
            Console.WriteLine("사각형 넓이 : " + rect.area() + ", 둘레 : " + rect.perimeter());

            Shape cir = new Circle();
            Console.WriteLine("원 넓이 : " + cir.area() + ", 둘레 : " + cir.perimeter());
            Shape circle = new Circle(5);
            Console.WriteLine("원 넓이 : " + circle.area() + ", 둘레 : " + circle.perimeter());

            Shape tri = new Triangle();
            Console.WriteLine("삼각형 넓이 : " + tri.area() + ", 둘레 : " + tri.perimeter());
            Shape triangle = new Triangle(1,1,1);
            Console.WriteLine("삼각형 넓이 : " + triangle.area() + ", 둘레 : " + triangle.perimeter());
        }
    }
}