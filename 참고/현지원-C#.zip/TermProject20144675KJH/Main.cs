﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

//20144675김재형
/*
 현재 이 폼은 모든 동작의 시작인 Main의 역할을 하고있습니다.
 사용자의 아이디정보를 받아 그 정보로 로그인하고 해당 폼을 띄우며,
 만약에 아이디정보가 없을 시 회원가입을 처리하는 폼으로 이동하는 역할을 합니다.*/
namespace TermProject20144675KJH
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void Main_Load(object sender, EventArgs e)
        {
            this.Text = "로그인";
        }

        //확인버튼을 누를 시 입력아이디와 비밀번호를 추출합니다.
        //그리고 그 내용이 파일시스템에 있을 경우,
        //해당폼(고용인, 피고용인, 관리자)로 이동합니다.
        //해당사항이 없을경우 "아이디와 비밀번호확인"문구를출력합니다.
        private void button1_Click(object sender, EventArgs e)
        {
            
            /*파일을받아 읽습니다*/
            StreamReader sr = new StreamReader("people.txt");
            while(sr.Peek()>=0)
            {
                if(sr.ReadLine() == ID.Text)
                {
                    sr.Close();

                    MessageBox.Show("로그인완료");
                    Employee em = new Employee(ID.Text);
                    em.ShowDialog();
                    break;
                }

            }
            sr.Close();
            

        }

        //회원가입을 누를 시 회원가입폼( 빈 피고용인 폼 )으로 이동합니다.
        private void button2_Click(object sender, EventArgs e)
        {
            Employee em = new Employee("Registration");
            em.ShowDialog();
        }
    }
}
