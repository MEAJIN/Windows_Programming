﻿namespace TermProject20144675KJH
{
    partial class WorkReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Year = new System.Windows.Forms.Label();
            this.Month = new System.Windows.Forms.Label();
            this.Days = new System.Windows.Forms.Label();
            this.Division = new System.Windows.Forms.Label();
            this.Position = new System.Windows.Forms.Label();
            this.Name = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.AttanceTime = new System.Windows.Forms.ComboBox();
            this.AttanceMinute = new System.Windows.Forms.ComboBox();
            this.LeaveMinute = new System.Windows.Forms.ComboBox();
            this.LeaveTime = new System.Windows.Forms.ComboBox();
            this.ReportInfo = new System.Windows.Forms.TextBox();
            this.Submit = new System.Windows.Forms.Button();
            this.Modify = new System.Windows.Forms.Button();
            this.Delete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 20F);
            this.label1.Location = new System.Drawing.Point(179, 42);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(475, 54);
            this.label1.TabIndex = 0;
            this.label1.Text = "Daily Work Report";
            // 
            // Year
            // 
            this.Year.AutoSize = true;
            this.Year.Font = new System.Drawing.Font("굴림", 15F);
            this.Year.Location = new System.Drawing.Point(146, 162);
            this.Year.Name = "Year";
            this.Year.Size = new System.Drawing.Size(101, 40);
            this.Year.TabIndex = 1;
            this.Year.Text = "Year";
            // 
            // Month
            // 
            this.Month.AutoSize = true;
            this.Month.Font = new System.Drawing.Font("굴림", 15F);
            this.Month.Location = new System.Drawing.Point(359, 162);
            this.Month.Name = "Month";
            this.Month.Size = new System.Drawing.Size(133, 40);
            this.Month.TabIndex = 2;
            this.Month.Text = "Month";
            // 
            // Days
            // 
            this.Days.AutoSize = true;
            this.Days.Font = new System.Drawing.Font("굴림", 15F);
            this.Days.Location = new System.Drawing.Point(594, 162);
            this.Days.Name = "Days";
            this.Days.Size = new System.Drawing.Size(110, 40);
            this.Days.TabIndex = 3;
            this.Days.Text = "Days";
            // 
            // Division
            // 
            this.Division.AutoSize = true;
            this.Division.Font = new System.Drawing.Font("Arial", 8.25F);
            this.Division.Location = new System.Drawing.Point(146, 259);
            this.Division.Name = "Division";
            this.Division.Size = new System.Drawing.Size(180, 25);
            this.Division.TabIndex = 4;
            this.Division.Text = "Attached Division";
            // 
            // Position
            // 
            this.Position.AutoSize = true;
            this.Position.Font = new System.Drawing.Font("Arial", 8.25F);
            this.Position.Location = new System.Drawing.Point(361, 259);
            this.Position.Name = "Position";
            this.Position.Size = new System.Drawing.Size(91, 25);
            this.Position.TabIndex = 5;
            this.Position.Text = "Position";
            // 
            // Name
            // 
            this.Name.AutoSize = true;
            this.Name.Font = new System.Drawing.Font("Arial", 8.25F);
            this.Name.Location = new System.Drawing.Point(529, 259);
            this.Name.Name = "Name";
            this.Name.Size = new System.Drawing.Size(70, 25);
            this.Name.TabIndex = 6;
            this.Name.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 8.25F);
            this.label2.Location = new System.Drawing.Point(148, 317);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(197, 25);
            this.label2.TabIndex = 7;
            this.label2.Text = "Attancedance Time";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 8.25F);
            this.label3.Location = new System.Drawing.Point(451, 317);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 25);
            this.label3.TabIndex = 8;
            this.label3.Text = "Leave Time";
            // 
            // AttanceTime
            // 
            this.AttanceTime.FormattingEnabled = true;
            this.AttanceTime.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24"});
            this.AttanceTime.Location = new System.Drawing.Point(150, 365);
            this.AttanceTime.Name = "AttanceTime";
            this.AttanceTime.Size = new System.Drawing.Size(121, 32);
            this.AttanceTime.TabIndex = 9;
            this.AttanceTime.Text = "Time";
            // 
            // AttanceMinute
            // 
            this.AttanceMinute.FormattingEnabled = true;
            this.AttanceMinute.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50",
            "51",
            "52",
            "53",
            "54",
            "55",
            "56",
            "57",
            "58",
            "59",
            "60"});
            this.AttanceMinute.Location = new System.Drawing.Point(277, 365);
            this.AttanceMinute.Name = "AttanceMinute";
            this.AttanceMinute.Size = new System.Drawing.Size(121, 32);
            this.AttanceMinute.TabIndex = 10;
            this.AttanceMinute.Text = "Minute";
            // 
            // LeaveMinute
            // 
            this.LeaveMinute.FormattingEnabled = true;
            this.LeaveMinute.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31",
            "32",
            "33",
            "34",
            "35",
            "36",
            "37",
            "38",
            "39",
            "40",
            "41",
            "42",
            "43",
            "44",
            "45",
            "46",
            "47",
            "48",
            "49",
            "50",
            "51",
            "52",
            "53",
            "54",
            "55",
            "56",
            "57",
            "58",
            "59",
            "60"});
            this.LeaveMinute.Location = new System.Drawing.Point(583, 365);
            this.LeaveMinute.Name = "LeaveMinute";
            this.LeaveMinute.Size = new System.Drawing.Size(121, 32);
            this.LeaveMinute.TabIndex = 12;
            this.LeaveMinute.Text = "Minute";
            // 
            // LeaveTime
            // 
            this.LeaveTime.FormattingEnabled = true;
            this.LeaveTime.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24"});
            this.LeaveTime.Location = new System.Drawing.Point(456, 365);
            this.LeaveTime.Name = "LeaveTime";
            this.LeaveTime.Size = new System.Drawing.Size(121, 32);
            this.LeaveTime.TabIndex = 11;
            this.LeaveTime.Text = "Time";
            // 
            // ReportInfo
            // 
            this.ReportInfo.Location = new System.Drawing.Point(153, 419);
            this.ReportInfo.Multiline = true;
            this.ReportInfo.Name = "ReportInfo";
            this.ReportInfo.Size = new System.Drawing.Size(551, 304);
            this.ReportInfo.TabIndex = 13;
            // 
            // Submit
            // 
            this.Submit.Location = new System.Drawing.Point(224, 745);
            this.Submit.Name = "Submit";
            this.Submit.Size = new System.Drawing.Size(102, 54);
            this.Submit.TabIndex = 14;
            this.Submit.Text = "Submit";
            this.Submit.UseVisualStyleBackColor = true;
            // 
            // Modify
            // 
            this.Modify.Location = new System.Drawing.Point(380, 745);
            this.Modify.Name = "Modify";
            this.Modify.Size = new System.Drawing.Size(102, 54);
            this.Modify.TabIndex = 15;
            this.Modify.Text = "Modify";
            this.Modify.UseVisualStyleBackColor = true;
            // 
            // Delete
            // 
            this.Delete.Location = new System.Drawing.Point(534, 745);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(102, 54);
            this.Delete.TabIndex = 16;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            // 
            // WorkReport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(865, 860);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.Modify);
            this.Controls.Add(this.Submit);
            this.Controls.Add(this.ReportInfo);
            this.Controls.Add(this.LeaveMinute);
            this.Controls.Add(this.LeaveTime);
            this.Controls.Add(this.AttanceMinute);
            this.Controls.Add(this.AttanceTime);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Name);
            this.Controls.Add(this.Position);
            this.Controls.Add(this.Division);
            this.Controls.Add(this.Days);
            this.Controls.Add(this.Month);
            this.Controls.Add(this.Year);
            this.Controls.Add(this.label1);
            this.Text = "WorkReport";
            this.Load += new System.EventHandler(this.WorkReport_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Year;
        private System.Windows.Forms.Label Month;
        private System.Windows.Forms.Label Days;
        private System.Windows.Forms.Label Division;
        private System.Windows.Forms.Label Position;
        private System.Windows.Forms.Label Name;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox AttanceTime;
        private System.Windows.Forms.ComboBox AttanceMinute;
        private System.Windows.Forms.ComboBox LeaveMinute;
        private System.Windows.Forms.ComboBox LeaveTime;
        private System.Windows.Forms.TextBox ReportInfo;
        private System.Windows.Forms.Button Submit;
        private System.Windows.Forms.Button Modify;
        private System.Windows.Forms.Button Delete;
    }
}