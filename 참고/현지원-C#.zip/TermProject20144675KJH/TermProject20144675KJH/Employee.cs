﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

//20144675김재형 
namespace TermProject20144675KJH
{

    public partial class Employee : Form
    {
        String Status;

        int start = 0;
        int startTwo = 0;

        //회원가입인지 아닌지를 판별합니다.
        public Employee(String St)
        {
            InitializeComponent();




            this.Size = new System.Drawing.Size(800, 700);

            this.Status = St;

            String[] Info;

            //회원가입이아니라 로그인이라면 ! 
            if (St != "Registration")
            {
                /*파일을받아 읽습니다*/
                StreamReader sr = new StreamReader("people.txt");
                while (sr.Peek() >= 0)
                {
                    if (sr.ReadLine() == St)
                    {
                        //권한을 추출합니다.
                        this.Authority.Text = sr.ReadLine();

                        //나머지 사용자 정보를 Split으로 쪼개어 추출합니다
                        Info = sr.ReadLine().Split('/');
                        sr.Close();

                        this.ID.Text = St;

                        //이름
                        String[] Name;
                        Name = Info[0].Split(',');
                        this.FirstName.Text = Name[0];
                        this.MiddleName.Text = Name[1];
                        this.LastName.Text = Name[2];
                        //출생지
                        this.BirthPlace.Text = Info[1];
                        //성별
                        if(Info[2].Equals("Male"))
                        {
                            this.CheckMale.Checked = true;
                        }
                        else if (Info[2].Equals("FeMale"))
                        {
                            this.CheckFeMale.Checked = true;
                        }
                        //
                        //Nationality
                        this.Nationality.Text = Info[3];
                        //Family
                        //[4].split(',')
                        //AcName, AcBank
                        this.ACName.Text = Info[5];
                        this.ACBank.Text = Info[6];

                        //SWFC ACNT 빠짐
                        this.SwiftCode.Text = Info[7];
                        this.Account.Text = Info[8];

                        //address
                        this.Address.Text = Info[9];
                        //State
                        this.State.Text = Info[10];
                        //City
                        this.City.Text = Info[11];
                        //Zip
                        this.ZipCode.Text = Info[12];
                        //Mail
                        this.PEmail.Text = Info[13];
                        this.WEmail.Text = Info[14];
                        //DIvision
                        this.Division.Text = Info[15];
                        //Department
                        this.DepartMent.Text = Info[16];
                        //Title
                        this.Title.Text = Info[17];
                        //Classification
                        this.Classification.Text = Info[18];
                        //Constract
                        this.ContractNo.Text = Info[19];
                        //EmployeeStatus
                        this.EmplyStatus.Text = Info[20];
                        //EmployeeWorkout
                        this.EmplyWorkout.Text = Info[21];

                        //PW
                        this.PASSWORD.Text = (String)Info[22];
                        //Birthday
                        this.BirthDate.Text = (String)Info[23];
                        //PassPort
                        this.Passport.Text = (String)Info[24];
                        //SSN
                        this.SSN.Text = (String)Info[25];
                        //DriverLisense
                        this.DriverLicense.Text = (String)Info[26];
                        //HomeNum
                        this.HPnum.Text = (String)Info[27];
                        //MobileNUm
                        this.MPnum.Text = (String)Info[28];
                        //Hired
                        this.HiredDate.Text = (String)Info[29];
                        this.ResignDate.Text = (String)Info[30];

                        //NickName
                        this.NickName.Text = Info[31];

                        
                        break;
                    }

                    
                }
                sr.Close();
            }

        }



        private void FirstName_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void Employee_Load(object sender, EventArgs e)
        {
            numericUpDown1.Value = DateTime.Today.Year;
            comboBox1.SelectedItem = DateTime.Today.Month.ToString();
            comboBox2.SelectedItem = DateTime.Today.Day.ToString();

        }

        private void date_Changed(object sender, System.EventArgs e)
        {
            Invalidate();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            

        }
            private void label16_Click(object sender, EventArgs e)
        {

        }

        private void NickName_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void LastName_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void MiddleName_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        //저장을 누를 시
        private void Save_Click(object sender, EventArgs e)
        {
            if(errorSearch()!=0)
            { 
                Person p1 = new Person();

                p1.Id = ID.Text;

                p1.Name = FirstName.Text + "," + MiddleName.Text + "," + LastName.Text;
                p1.BirthPlace = BirthPlace.Text;
                //p1.Gender =  Gender.Text;
                if (CheckMale.Checked == true)
                    p1.Gender = "Male";
                else if (CheckFeMale.Checked == true)
                    p1.Gender = "FeMale";
                p1.Nationality = Nationality.Text;
                //p1.Family = Spouse.Text;


                p1.AcName = ACName.Text;
                p1.AcBank = ACBank.Text;
                p1.SwiftCode = SwiftCode.Text;
                p1.Account = Account.Text;
                p1.Address = Address.Text;
                p1.State = State.Text;
                p1.City = City.Text;
                p1.ZipCode = ZipCode.Text;

                p1.Pemail = PEmail.Text;
                p1.Wemail = WEmail.Text;

                p1.Division = Division.Text;
                p1.Department = DepartMent.Text;

                p1.Title = Title.Text;
                p1.Classification = Classification.Text;
                p1.ConstractNo = ContractNo.Text;
                p1.EmplyStatus = EmplyStatus.Text;
                p1.EmplyWorkout = EmplyWorkout.Text;

                p1.Pw = Int32.Parse(PASSWORD.Text);
                p1.BirthDate = Int32.Parse(BirthDate.Text);
                p1.PassPort = Int32.Parse(Passport.Text);
                p1.SSN = Int32.Parse(SSN.Text);
                p1.DriverLisense = Int32.Parse(DriverLicense.Text);
                p1.HomeN = HPnum.Text;
                p1.MobileN = MPnum.Text;
                p1.HiredDate = Int32.Parse(HiredDate.Text);
                p1.ResignDate = Int32.Parse(ResignDate.Text);

                p1.NickName = NickName.Text;


    
                FileStream fs = new FileStream("people.txt", FileMode.Append, FileAccess.Write);
                //FileMode중 append는 이어쓰기. 파일이 없으면 만든다.
                StreamWriter sw = new StreamWriter(fs, System.Text.Encoding.UTF8);
            
                sw.WriteLine(ID.Text);
                sw.WriteLine(Authority.Text);
                sw.WriteLine(
                    p1.Name + "/" + p1.BirthPlace + "/" + p1.Gender + "/" +
                    p1.Nationality + "/" + p1.Family + "/" + p1.AcName + "/" +
                    p1.AcBank + "/" + p1.SwiftCode + "/" + p1.Account + "/" +
                    p1.Address + "/" + p1.State + "/" + p1.City + "/" +
                    p1.ZipCode + "/" + p1.Pemail + "/" + p1.Wemail + "/" +
                    p1.Division + "/" + p1.Department + "/" + p1.Title + "/" +
                    p1.Classification + "/" + p1.ConstractNo + "/" + p1.EmplyStatus + "/" +
                    p1.EmplyWorkout + "/" + p1.Pw + "/" + p1.BirthDate + "/" +
                    p1.PassPort + "/" + p1.SSN + "/" + p1.DriverLisense + "/" +
                    p1.HomeN + "/" + p1.MobileN + "/" + p1.HiredDate + "/" +
                    p1.ResignDate + "/" + p1.NickName);

                sw.Close();
                fs.Close();

                //마지막으로 Division에 업데이트해준다.
                StreamWriter temw = new StreamWriter("Temp.txt");
                StreamReader divir = new StreamReader("Division.txt");

                String[] str = new String[2];
                String s;
                while (divir.Peek()>=0)
                {
                    s = divir.ReadLine();
                    if (Division.Text.Equals(s)==false)
                    {
                        temw.WriteLine(s);
                    
                    }
                    else
                    {
                        str[0] = s;
                        s = divir.ReadLine();
                        str[1] = s + "," + ID.Text;
                    }
                }


                temw.Close();
                divir.Close();

                StreamWriter diviw = new StreamWriter("Division.txt");
                StreamReader tems = new StreamReader("Temp.txt");
                while(tems.Peek()>=0)
                {
                    diviw.WriteLine(tems.ReadLine());
                }
                diviw.WriteLine(str[0]);
                diviw.WriteLine(str[1]);

                diviw.Close();
                tems.Close();
            }
        }

        private void Apply_Click(object sender, EventArgs e)
        {
            if (errorSearch() != 0)
            {
                Person p1 = new Person();

                p1.Id = ID.Text;

                p1.Name = FirstName.Text + "," + MiddleName.Text + "," + LastName.Text;
                p1.BirthPlace = BirthPlace.Text;
                if (CheckMale.Checked == true)
                    p1.Gender = "Male";
                else if (CheckFeMale.Checked == true)
                    p1.Gender = "FeMale";
                p1.Nationality = Nationality.Text;
                //p1.Family = Spouse.Text;


                p1.AcName = ACName.Text;
                p1.AcBank = ACBank.Text;
                p1.SwiftCode = SwiftCode.Text;
                p1.Account = Account.Text;
                p1.Address = Address.Text;
                p1.State = State.Text;
                p1.City = City.Text;
                p1.ZipCode = ZipCode.Text;

                p1.Pemail = PEmail.Text;
                p1.Wemail = WEmail.Text;

                p1.Division = Division.Text;
                p1.Department = DepartMent.Text;

                p1.Title = Title.Text;
                p1.Classification = Classification.Text;
                p1.ConstractNo = ContractNo.Text;
                p1.EmplyStatus = EmplyStatus.Text;
                p1.EmplyWorkout = EmplyWorkout.Text;

                p1.Pw = Int32.Parse(PASSWORD.Text);
                p1.BirthDate = Int32.Parse(BirthDate.Text);
                p1.PassPort = Int32.Parse(Passport.Text);
                p1.SSN = Int32.Parse(SSN.Text);
                p1.DriverLisense = Int32.Parse(DriverLicense.Text);
                p1.HomeN = HPnum.Text;
                p1.MobileN = MPnum.Text;
                p1.HiredDate = Int32.Parse(HiredDate.Text);
                p1.ResignDate = Int32.Parse(ResignDate.Text);

                p1.NickName = NickName.Text;
            }
            
        }

        private void Remove_Click(object sender, EventArgs e)
        {

            /*파일을읽고 수정전 부분을 제외한 모든것을 TEMP 빈공간 파일에 넣고
             다마친후에, Person파일에 넣고, 수정후 내용을 추가하면
             수정의 완성*/
            StreamReader sr = new StreamReader("people.txt");
            //FileMode중 append는 이어쓰기. 파일이 없으면 만든다.
            StreamWriter sw = new StreamWriter("temp.txt");
            //수정할 ID( ID, 권한, 직원내용 ) 을 제외한 다른 ID들을 TEMP파일에 백업시켜줍니다.
            while (sr.Peek() >= 0)
            {
                String s = sr.ReadLine();
                if (ID.Text.Equals(s))
                {
                    sr.ReadLine();
                    sr.ReadLine();
                }
                else
                {
                    sw.WriteLine(s);
                }

            }

            sr.Close();
            sw.Close();

            StreamWriter target = new StreamWriter("people.txt");
            StreamReader thisInfo = new StreamReader("temp.txt");
            while(thisInfo.Peek()>=0)
            {
                target.WriteLine(thisInfo.ReadLine());
            }

            target.Close();
            thisInfo.Close();


            //마지막으로 Division에 업데이트해준다.
            StreamWriter temw = new StreamWriter("Temp.txt");
            StreamReader divir = new StreamReader("Division.txt");

            String[] str = new String[2];
            String smp;
            while (divir.Peek() >= 0)
            {
                smp = divir.ReadLine();
                if (Division.Text.Equals(smp) == false)
                {
                    temw.WriteLine(smp);

                }
                else
                {
                    str[0] = smp;
                    smp = divir.ReadLine();
                    str[1] = smp;
                }
            }

            String[] splitStr = str[1].Split(',');
            String FinalStr = "";

            FinalStr += splitStr[0];

            for(int i=1; i<splitStr.Length;i++)
            {
                if (i + 1 <= splitStr.Length)
                {
                    FinalStr += ",";
                }

                if (splitStr[i].Equals(ID.Text)==false)
                {
                    FinalStr += splitStr[i];
                }

                
            }
            
            temw.Close();
            divir.Close();

            StreamWriter diviw = new StreamWriter("Division.txt");
            StreamReader tems = new StreamReader("Temp.txt");
            while (tems.Peek() >= 0)
            {
                diviw.WriteLine(tems.ReadLine());
            }
            diviw.WriteLine(str[0]);
            diviw.WriteLine(FinalStr);

            diviw.Close();
            tems.Close();
        }


        //달력부분///////////////////////////////////////////////////////////////////////
        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {

            //달력에 근무표를 표시하기위한 파일입출력
            StreamReader sr = new StreamReader("Reports.txt");

            int FinalIndex = 31;
            //근무표가있는날짜를 추출하는 배열
            int[] existRepo= new int[FinalIndex];
            int existIndex = 0;
            String temp;

            while (sr.Peek()>=0)
            {
                if(sr.ReadLine().Equals(ID.Text))
                {
                    while( (sr.Peek()>=0) )
                    {
                        temp = sr.ReadLine();
                        if (temp == "Name")
                            break;

                        String[] selected = temp.Split(',');
                        existRepo[existIndex] = Int32.Parse(selected[2]);


                        existIndex++;
                        sr.ReadLine();
                    }
                    break;
                }
            }

            sr.Close();


            //정렬을 사용하기위한 리스트변환 후 컬렉션메소드사용
            List<int> exte = existRepo.ToList();
            exte.Sort();
            existRepo = exte.ToArray();




            //요일들의 이름을 갖고있는 문자열 배열이다.
            string[] daySign = { "일", "월", "화", "수", "목", "금", "토" };
            Graphics g = e.Graphics;


            

            int yearCnt, monthCnt, days = 1;

            //1년부터 선택한 년도까지의 일 수를 합합니다.(윤달구분)
            for (yearCnt = 1; yearCnt < (int)numericUpDown1.Value; yearCnt++)
            {
                if (DateTime.IsLeapYear(yearCnt))
                    days += 366;
                else days += 365;
            }
            
            //1월부터 선택한 월까지의 해당년도와 그년도의 1부터 선택한월까지의 일수를 합니다.
            for (monthCnt = 1; monthCnt < int.Parse(comboBox1.SelectedItem.ToString()); monthCnt++)
                days += DateTime.DaysInMonth(yearCnt, monthCnt);
            days %= 7;
            
            //요일의 표시
            for (int i = 0; i < 7; i++)
            {
                Font f = new Font("굴림", 10);
                if (i == 0)
                    g.DrawString(daySign[i], f, Brushes.Red, 15 + i * 40, 50);
                else if (i == 6)
                    g.DrawString(daySign[i], f, Brushes.Blue, 15 + i * 40, 50);
                else
                    g.DrawString(daySign[i], f, Brushes.Black, 15 + i * 40, 50);
            }


            int pointIndex=0;
            foreach(int a in existRepo)
            {
                pointIndex++;

                if (a != 0)
                    break;
            }

            
            int j = 0;
            int k = pointIndex-1;
            

            for (int i = 1; i <= DateTime.DaysInMonth((int)numericUpDown1.Value, int.Parse(comboBox1.SelectedItem.ToString())); i++)
            {
                Font f = new Font("굴림", 10); ;

                //사용자가 선택한 날짜를 하얀색으로 표시한다.
                //이부분을 활용하여 근무표가있는 날짜를 하얀색으로 표시하면 되겠다. 

                if (k < FinalIndex) { 
                    if ((i == existRepo[k]))
                    {
                        
                         f = new Font("굴림", 10, FontStyle.Bold);
                         g.FillRectangle(Brushes.Yellow, 15 + days * 40, 70 + j * 20, 20, 15);
                         k++;
                        
                    }
                }


                //일요일이면 빨강, 토요일이면 파랑, 나머지 평일은 검정색으로 한다.
                if (days == 0)
                    g.DrawString(i.ToString(), f, Brushes.Red, 15 + days * 40, 70 + j * 20);
                else if (days == 6)
                    g.DrawString(i.ToString(), f, Brushes.Blue, 15 + days * 40, 70 + j * 20);
                else
                    g.DrawString(i.ToString(), f, Brushes.Black, 15 + days * 40, 70 + j * 20);

                //만약 토요일이라면 이를 0으로 바꾸고 j를 추가함 아니면ㅁ j만 추가한다.
                if (days == 6)
                {
                    days = 0;
                    j++;
                }
                else days++;
            }

            
        }

        //수치가 변경될 시 달력판넬을 리프레쉬
        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            panel1.Refresh();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            panel1.Refresh();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            panel1.Refresh();
        }
        ////////////////////////////////////////////////////////////////////////////////

        //근무표를 띄웁니다.
        //근무표 폼은 현재 사용자가 선택한 날짜를 매개변수로갖습니다.
        private void WorkReport_Click(object sender, EventArgs e)
        {

            //사용자의선택을 텍스트형식에맞게 묶어줍니다.

            String year = numericUpDown1.Value.ToString();
            String month = comboBox1.SelectedItem.ToString();
            String daysi = comboBox2.SelectedItem.ToString();
            String sentence = year + "," + month + "," + daysi;



            //근무일지폼에 매개변수를보내야한다
            //1.만약 근무일지가 적힌 날짜면은 Reports.txt를 비교해 그 근무일지가 적힌 날짜와 근무기록들을 다 보낸다.
            //2.만약 근무일지가 적히지 않은 날짜면은 선택한 사용자가 선택한 날짜만을 보낸다.

            StreamReader sr = new StreamReader("Reports.txt");
            String temp="00/00/00/00/Information";
            
            while (sr.Peek() >= 0)
            {
                if (sr.ReadLine().Equals(ID.Text))
                {
                    while ((sr.Peek() >= 0))
                    {
                       if(sr.ReadLine().Equals(sentence))
                        {
                            //날짜가같은것이있다면 그 다음줄이 그 날짜에 해당되는 정보이다.
                            temp = sr.ReadLine();
                            break;
                        }
                    }
                    break;
                }
            }
            
            sr.Close();

            

            WorkReport wr = new WorkReport(ID.Text,sentence,temp);
            wr.ShowDialog();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void PEmail_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            
        }

        private void WEmail_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }


        int errorSearch()
        {
            String[] pm = PEmail.Text.Split('@');
            String[] wm = WEmail.Text.Split('@');
            if (pm.Length!=2 || wm.Length!=2)
            {
                MessageBox.Show("메일에 @가 포함되지않았습니다");
                return 0;
            }

            int HPn = HPnum.Text.Length; 
            int MPn = MPnum.Text.Length;

            
            if((HPn == 11 && MPn == 11) || (HPn == 11 && MPn == 12) || (HPn == 12 && MPn == 11) || (HPn == 12 && MPn == 12)   )
            {
                
            }
            else
            {
                LastName.Text = HPn.ToString();
                MessageBox.Show("전화번호가 11자리 혹은 12자리가 아닙니다");
                return 0;
            }


            if((CheckMale.Checked==true && CheckFeMale.Checked==true)|| (CheckMale.Checked == false && CheckFeMale.Checked ==false))
            {
                MessageBox.Show("성별을 하나 선택해주세요");
                return 0;
            }


            return 1;
        }

        private void BirthPlus_Click(object sender, EventArgs e)
        {
            //달력
            Calen cl = new Calen();
            cl.ShowDialog();

            StreamReader sr = new StreamReader("BirthDay.txt");
            this.BirthDate.Text=sr.ReadLine();
            sr.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Map mp = new Map();
            mp.ShowDialog();

            StreamReader sr = new StreamReader("Map.txt");
            this.Address.Text = sr.ReadLine();
            sr.Close();
        }

        private void SpousePlus_Click(object sender, EventArgs e)
        {
            if(start==0)
            { 
                OneSP.Visible = true;
            }
            else if(start==1)
            {
                TwoSP.Visible = true;
            }

            start++;
        }
        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            if (startTwo == 1)
            {
                maskedTextBox1.Visible = true;
            }
            else if (startTwo == 2)
            {
                maskedTextBox2.Visible = true;
            }
            else if (startTwo == 3)
            {
                maskedTextBox3.Visible = true;
            }
            startTwo++;

        }
    }



    class Person
    {
        public String Id;
        public int Pw;

        public String Name;

        public int BirthDate;
        public String BirthPlace;

        public String Gender;
        public String Nationality;
        public String NickName;

        //가족리스트
        public List<String> Family = new List<String>();

        public int PassPort, SSN, DriverLisense;
        public String AcName, AcBank, SwiftCode, Account;

        public String Address, State, City;
        public String ZipCode;

        public String HomeN, MobileN;

        public String Pemail, Wemail;

        public int HiredDate, ResignDate;

        public String Division, Department, Title, Classification, ConstractNo, EmplyStatus, EmplyWorkout;


    }
}
