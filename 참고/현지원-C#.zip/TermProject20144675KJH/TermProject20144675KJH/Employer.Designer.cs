﻿namespace TermProject20144675KJH
{
    partial class Employer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label49 = new System.Windows.Forms.Label();
            this.Authority = new System.Windows.Forms.MaskedTextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.PASSWORD = new System.Windows.Forms.MaskedTextBox();
            this.ID = new System.Windows.Forms.MaskedTextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.Account = new System.Windows.Forms.MaskedTextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.SwiftCode = new System.Windows.Forms.MaskedTextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.ACBank = new System.Windows.Forms.MaskedTextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.ACName = new System.Windows.Forms.MaskedTextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.DriverLicense = new System.Windows.Forms.MaskedTextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.SSN = new System.Windows.Forms.MaskedTextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.Passport = new System.Windows.Forms.MaskedTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.NickName = new System.Windows.Forms.MaskedTextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.LastName = new System.Windows.Forms.MaskedTextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.MiddleName = new System.Windows.Forms.MaskedTextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.FirstName = new System.Windows.Forms.MaskedTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label62 = new System.Windows.Forms.Label();
            this.Address = new System.Windows.Forms.MaskedTextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.State = new System.Windows.Forms.MaskedTextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.City = new System.Windows.Forms.MaskedTextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.ZipCode = new System.Windows.Forms.MaskedTextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.HPnum = new System.Windows.Forms.MaskedTextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.MPnum = new System.Windows.Forms.MaskedTextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.PEmail = new System.Windows.Forms.MaskedTextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.WEmail = new System.Windows.Forms.MaskedTextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.HiredDate = new System.Windows.Forms.MaskedTextBox();
            this.ResignDate = new System.Windows.Forms.MaskedTextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.Classification = new System.Windows.Forms.MaskedTextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.ContractNo = new System.Windows.Forms.MaskedTextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.EmplyStatus = new System.Windows.Forms.MaskedTextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.EmplyWorkout = new System.Windows.Forms.MaskedTextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.Title = new System.Windows.Forms.MaskedTextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.Division = new System.Windows.Forms.MaskedTextBox();
            this.DepartMent = new System.Windows.Forms.MaskedTextBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.WR = new System.Windows.Forms.Button();
            this.Apply = new System.Windows.Forms.Button();
            this.Remove = new System.Windows.Forms.Button();
            this.Save = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.Eval = new System.Windows.Forms.Button();
            this.DeptURL = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.DeptAddInfo = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.DeptEmail = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.DeptPhone = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.DeptName = new System.Windows.Forms.TextBox();
            this.label52 = new System.Windows.Forms.Label();
            this.DeptDiv = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.RegistrationNum = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.CompanyName = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.SelectDivision = new System.Windows.Forms.ComboBox();
            this.SelectPerson = new System.Windows.Forms.ComboBox();
            this.label59 = new System.Windows.Forms.Label();
            this.FirstNameSearch = new System.Windows.Forms.TextBox();
            this.NameSearch = new System.Windows.Forms.Button();
            this.label60 = new System.Windows.Forms.Label();
            this.DepartmentSearch = new System.Windows.Forms.TextBox();
            this.DepartSearch = new System.Windows.Forms.Button();
            this.label61 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.TwoSP = new System.Windows.Forms.MaskedTextBox();
            this.OneSP = new System.Windows.Forms.MaskedTextBox();
            this.SpousePlus = new System.Windows.Forms.Button();
            this.CheckFeMale = new System.Windows.Forms.CheckBox();
            this.label63 = new System.Windows.Forms.Label();
            this.CheckMale = new System.Windows.Forms.CheckBox();
            this.button5 = new System.Windows.Forms.Button();
            this.Nationality = new System.Windows.Forms.MaskedTextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.Spouse = new System.Windows.Forms.MaskedTextBox();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.BirthDate = new System.Windows.Forms.MaskedTextBox();
            this.BirthPlace = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox3 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel13.SuspendLayout();
            this.SuspendLayout();
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(18, 131);
            this.label49.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(54, 12);
            this.label49.TabIndex = 136;
            this.label49.Text = "Authority";
            // 
            // Authority
            // 
            this.Authority.Location = new System.Drawing.Point(96, 130);
            this.Authority.Margin = new System.Windows.Forms.Padding(2);
            this.Authority.Name = "Authority";
            this.Authority.Size = new System.Drawing.Size(75, 21);
            this.Authority.TabIndex = 135;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(18, 111);
            this.label46.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(72, 12);
            this.label46.TabIndex = 133;
            this.label46.Text = "PASSWORD";
            // 
            // PASSWORD
            // 
            this.PASSWORD.Location = new System.Drawing.Point(96, 109);
            this.PASSWORD.Margin = new System.Windows.Forms.Padding(2);
            this.PASSWORD.Name = "PASSWORD";
            this.PASSWORD.Size = new System.Drawing.Size(75, 21);
            this.PASSWORD.TabIndex = 132;
            // 
            // ID
            // 
            this.ID.Location = new System.Drawing.Point(96, 89);
            this.ID.Margin = new System.Windows.Forms.Padding(2);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(75, 21);
            this.ID.TabIndex = 131;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(431, 55);
            this.label45.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(44, 12);
            this.label45.TabIndex = 130;
            this.label45.Text = "Picture";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(27, 608);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(61, 12);
            this.label29.TabIndex = 129;
            this.label29.Text = "Account #";
            // 
            // Account
            // 
            this.Account.Location = new System.Drawing.Point(114, 607);
            this.Account.Margin = new System.Windows.Forms.Padding(2);
            this.Account.Name = "Account";
            this.Account.Size = new System.Drawing.Size(75, 21);
            this.Account.TabIndex = 128;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(27, 588);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(66, 12);
            this.label26.TabIndex = 127;
            this.label26.Text = "Swift Code";
            // 
            // SwiftCode
            // 
            this.SwiftCode.Location = new System.Drawing.Point(114, 586);
            this.SwiftCode.Margin = new System.Windows.Forms.Padding(2);
            this.SwiftCode.Name = "SwiftCode";
            this.SwiftCode.Size = new System.Drawing.Size(75, 21);
            this.SwiftCode.TabIndex = 126;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(27, 568);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(54, 12);
            this.label27.TabIndex = 125;
            this.label27.Text = "AC Bank";
            // 
            // ACBank
            // 
            this.ACBank.Location = new System.Drawing.Point(114, 566);
            this.ACBank.Margin = new System.Windows.Forms.Padding(2);
            this.ACBank.Name = "ACBank";
            this.ACBank.Size = new System.Drawing.Size(75, 21);
            this.ACBank.TabIndex = 124;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(27, 547);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(60, 12);
            this.label28.TabIndex = 123;
            this.label28.Text = "AC Name";
            // 
            // ACName
            // 
            this.ACName.Location = new System.Drawing.Point(114, 546);
            this.ACName.Margin = new System.Windows.Forms.Padding(2);
            this.ACName.Name = "ACName";
            this.ACName.Size = new System.Drawing.Size(75, 21);
            this.ACName.TabIndex = 122;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(27, 496);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(86, 12);
            this.label25.TabIndex = 121;
            this.label25.Text = "Driver License";
            // 
            // DriverLicense
            // 
            this.DriverLicense.Location = new System.Drawing.Point(114, 495);
            this.DriverLicense.Margin = new System.Windows.Forms.Padding(2);
            this.DriverLicense.Name = "DriverLicense";
            this.DriverLicense.Size = new System.Drawing.Size(75, 21);
            this.DriverLicense.TabIndex = 120;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(27, 475);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(30, 12);
            this.label23.TabIndex = 119;
            this.label23.Text = "SSN";
            // 
            // SSN
            // 
            this.SSN.Location = new System.Drawing.Point(114, 474);
            this.SSN.Margin = new System.Windows.Forms.Padding(2);
            this.SSN.Name = "SSN";
            this.SSN.Size = new System.Drawing.Size(75, 21);
            this.SSN.TabIndex = 118;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(27, 455);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(55, 12);
            this.label24.TabIndex = 117;
            this.label24.Text = "Passport";
            // 
            // Passport
            // 
            this.Passport.Location = new System.Drawing.Point(114, 453);
            this.Passport.Margin = new System.Windows.Forms.Padding(2);
            this.Passport.Name = "Passport";
            this.Passport.Size = new System.Drawing.Size(75, 21);
            this.Passport.TabIndex = 116;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(27, 242);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(64, 12);
            this.label18.TabIndex = 107;
            this.label18.Text = "NickName";
            // 
            // NickName
            // 
            this.NickName.Location = new System.Drawing.Point(105, 240);
            this.NickName.Margin = new System.Windows.Forms.Padding(2);
            this.NickName.Name = "NickName";
            this.NickName.Size = new System.Drawing.Size(75, 21);
            this.NickName.TabIndex = 106;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(27, 221);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(63, 12);
            this.label17.TabIndex = 105;
            this.label17.Text = "LastName";
            // 
            // LastName
            // 
            this.LastName.Location = new System.Drawing.Point(105, 220);
            this.LastName.Margin = new System.Windows.Forms.Padding(2);
            this.LastName.Name = "LastName";
            this.LastName.Size = new System.Drawing.Size(75, 21);
            this.LastName.TabIndex = 104;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(27, 200);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 12);
            this.label16.TabIndex = 103;
            this.label16.Text = "MiddleName";
            // 
            // MiddleName
            // 
            this.MiddleName.Location = new System.Drawing.Point(105, 199);
            this.MiddleName.Margin = new System.Windows.Forms.Padding(2);
            this.MiddleName.Name = "MiddleName";
            this.MiddleName.Size = new System.Drawing.Size(75, 21);
            this.MiddleName.TabIndex = 102;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(27, 180);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(63, 12);
            this.label15.TabIndex = 101;
            this.label15.Text = "FirstName";
            // 
            // FirstName
            // 
            this.FirstName.Location = new System.Drawing.Point(105, 178);
            this.FirstName.Margin = new System.Windows.Forms.Padding(2);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(75, 21);
            this.FirstName.TabIndex = 100;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(209, 55);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 12);
            this.label7.TabIndex = 99;
            this.label7.Text = "Contact Info";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 523);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 12);
            this.label6.TabIndex = 98;
            this.label6.Text = "Account";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 161);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 12);
            this.label2.TabIndex = 95;
            this.label2.Text = "Name";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 55);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 12);
            this.label1.TabIndex = 94;
            this.label1.Text = "Personal Info";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Window;
            this.panel2.Controls.Add(this.panel13);
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.Address);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.label33);
            this.panel2.Controls.Add(this.State);
            this.panel2.Controls.Add(this.label32);
            this.panel2.Controls.Add(this.City);
            this.panel2.Controls.Add(this.label31);
            this.panel2.Controls.Add(this.ZipCode);
            this.panel2.Controls.Add(this.label30);
            this.panel2.Controls.Add(this.PEmail);
            this.panel2.Controls.Add(this.label37);
            this.panel2.Controls.Add(this.WEmail);
            this.panel2.Controls.Add(this.label36);
            this.panel2.Controls.Add(this.label40);
            this.panel2.Controls.Add(this.HiredDate);
            this.panel2.Controls.Add(this.ResignDate);
            this.panel2.Controls.Add(this.label41);
            this.panel2.Controls.Add(this.panel8);
            this.panel2.Controls.Add(this.panel9);
            this.panel2.Controls.Add(this.panel10);
            this.panel2.Controls.Add(this.panel11);
            this.panel2.Controls.Add(this.panel12);
            this.panel2.Location = new System.Drawing.Point(11, 70);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(769, 580);
            this.panel2.TabIndex = 137;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.Info;
            this.panel7.Location = new System.Drawing.Point(3, 368);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(191, 206);
            this.panel7.TabIndex = 4;
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(421, 238);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(346, 187);
            this.panel1.TabIndex = 91;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint_1);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.Info;
            this.panel5.Location = new System.Drawing.Point(3, 87);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(190, 108);
            this.panel5.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.Info;
            this.panel4.Controls.Add(this.label62);
            this.panel4.Location = new System.Drawing.Point(3, 7);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(190, 81);
            this.panel4.TabIndex = 1;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(4, 15);
            this.label62.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(16, 12);
            this.label62.TabIndex = 147;
            this.label62.Text = "ID";
            // 
            // Address
            // 
            this.Address.Location = new System.Drawing.Point(317, 41);
            this.Address.Margin = new System.Windows.Forms.Padding(2);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(78, 21);
            this.Address.TabIndex = 44;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(216, 315);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 12);
            this.label12.TabIndex = 11;
            this.label12.Text = "Hired Date";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(216, 335);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(73, 12);
            this.label13.TabIndex = 12;
            this.label13.Text = "Resign Date";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(209, 372);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(50, 12);
            this.label14.TabIndex = 13;
            this.label14.Text = "Position";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(220, 41);
            this.label33.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(52, 12);
            this.label33.TabIndex = 45;
            this.label33.Text = "Address";
            // 
            // State
            // 
            this.State.Location = new System.Drawing.Point(317, 62);
            this.State.Margin = new System.Windows.Forms.Padding(2);
            this.State.Name = "State";
            this.State.Size = new System.Drawing.Size(78, 21);
            this.State.TabIndex = 46;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(220, 62);
            this.label32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(33, 12);
            this.label32.TabIndex = 47;
            this.label32.Text = "State";
            // 
            // City
            // 
            this.City.Location = new System.Drawing.Point(317, 83);
            this.City.Margin = new System.Windows.Forms.Padding(2);
            this.City.Name = "City";
            this.City.Size = new System.Drawing.Size(78, 21);
            this.City.TabIndex = 48;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(220, 83);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(27, 12);
            this.label31.TabIndex = 49;
            this.label31.Text = "City";
            // 
            // ZipCode
            // 
            this.ZipCode.Location = new System.Drawing.Point(317, 103);
            this.ZipCode.Margin = new System.Windows.Forms.Padding(2);
            this.ZipCode.Name = "ZipCode";
            this.ZipCode.Size = new System.Drawing.Size(78, 21);
            this.ZipCode.TabIndex = 50;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(220, 103);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(53, 12);
            this.label30.TabIndex = 51;
            this.label30.Text = "ZipCode";
            // 
            // HPnum
            // 
            this.HPnum.Location = new System.Drawing.Point(118, 21);
            this.HPnum.Margin = new System.Windows.Forms.Padding(2);
            this.HPnum.Name = "HPnum";
            this.HPnum.Size = new System.Drawing.Size(78, 21);
            this.HPnum.TabIndex = 52;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(21, 26);
            this.label35.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(81, 12);
            this.label35.TabIndex = 53;
            this.label35.Text = "Home P.Num";
            // 
            // MPnum
            // 
            this.MPnum.Location = new System.Drawing.Point(118, 42);
            this.MPnum.Margin = new System.Windows.Forms.Padding(2);
            this.MPnum.Name = "MPnum";
            this.MPnum.Size = new System.Drawing.Size(78, 21);
            this.MPnum.TabIndex = 54;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(21, 47);
            this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(94, 12);
            this.label34.TabIndex = 55;
            this.label34.Text = "Mobile P.num 1";
            // 
            // PEmail
            // 
            this.PEmail.Location = new System.Drawing.Point(318, 243);
            this.PEmail.Margin = new System.Windows.Forms.Padding(2);
            this.PEmail.Name = "PEmail";
            this.PEmail.Size = new System.Drawing.Size(78, 21);
            this.PEmail.TabIndex = 56;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(217, 246);
            this.label37.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(97, 12);
            this.label37.TabIndex = 57;
            this.label37.Text = "Personal E-Mail";
            // 
            // WEmail
            // 
            this.WEmail.Location = new System.Drawing.Point(318, 264);
            this.WEmail.Margin = new System.Windows.Forms.Padding(2);
            this.WEmail.Name = "WEmail";
            this.WEmail.Size = new System.Drawing.Size(78, 21);
            this.WEmail.TabIndex = 58;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(217, 267);
            this.label36.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(74, 12);
            this.label36.TabIndex = 59;
            this.label36.Text = "Work E-Mail";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(217, 412);
            this.label40.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(69, 12);
            this.label40.TabIndex = 65;
            this.label40.Text = "Department";
            // 
            // HiredDate
            // 
            this.HiredDate.Location = new System.Drawing.Point(321, 312);
            this.HiredDate.Margin = new System.Windows.Forms.Padding(2);
            this.HiredDate.Name = "HiredDate";
            this.HiredDate.Size = new System.Drawing.Size(75, 21);
            this.HiredDate.TabIndex = 60;
            // 
            // ResignDate
            // 
            this.ResignDate.Location = new System.Drawing.Point(321, 332);
            this.ResignDate.Margin = new System.Windows.Forms.Padding(2);
            this.ResignDate.Name = "ResignDate";
            this.ResignDate.Size = new System.Drawing.Size(75, 21);
            this.ResignDate.TabIndex = 61;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(217, 391);
            this.label41.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(49, 12);
            this.label41.TabIndex = 63;
            this.label41.Text = "Division";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.Info;
            this.panel8.Controls.Add(this.button4);
            this.panel8.Controls.Add(this.label8);
            this.panel8.Location = new System.Drawing.Point(199, 7);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(217, 138);
            this.panel8.TabIndex = 1;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(198, 34);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(16, 21);
            this.button4.TabIndex = 96;
            this.button4.Text = "+";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(10, 6);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 12);
            this.label8.TabIndex = 7;
            this.label8.Text = "Address Info";
            // 
            // panel9
            // 
            this.panel9.AutoScroll = true;
            this.panel9.BackColor = System.Drawing.SystemColors.Info;
            this.panel9.Controls.Add(this.maskedTextBox3);
            this.panel9.Controls.Add(this.label9);
            this.panel9.Controls.Add(this.HPnum);
            this.panel9.Controls.Add(this.maskedTextBox2);
            this.panel9.Controls.Add(this.label34);
            this.panel9.Controls.Add(this.MPnum);
            this.panel9.Controls.Add(this.maskedTextBox1);
            this.panel9.Controls.Add(this.label35);
            this.panel9.Controls.Add(this.button6);
            this.panel9.Location = new System.Drawing.Point(199, 148);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(218, 73);
            this.panel9.TabIndex = 2;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 5);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 12);
            this.label9.TabIndex = 8;
            this.label9.Text = "Phone Num";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.Info;
            this.panel10.Controls.Add(this.label10);
            this.panel10.Controls.Add(this.label11);
            this.panel10.Location = new System.Drawing.Point(199, 224);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(217, 139);
            this.panel10.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(10, 4);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 12);
            this.label10.TabIndex = 9;
            this.label10.Text = "Email Info";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(10, 67);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 12);
            this.label11.TabIndex = 10;
            this.label11.Text = "Job Info";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.SystemColors.Info;
            this.panel11.Controls.Add(this.Classification);
            this.panel11.Controls.Add(this.label38);
            this.panel11.Controls.Add(this.ContractNo);
            this.panel11.Controls.Add(this.label44);
            this.panel11.Controls.Add(this.EmplyStatus);
            this.panel11.Controls.Add(this.label43);
            this.panel11.Controls.Add(this.EmplyWorkout);
            this.panel11.Controls.Add(this.label42);
            this.panel11.Controls.Add(this.Title);
            this.panel11.Controls.Add(this.label39);
            this.panel11.Controls.Add(this.Division);
            this.panel11.Controls.Add(this.DepartMent);
            this.panel11.Location = new System.Drawing.Point(200, 368);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(216, 206);
            this.panel11.TabIndex = 4;
            // 
            // Classification
            // 
            this.Classification.Location = new System.Drawing.Point(120, 82);
            this.Classification.Margin = new System.Windows.Forms.Padding(2);
            this.Classification.Name = "Classification";
            this.Classification.Size = new System.Drawing.Size(75, 21);
            this.Classification.TabIndex = 68;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(16, 91);
            this.label38.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(81, 12);
            this.label38.TabIndex = 69;
            this.label38.Text = "Classification";
            // 
            // ContractNo
            // 
            this.ContractNo.Location = new System.Drawing.Point(120, 109);
            this.ContractNo.Margin = new System.Windows.Forms.Padding(2);
            this.ContractNo.Name = "ContractNo";
            this.ContractNo.Size = new System.Drawing.Size(75, 21);
            this.ContractNo.TabIndex = 70;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(16, 117);
            this.label44.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(72, 12);
            this.label44.TabIndex = 71;
            this.label44.Text = "Contract No";
            // 
            // EmplyStatus
            // 
            this.EmplyStatus.Location = new System.Drawing.Point(120, 134);
            this.EmplyStatus.Margin = new System.Windows.Forms.Padding(2);
            this.EmplyStatus.Name = "EmplyStatus";
            this.EmplyStatus.Size = new System.Drawing.Size(75, 21);
            this.EmplyStatus.TabIndex = 72;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(16, 142);
            this.label43.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(80, 12);
            this.label43.TabIndex = 73;
            this.label43.Text = "Emply Status";
            // 
            // EmplyWorkout
            // 
            this.EmplyWorkout.Location = new System.Drawing.Point(120, 159);
            this.EmplyWorkout.Margin = new System.Windows.Forms.Padding(2);
            this.EmplyWorkout.Name = "EmplyWorkout";
            this.EmplyWorkout.Size = new System.Drawing.Size(75, 21);
            this.EmplyWorkout.TabIndex = 74;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(17, 162);
            this.label42.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(89, 12);
            this.label42.TabIndex = 75;
            this.label42.Text = "Emply Workout";
            // 
            // Title
            // 
            this.Title.Location = new System.Drawing.Point(120, 58);
            this.Title.Margin = new System.Windows.Forms.Padding(2);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(75, 21);
            this.Title.TabIndex = 66;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(16, 67);
            this.label39.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(29, 12);
            this.label39.TabIndex = 67;
            this.label39.Text = "Title";
            // 
            // Division
            // 
            this.Division.Location = new System.Drawing.Point(121, 10);
            this.Division.Margin = new System.Windows.Forms.Padding(2);
            this.Division.Name = "Division";
            this.Division.Size = new System.Drawing.Size(75, 21);
            this.Division.TabIndex = 62;
            // 
            // DepartMent
            // 
            this.DepartMent.Location = new System.Drawing.Point(120, 35);
            this.DepartMent.Margin = new System.Windows.Forms.Padding(2);
            this.DepartMent.Name = "DepartMent";
            this.DepartMent.Size = new System.Drawing.Size(75, 21);
            this.DepartMent.TabIndex = 64;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.SystemColors.Info;
            this.panel12.Controls.Add(this.comboBox1);
            this.panel12.Controls.Add(this.comboBox2);
            this.panel12.Controls.Add(this.WR);
            this.panel12.Controls.Add(this.Apply);
            this.panel12.Controls.Add(this.Remove);
            this.panel12.Controls.Add(this.Save);
            this.panel12.Controls.Add(this.numericUpDown1);
            this.panel12.Location = new System.Drawing.Point(422, 430);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(344, 147);
            this.panel12.TabIndex = 1;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.comboBox1.Location = new System.Drawing.Point(138, 16);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(67, 20);
            this.comboBox1.TabIndex = 90;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31"});
            this.comboBox2.Location = new System.Drawing.Point(207, 16);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(67, 20);
            this.comboBox2.TabIndex = 92;
            // 
            // WR
            // 
            this.WR.Location = new System.Drawing.Point(88, 40);
            this.WR.Margin = new System.Windows.Forms.Padding(2);
            this.WR.Name = "WR";
            this.WR.Size = new System.Drawing.Size(163, 21);
            this.WR.TabIndex = 77;
            this.WR.Text = "Change WorkReport";
            this.WR.UseVisualStyleBackColor = true;
            this.WR.Click += new System.EventHandler(this.WR_Click);
            // 
            // Apply
            // 
            this.Apply.Location = new System.Drawing.Point(63, 65);
            this.Apply.Margin = new System.Windows.Forms.Padding(2);
            this.Apply.Name = "Apply";
            this.Apply.Size = new System.Drawing.Size(218, 21);
            this.Apply.TabIndex = 78;
            this.Apply.Text = "Apply Change - Personal Info";
            this.Apply.UseVisualStyleBackColor = true;
            this.Apply.Click += new System.EventHandler(this.Apply_Click);
            // 
            // Remove
            // 
            this.Remove.Location = new System.Drawing.Point(63, 91);
            this.Remove.Margin = new System.Windows.Forms.Padding(2);
            this.Remove.Name = "Remove";
            this.Remove.Size = new System.Drawing.Size(218, 21);
            this.Remove.TabIndex = 79;
            this.Remove.Text = "Remove Info - Personal Info";
            this.Remove.UseVisualStyleBackColor = true;
            this.Remove.Click += new System.EventHandler(this.Remove_Click);
            // 
            // Save
            // 
            this.Save.Location = new System.Drawing.Point(63, 116);
            this.Save.Margin = new System.Windows.Forms.Padding(2);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(218, 21);
            this.Save.TabIndex = 80;
            this.Save.Text = "Save new Info - Personal Infio";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(70, 16);
            this.numericUpDown1.Margin = new System.Windows.Forms.Padding(2);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            2020,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1990,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(65, 21);
            this.numericUpDown1.TabIndex = 88;
            this.numericUpDown1.Value = new decimal(new int[] {
            1990,
            0,
            0,
            0});
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Window;
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.textBox2);
            this.panel3.Controls.Add(this.button3);
            this.panel3.Controls.Add(this.textBox1);
            this.panel3.Controls.Add(this.label58);
            this.panel3.Controls.Add(this.label57);
            this.panel3.Controls.Add(this.Eval);
            this.panel3.Controls.Add(this.DeptURL);
            this.panel3.Controls.Add(this.label56);
            this.panel3.Controls.Add(this.DeptAddInfo);
            this.panel3.Controls.Add(this.label55);
            this.panel3.Controls.Add(this.DeptEmail);
            this.panel3.Controls.Add(this.label54);
            this.panel3.Controls.Add(this.DeptPhone);
            this.panel3.Controls.Add(this.label53);
            this.panel3.Controls.Add(this.DeptName);
            this.panel3.Controls.Add(this.label52);
            this.panel3.Controls.Add(this.DeptDiv);
            this.panel3.Controls.Add(this.label51);
            this.panel3.Controls.Add(this.label50);
            this.panel3.Controls.Add(this.RegistrationNum);
            this.panel3.Controls.Add(this.label47);
            this.panel3.Controls.Add(this.CompanyName);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.panel14);
            this.panel3.Controls.Add(this.panel15);
            this.panel3.Controls.Add(this.panel16);
            this.panel3.Location = new System.Drawing.Point(786, 70);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(289, 580);
            this.panel3.TabIndex = 138;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(34, 489);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(228, 21);
            this.button1.TabIndex = 93;
            this.button1.Text = "Apply Change - Division Info";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(34, 515);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(228, 21);
            this.button2.TabIndex = 94;
            this.button2.Text = "Remove Info - Division Info";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(162, 446);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 21);
            this.textBox2.TabIndex = 143;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(34, 540);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(228, 21);
            this.button3.TabIndex = 95;
            this.button3.Text = "Save new Info - Division Infio";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(34, 446);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 21);
            this.textBox1.TabIndex = 142;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(87, 423);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(121, 12);
            this.label58.TabIndex = 141;
            this.label58.Text = "of Division Members";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(32, 403);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(230, 12);
            this.label57.TabIndex = 140;
            this.label57.Text = "Count of Division Members Total Salary";
            // 
            // Eval
            // 
            this.Eval.Location = new System.Drawing.Point(212, 221);
            this.Eval.Name = "Eval";
            this.Eval.Size = new System.Drawing.Size(66, 23);
            this.Eval.TabIndex = 109;
            this.Eval.Text = "Eval";
            this.Eval.UseVisualStyleBackColor = true;
            // 
            // DeptURL
            // 
            this.DeptURL.Location = new System.Drawing.Point(116, 222);
            this.DeptURL.Name = "DeptURL";
            this.DeptURL.Size = new System.Drawing.Size(90, 21);
            this.DeptURL.TabIndex = 108;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(13, 228);
            this.label56.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(57, 12);
            this.label56.TabIndex = 107;
            this.label56.Text = "Dept URL";
            // 
            // DeptAddInfo
            // 
            this.DeptAddInfo.Location = new System.Drawing.Point(116, 195);
            this.DeptAddInfo.Name = "DeptAddInfo";
            this.DeptAddInfo.Size = new System.Drawing.Size(90, 21);
            this.DeptAddInfo.TabIndex = 106;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(13, 201);
            this.label55.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(76, 12);
            this.label55.TabIndex = 105;
            this.label55.Text = "Dept AddInfo";
            // 
            // DeptEmail
            // 
            this.DeptEmail.Location = new System.Drawing.Point(116, 168);
            this.DeptEmail.Name = "DeptEmail";
            this.DeptEmail.Size = new System.Drawing.Size(90, 21);
            this.DeptEmail.TabIndex = 104;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(13, 174);
            this.label54.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(66, 12);
            this.label54.TabIndex = 103;
            this.label54.Text = "Dept Email";
            // 
            // DeptPhone
            // 
            this.DeptPhone.Location = new System.Drawing.Point(116, 141);
            this.DeptPhone.Name = "DeptPhone";
            this.DeptPhone.Size = new System.Drawing.Size(90, 21);
            this.DeptPhone.TabIndex = 102;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(13, 147);
            this.label53.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(66, 12);
            this.label53.TabIndex = 101;
            this.label53.Text = "DeptPhone";
            // 
            // DeptName
            // 
            this.DeptName.Location = new System.Drawing.Point(116, 114);
            this.DeptName.Name = "DeptName";
            this.DeptName.Size = new System.Drawing.Size(90, 21);
            this.DeptName.TabIndex = 100;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(13, 120);
            this.label52.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(64, 12);
            this.label52.TabIndex = 99;
            this.label52.Text = "DeptName";
            // 
            // DeptDiv
            // 
            this.DeptDiv.Location = new System.Drawing.Point(116, 87);
            this.DeptDiv.Name = "DeptDiv";
            this.DeptDiv.Size = new System.Drawing.Size(90, 21);
            this.DeptDiv.TabIndex = 98;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(13, 93);
            this.label51.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(47, 12);
            this.label51.TabIndex = 97;
            this.label51.Text = "DeptDiv";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(13, 71);
            this.label50.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(73, 12);
            this.label50.TabIndex = 96;
            this.label50.Text = "Division Info";
            // 
            // RegistrationNum
            // 
            this.RegistrationNum.Location = new System.Drawing.Point(116, 32);
            this.RegistrationNum.Name = "RegistrationNum";
            this.RegistrationNum.Size = new System.Drawing.Size(90, 21);
            this.RegistrationNum.TabIndex = 95;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(13, 38);
            this.label47.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(102, 12);
            this.label47.TabIndex = 94;
            this.label47.Text = "Registration Num";
            // 
            // CompanyName
            // 
            this.CompanyName.Location = new System.Drawing.Point(116, 7);
            this.CompanyName.Name = "CompanyName";
            this.CompanyName.Size = new System.Drawing.Size(90, 21);
            this.CompanyName.TabIndex = 93;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 13);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 12);
            this.label5.TabIndex = 92;
            this.label5.Text = "Company Name";
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.SystemColors.Info;
            this.panel14.Location = new System.Drawing.Point(3, 4);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(283, 56);
            this.panel14.TabIndex = 140;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.SystemColors.Info;
            this.panel15.Location = new System.Drawing.Point(3, 62);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(283, 195);
            this.panel15.TabIndex = 140;
            this.panel15.Paint += new System.Windows.Forms.PaintEventHandler(this.panel15_Paint);
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.SystemColors.Info;
            this.panel16.Location = new System.Drawing.Point(3, 473);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(283, 101);
            this.panel16.TabIndex = 140;
            // 
            // SelectDivision
            // 
            this.SelectDivision.FormattingEnabled = true;
            this.SelectDivision.Items.AddRange(new object[] {
            "APPLE",
            "SAMSUNG",
            "GOOGLE"});
            this.SelectDivision.Location = new System.Drawing.Point(12, 23);
            this.SelectDivision.Name = "SelectDivision";
            this.SelectDivision.Size = new System.Drawing.Size(160, 20);
            this.SelectDivision.TabIndex = 139;
            this.SelectDivision.Text = "Select Division";
            this.SelectDivision.SelectedIndexChanged += new System.EventHandler(this.SelectDivision_SelectedIndexChanged);
            // 
            // SelectPerson
            // 
            this.SelectPerson.FormattingEnabled = true;
            this.SelectPerson.Location = new System.Drawing.Point(178, 23);
            this.SelectPerson.Name = "SelectPerson";
            this.SelectPerson.Size = new System.Drawing.Size(160, 20);
            this.SelectPerson.TabIndex = 140;
            this.SelectPerson.Text = "Select Person";
            this.SelectPerson.SelectedIndexChanged += new System.EventHandler(this.SelectPerson_SelectedIndexChanged);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(361, 26);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(67, 12);
            this.label59.TabIndex = 141;
            this.label59.Text = "First Name";
            // 
            // FirstNameSearch
            // 
            this.FirstNameSearch.Location = new System.Drawing.Point(433, 22);
            this.FirstNameSearch.Name = "FirstNameSearch";
            this.FirstNameSearch.Size = new System.Drawing.Size(100, 21);
            this.FirstNameSearch.TabIndex = 142;
            // 
            // NameSearch
            // 
            this.NameSearch.Location = new System.Drawing.Point(539, 22);
            this.NameSearch.Name = "NameSearch";
            this.NameSearch.Size = new System.Drawing.Size(75, 21);
            this.NameSearch.TabIndex = 143;
            this.NameSearch.Text = "Search";
            this.NameSearch.UseVisualStyleBackColor = true;
            this.NameSearch.Click += new System.EventHandler(this.NameSearch_Click);
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(788, 26);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(69, 12);
            this.label60.TabIndex = 144;
            this.label60.Text = "Department";
            // 
            // DepartmentSearch
            // 
            this.DepartmentSearch.Location = new System.Drawing.Point(863, 23);
            this.DepartmentSearch.Name = "DepartmentSearch";
            this.DepartmentSearch.Size = new System.Drawing.Size(100, 21);
            this.DepartmentSearch.TabIndex = 145;
            // 
            // DepartSearch
            // 
            this.DepartSearch.Location = new System.Drawing.Point(969, 22);
            this.DepartSearch.Name = "DepartSearch";
            this.DepartSearch.Size = new System.Drawing.Size(75, 21);
            this.DepartSearch.TabIndex = 146;
            this.DepartSearch.Text = "Search";
            this.DepartSearch.UseVisualStyleBackColor = true;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(787, 55);
            this.label61.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(84, 12);
            this.label61.TabIndex = 144;
            this.label61.Text = "Company Info";
            // 
            // panel13
            // 
            this.panel13.AutoScroll = true;
            this.panel13.BackColor = System.Drawing.SystemColors.Info;
            this.panel13.Controls.Add(this.TwoSP);
            this.panel13.Controls.Add(this.OneSP);
            this.panel13.Controls.Add(this.SpousePlus);
            this.panel13.Controls.Add(this.CheckFeMale);
            this.panel13.Controls.Add(this.label63);
            this.panel13.Controls.Add(this.CheckMale);
            this.panel13.Controls.Add(this.button5);
            this.panel13.Controls.Add(this.Nationality);
            this.panel13.Controls.Add(this.label64);
            this.panel13.Controls.Add(this.label65);
            this.panel13.Controls.Add(this.Spouse);
            this.panel13.Controls.Add(this.label66);
            this.panel13.Controls.Add(this.label67);
            this.panel13.Controls.Add(this.label68);
            this.panel13.Controls.Add(this.label69);
            this.panel13.Controls.Add(this.BirthDate);
            this.panel13.Controls.Add(this.BirthPlace);
            this.panel13.Location = new System.Drawing.Point(3, 196);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(191, 167);
            this.panel13.TabIndex = 92;
            // 
            // TwoSP
            // 
            this.TwoSP.Location = new System.Drawing.Point(91, 189);
            this.TwoSP.Margin = new System.Windows.Forms.Padding(2);
            this.TwoSP.Name = "TwoSP";
            this.TwoSP.Size = new System.Drawing.Size(75, 21);
            this.TwoSP.TabIndex = 98;
            this.TwoSP.Visible = false;
            // 
            // OneSP
            // 
            this.OneSP.Location = new System.Drawing.Point(91, 164);
            this.OneSP.Margin = new System.Windows.Forms.Padding(2);
            this.OneSP.Name = "OneSP";
            this.OneSP.Size = new System.Drawing.Size(75, 21);
            this.OneSP.TabIndex = 97;
            this.OneSP.Visible = false;
            // 
            // SpousePlus
            // 
            this.SpousePlus.Location = new System.Drawing.Point(171, 140);
            this.SpousePlus.Name = "SpousePlus";
            this.SpousePlus.Size = new System.Drawing.Size(16, 21);
            this.SpousePlus.TabIndex = 96;
            this.SpousePlus.Text = "+";
            this.SpousePlus.UseVisualStyleBackColor = true;
            this.SpousePlus.Click += new System.EventHandler(this.SpousePlus_Click);
            // 
            // CheckFeMale
            // 
            this.CheckFeMale.AutoSize = true;
            this.CheckFeMale.Location = new System.Drawing.Point(121, 74);
            this.CheckFeMale.Name = "CheckFeMale";
            this.CheckFeMale.Size = new System.Drawing.Size(66, 16);
            this.CheckFeMale.TabIndex = 95;
            this.CheckFeMale.Text = "Female";
            this.CheckFeMale.UseVisualStyleBackColor = true;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(4, 73);
            this.label63.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(46, 12);
            this.label63.TabIndex = 85;
            this.label63.Text = "Gender";
            // 
            // CheckMale
            // 
            this.CheckMale.AutoSize = true;
            this.CheckMale.Location = new System.Drawing.Point(68, 74);
            this.CheckMale.Name = "CheckMale";
            this.CheckMale.Size = new System.Drawing.Size(52, 16);
            this.CheckMale.TabIndex = 94;
            this.CheckMale.Text = "Male";
            this.CheckMale.UseVisualStyleBackColor = true;
            this.CheckMale.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(171, 27);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(16, 21);
            this.button5.TabIndex = 94;
            this.button5.Text = "+";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // Nationality
            // 
            this.Nationality.Location = new System.Drawing.Point(91, 92);
            this.Nationality.Margin = new System.Windows.Forms.Padding(2);
            this.Nationality.Name = "Nationality";
            this.Nationality.Size = new System.Drawing.Size(75, 21);
            this.Nationality.TabIndex = 26;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(4, 121);
            this.label64.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(67, 12);
            this.label64.TabIndex = 3;
            this.label64.Text = "Family Info";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(4, 96);
            this.label65.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(64, 12);
            this.label65.TabIndex = 27;
            this.label65.Text = "Nationality";
            // 
            // Spouse
            // 
            this.Spouse.Location = new System.Drawing.Point(91, 140);
            this.Spouse.Margin = new System.Windows.Forms.Padding(2);
            this.Spouse.Name = "Spouse";
            this.Spouse.Size = new System.Drawing.Size(75, 21);
            this.Spouse.TabIndex = 28;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(13, 144);
            this.label66.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(48, 12);
            this.label66.TabIndex = 29;
            this.label66.Text = "Spouse";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(12, 31);
            this.label67.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(59, 12);
            this.label67.TabIndex = 23;
            this.label67.Text = "Birth Date";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(12, 52);
            this.label68.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(66, 12);
            this.label68.TabIndex = 25;
            this.label68.Text = "Birth Place";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(4, 2);
            this.label69.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(120, 12);
            this.label69.TabIndex = 2;
            this.label69.Text = "Place and Birth Date";
            // 
            // BirthDate
            // 
            this.BirthDate.Location = new System.Drawing.Point(91, 27);
            this.BirthDate.Margin = new System.Windows.Forms.Padding(2);
            this.BirthDate.Name = "BirthDate";
            this.BirthDate.Size = new System.Drawing.Size(75, 21);
            this.BirthDate.TabIndex = 22;
            // 
            // BirthPlace
            // 
            this.BirthPlace.Location = new System.Drawing.Point(91, 48);
            this.BirthPlace.Margin = new System.Windows.Forms.Padding(2);
            this.BirthPlace.Name = "BirthPlace";
            this.BirthPlace.Size = new System.Drawing.Size(75, 21);
            this.BirthPlace.TabIndex = 24;
            // 
            // maskedTextBox3
            // 
            this.maskedTextBox3.Location = new System.Drawing.Point(118, 98);
            this.maskedTextBox3.Margin = new System.Windows.Forms.Padding(2);
            this.maskedTextBox3.Name = "maskedTextBox3";
            this.maskedTextBox3.Size = new System.Drawing.Size(78, 21);
            this.maskedTextBox3.TabIndex = 150;
            this.maskedTextBox3.Visible = false;
            // 
            // maskedTextBox2
            // 
            this.maskedTextBox2.Location = new System.Drawing.Point(118, 78);
            this.maskedTextBox2.Margin = new System.Windows.Forms.Padding(2);
            this.maskedTextBox2.Name = "maskedTextBox2";
            this.maskedTextBox2.Size = new System.Drawing.Size(78, 21);
            this.maskedTextBox2.TabIndex = 149;
            this.maskedTextBox2.Visible = false;
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(118, 62);
            this.maskedTextBox1.Margin = new System.Windows.Forms.Padding(2);
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(78, 21);
            this.maskedTextBox1.TabIndex = 148;
            this.maskedTextBox1.Visible = false;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(198, 43);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(16, 21);
            this.button6.TabIndex = 147;
            this.button6.Text = "+";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // Employer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1096, 663);
            this.Controls.Add(this.label61);
            this.Controls.Add(this.DepartSearch);
            this.Controls.Add(this.DepartmentSearch);
            this.Controls.Add(this.label60);
            this.Controls.Add(this.NameSearch);
            this.Controls.Add(this.FirstNameSearch);
            this.Controls.Add(this.label59);
            this.Controls.Add(this.SelectPerson);
            this.Controls.Add(this.SelectDivision);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.Authority);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.PASSWORD);
            this.Controls.Add(this.ID);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.Account);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.SwiftCode);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.ACBank);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.ACName);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.DriverLicense);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.SSN);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.Passport);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.NickName);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.LastName);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.MiddleName);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.FirstName);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel2);
            this.Name = "Employer";
            this.Text = "Employer";
            this.Load += new System.EventHandler(this.Employer_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.MaskedTextBox Authority;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.MaskedTextBox PASSWORD;
        private System.Windows.Forms.MaskedTextBox ID;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.MaskedTextBox Account;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.MaskedTextBox SwiftCode;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.MaskedTextBox ACBank;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.MaskedTextBox ACName;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.MaskedTextBox DriverLicense;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.MaskedTextBox SSN;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.MaskedTextBox Passport;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.MaskedTextBox NickName;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.MaskedTextBox LastName;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.MaskedTextBox MiddleName;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.MaskedTextBox FirstName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.MaskedTextBox Address;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.MaskedTextBox State;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.MaskedTextBox City;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.MaskedTextBox ZipCode;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.MaskedTextBox HPnum;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.MaskedTextBox MPnum;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.MaskedTextBox PEmail;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.MaskedTextBox WEmail;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.MaskedTextBox HiredDate;
        private System.Windows.Forms.MaskedTextBox ResignDate;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.MaskedTextBox Classification;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.MaskedTextBox ContractNo;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.MaskedTextBox EmplyStatus;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.MaskedTextBox EmplyWorkout;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.MaskedTextBox Title;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.MaskedTextBox Division;
        private System.Windows.Forms.MaskedTextBox DepartMent;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button WR;
        private System.Windows.Forms.Button Apply;
        private System.Windows.Forms.Button Remove;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Button Eval;
        private System.Windows.Forms.TextBox DeptURL;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox DeptAddInfo;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox DeptEmail;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox DeptPhone;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox DeptName;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox DeptDiv;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox RegistrationNum;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox CompanyName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.ComboBox SelectDivision;
        private System.Windows.Forms.ComboBox SelectPerson;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox FirstNameSearch;
        private System.Windows.Forms.Button NameSearch;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.TextBox DepartmentSearch;
        private System.Windows.Forms.Button DepartSearch;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.MaskedTextBox TwoSP;
        private System.Windows.Forms.MaskedTextBox OneSP;
        private System.Windows.Forms.Button SpousePlus;
        private System.Windows.Forms.CheckBox CheckFeMale;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.CheckBox CheckMale;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.MaskedTextBox Nationality;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.MaskedTextBox Spouse;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.MaskedTextBox BirthDate;
        private System.Windows.Forms.MaskedTextBox BirthPlace;
        private System.Windows.Forms.MaskedTextBox maskedTextBox3;
        private System.Windows.Forms.MaskedTextBox maskedTextBox2;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.Button button6;
    }
}