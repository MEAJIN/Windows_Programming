﻿namespace TermProject20144675KJH
{
    partial class Employee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.FirstName = new System.Windows.Forms.MaskedTextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.MiddleName = new System.Windows.Forms.MaskedTextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.LastName = new System.Windows.Forms.MaskedTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.NickName = new System.Windows.Forms.MaskedTextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.BirthPlace = new System.Windows.Forms.MaskedTextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.BirthDate = new System.Windows.Forms.MaskedTextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.Spouse = new System.Windows.Forms.MaskedTextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.Nationality = new System.Windows.Forms.MaskedTextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.SSN = new System.Windows.Forms.MaskedTextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.Passport = new System.Windows.Forms.MaskedTextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.DriverLicense = new System.Windows.Forms.MaskedTextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.SwiftCode = new System.Windows.Forms.MaskedTextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.ACBank = new System.Windows.Forms.MaskedTextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.Account = new System.Windows.Forms.MaskedTextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.ZipCode = new System.Windows.Forms.MaskedTextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.City = new System.Windows.Forms.MaskedTextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.State = new System.Windows.Forms.MaskedTextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.Address = new System.Windows.Forms.MaskedTextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.MPnum = new System.Windows.Forms.MaskedTextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.HPnum = new System.Windows.Forms.MaskedTextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.WEmail = new System.Windows.Forms.MaskedTextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.PEmail = new System.Windows.Forms.MaskedTextBox();
            this.ResignDate = new System.Windows.Forms.MaskedTextBox();
            this.HiredDate = new System.Windows.Forms.MaskedTextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.Classification = new System.Windows.Forms.MaskedTextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.Title = new System.Windows.Forms.MaskedTextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.DepartMent = new System.Windows.Forms.MaskedTextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.Division = new System.Windows.Forms.MaskedTextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.EmplyWorkout = new System.Windows.Forms.MaskedTextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.EmplyStatus = new System.Windows.Forms.MaskedTextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.ContractNo = new System.Windows.Forms.MaskedTextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.WR = new System.Windows.Forms.Button();
            this.Apply = new System.Windows.Forms.Button();
            this.Remove = new System.Windows.Forms.Button();
            this.Save = new System.Windows.Forms.Button();
            this.label46 = new System.Windows.Forms.Label();
            this.PASSWORD = new System.Windows.Forms.MaskedTextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.ID = new System.Windows.Forms.MaskedTextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.Authority = new System.Windows.Forms.MaskedTextBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.maskedTextBox3 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.TwoSP = new System.Windows.Forms.MaskedTextBox();
            this.OneSP = new System.Windows.Forms.MaskedTextBox();
            this.SpousePlus = new System.Windows.Forms.Button();
            this.CheckFeMale = new System.Windows.Forms.CheckBox();
            this.CheckMale = new System.Windows.Forms.CheckBox();
            this.BirthPlus = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.ACName = new System.Windows.Forms.MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel12.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 51);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "Personal Info";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 157);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 2);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "Place and Birth Date";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 121);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "Family Info";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 438);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "ID";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 519);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 12);
            this.label6.TabIndex = 5;
            this.label6.Text = "Account";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(210, 51);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 12);
            this.label7.TabIndex = 6;
            this.label7.Text = "Contact Info";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(209, 22);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 12);
            this.label8.TabIndex = 7;
            this.label8.Text = "Address Info";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 6);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 12);
            this.label9.TabIndex = 8;
            this.label9.Text = "Phone Num";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(209, 226);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(61, 12);
            this.label10.TabIndex = 9;
            this.label10.Text = "Email Info";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(209, 297);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 12);
            this.label11.TabIndex = 10;
            this.label11.Text = "Job Info";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(216, 315);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 12);
            this.label12.TabIndex = 11;
            this.label12.Text = "Hired Date";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(216, 335);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(73, 12);
            this.label13.TabIndex = 12;
            this.label13.Text = "Resign Date";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(209, 372);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(50, 12);
            this.label14.TabIndex = 13;
            this.label14.Text = "Position";
            // 
            // FirstName
            // 
            this.FirstName.Location = new System.Drawing.Point(106, 174);
            this.FirstName.Margin = new System.Windows.Forms.Padding(2);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(75, 21);
            this.FirstName.TabIndex = 14;
            this.FirstName.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.FirstName_MaskInputRejected);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(28, 176);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(63, 12);
            this.label15.TabIndex = 15;
            this.label15.Text = "FirstName";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(28, 196);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(77, 12);
            this.label16.TabIndex = 17;
            this.label16.Text = "MiddleName";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // MiddleName
            // 
            this.MiddleName.Location = new System.Drawing.Point(106, 195);
            this.MiddleName.Margin = new System.Windows.Forms.Padding(2);
            this.MiddleName.Name = "MiddleName";
            this.MiddleName.Size = new System.Drawing.Size(75, 21);
            this.MiddleName.TabIndex = 16;
            this.MiddleName.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MiddleName_MaskInputRejected);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(28, 217);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(63, 12);
            this.label17.TabIndex = 19;
            this.label17.Text = "LastName";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // LastName
            // 
            this.LastName.Location = new System.Drawing.Point(106, 216);
            this.LastName.Margin = new System.Windows.Forms.Padding(2);
            this.LastName.Name = "LastName";
            this.LastName.Size = new System.Drawing.Size(75, 21);
            this.LastName.TabIndex = 18;
            this.LastName.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.LastName_MaskInputRejected);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(28, 238);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(64, 12);
            this.label18.TabIndex = 21;
            this.label18.Text = "NickName";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // NickName
            // 
            this.NickName.Location = new System.Drawing.Point(106, 236);
            this.NickName.Margin = new System.Windows.Forms.Padding(2);
            this.NickName.Name = "NickName";
            this.NickName.Size = new System.Drawing.Size(75, 21);
            this.NickName.TabIndex = 20;
            this.NickName.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.NickName_MaskInputRejected);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(12, 52);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(66, 12);
            this.label19.TabIndex = 25;
            this.label19.Text = "Birth Place";
            // 
            // BirthPlace
            // 
            this.BirthPlace.Location = new System.Drawing.Point(91, 48);
            this.BirthPlace.Margin = new System.Windows.Forms.Padding(2);
            this.BirthPlace.Name = "BirthPlace";
            this.BirthPlace.Size = new System.Drawing.Size(75, 21);
            this.BirthPlace.TabIndex = 24;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(12, 31);
            this.label20.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(59, 12);
            this.label20.TabIndex = 23;
            this.label20.Text = "Birth Date";
            // 
            // BirthDate
            // 
            this.BirthDate.Location = new System.Drawing.Point(91, 27);
            this.BirthDate.Margin = new System.Windows.Forms.Padding(2);
            this.BirthDate.Name = "BirthDate";
            this.BirthDate.Size = new System.Drawing.Size(75, 21);
            this.BirthDate.TabIndex = 22;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(13, 144);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(48, 12);
            this.label21.TabIndex = 29;
            this.label21.Text = "Spouse";
            // 
            // Spouse
            // 
            this.Spouse.Location = new System.Drawing.Point(91, 140);
            this.Spouse.Margin = new System.Windows.Forms.Padding(2);
            this.Spouse.Name = "Spouse";
            this.Spouse.Size = new System.Drawing.Size(75, 21);
            this.Spouse.TabIndex = 28;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(4, 96);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(64, 12);
            this.label22.TabIndex = 27;
            this.label22.Text = "Nationality";
            // 
            // Nationality
            // 
            this.Nationality.Location = new System.Drawing.Point(91, 92);
            this.Nationality.Margin = new System.Windows.Forms.Padding(2);
            this.Nationality.Name = "Nationality";
            this.Nationality.Size = new System.Drawing.Size(75, 21);
            this.Nationality.TabIndex = 26;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(28, 471);
            this.label23.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(30, 12);
            this.label23.TabIndex = 33;
            this.label23.Text = "SSN";
            // 
            // SSN
            // 
            this.SSN.Location = new System.Drawing.Point(115, 470);
            this.SSN.Margin = new System.Windows.Forms.Padding(2);
            this.SSN.Name = "SSN";
            this.SSN.Size = new System.Drawing.Size(75, 21);
            this.SSN.TabIndex = 32;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(28, 451);
            this.label24.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(55, 12);
            this.label24.TabIndex = 31;
            this.label24.Text = "Passport";
            // 
            // Passport
            // 
            this.Passport.Location = new System.Drawing.Point(115, 449);
            this.Passport.Margin = new System.Windows.Forms.Padding(2);
            this.Passport.Name = "Passport";
            this.Passport.Size = new System.Drawing.Size(75, 21);
            this.Passport.TabIndex = 30;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(28, 492);
            this.label25.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(86, 12);
            this.label25.TabIndex = 35;
            this.label25.Text = "Driver License";
            // 
            // DriverLicense
            // 
            this.DriverLicense.Location = new System.Drawing.Point(115, 491);
            this.DriverLicense.Margin = new System.Windows.Forms.Padding(2);
            this.DriverLicense.Name = "DriverLicense";
            this.DriverLicense.Size = new System.Drawing.Size(75, 21);
            this.DriverLicense.TabIndex = 34;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(28, 584);
            this.label26.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(66, 12);
            this.label26.TabIndex = 41;
            this.label26.Text = "Swift Code";
            // 
            // SwiftCode
            // 
            this.SwiftCode.Location = new System.Drawing.Point(115, 582);
            this.SwiftCode.Margin = new System.Windows.Forms.Padding(2);
            this.SwiftCode.Name = "SwiftCode";
            this.SwiftCode.Size = new System.Drawing.Size(75, 21);
            this.SwiftCode.TabIndex = 40;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(28, 564);
            this.label27.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(54, 12);
            this.label27.TabIndex = 39;
            this.label27.Text = "AC Bank";
            // 
            // ACBank
            // 
            this.ACBank.Location = new System.Drawing.Point(115, 562);
            this.ACBank.Margin = new System.Windows.Forms.Padding(2);
            this.ACBank.Name = "ACBank";
            this.ACBank.Size = new System.Drawing.Size(75, 21);
            this.ACBank.TabIndex = 38;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(28, 543);
            this.label28.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(60, 12);
            this.label28.TabIndex = 37;
            this.label28.Text = "AC Name";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(28, 604);
            this.label29.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(61, 12);
            this.label29.TabIndex = 43;
            this.label29.Text = "Account #";
            // 
            // Account
            // 
            this.Account.Location = new System.Drawing.Point(115, 603);
            this.Account.Margin = new System.Windows.Forms.Padding(2);
            this.Account.Name = "Account";
            this.Account.Size = new System.Drawing.Size(75, 21);
            this.Account.TabIndex = 42;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(220, 103);
            this.label30.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(53, 12);
            this.label30.TabIndex = 51;
            this.label30.Text = "ZipCode";
            // 
            // ZipCode
            // 
            this.ZipCode.Location = new System.Drawing.Point(317, 103);
            this.ZipCode.Margin = new System.Windows.Forms.Padding(2);
            this.ZipCode.Name = "ZipCode";
            this.ZipCode.Size = new System.Drawing.Size(78, 21);
            this.ZipCode.TabIndex = 50;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(220, 83);
            this.label31.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(27, 12);
            this.label31.TabIndex = 49;
            this.label31.Text = "City";
            // 
            // City
            // 
            this.City.Location = new System.Drawing.Point(317, 83);
            this.City.Margin = new System.Windows.Forms.Padding(2);
            this.City.Name = "City";
            this.City.Size = new System.Drawing.Size(78, 21);
            this.City.TabIndex = 48;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(220, 62);
            this.label32.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(33, 12);
            this.label32.TabIndex = 47;
            this.label32.Text = "State";
            // 
            // State
            // 
            this.State.Location = new System.Drawing.Point(317, 62);
            this.State.Margin = new System.Windows.Forms.Padding(2);
            this.State.Name = "State";
            this.State.Size = new System.Drawing.Size(78, 21);
            this.State.TabIndex = 46;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(220, 41);
            this.label33.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(52, 12);
            this.label33.TabIndex = 45;
            this.label33.Text = "Address";
            // 
            // Address
            // 
            this.Address.Location = new System.Drawing.Point(317, 41);
            this.Address.Margin = new System.Windows.Forms.Padding(2);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(78, 21);
            this.Address.TabIndex = 44;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(21, 50);
            this.label34.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(94, 12);
            this.label34.TabIndex = 55;
            this.label34.Text = "Mobile P.num 1";
            // 
            // MPnum
            // 
            this.MPnum.Location = new System.Drawing.Point(118, 45);
            this.MPnum.Margin = new System.Windows.Forms.Padding(2);
            this.MPnum.Name = "MPnum";
            this.MPnum.Size = new System.Drawing.Size(78, 21);
            this.MPnum.TabIndex = 54;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(21, 29);
            this.label35.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(81, 12);
            this.label35.TabIndex = 53;
            this.label35.Text = "Home P.Num";
            // 
            // HPnum
            // 
            this.HPnum.Location = new System.Drawing.Point(118, 24);
            this.HPnum.Margin = new System.Windows.Forms.Padding(2);
            this.HPnum.Name = "HPnum";
            this.HPnum.Size = new System.Drawing.Size(78, 21);
            this.HPnum.TabIndex = 52;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(217, 267);
            this.label36.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(74, 12);
            this.label36.TabIndex = 59;
            this.label36.Text = "Work E-Mail";
            // 
            // WEmail
            // 
            this.WEmail.Location = new System.Drawing.Point(318, 264);
            this.WEmail.Margin = new System.Windows.Forms.Padding(2);
            this.WEmail.Name = "WEmail";
            this.WEmail.Size = new System.Drawing.Size(78, 21);
            this.WEmail.TabIndex = 58;
            this.WEmail.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.WEmail_MaskInputRejected);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(217, 246);
            this.label37.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(97, 12);
            this.label37.TabIndex = 57;
            this.label37.Text = "Personal E-Mail";
            // 
            // PEmail
            // 
            this.PEmail.Location = new System.Drawing.Point(318, 243);
            this.PEmail.Margin = new System.Windows.Forms.Padding(2);
            this.PEmail.Name = "PEmail";
            this.PEmail.Size = new System.Drawing.Size(78, 21);
            this.PEmail.TabIndex = 56;
            this.PEmail.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.PEmail_MaskInputRejected);
            // 
            // ResignDate
            // 
            this.ResignDate.Location = new System.Drawing.Point(321, 332);
            this.ResignDate.Margin = new System.Windows.Forms.Padding(2);
            this.ResignDate.Name = "ResignDate";
            this.ResignDate.Size = new System.Drawing.Size(75, 21);
            this.ResignDate.TabIndex = 61;
            // 
            // HiredDate
            // 
            this.HiredDate.Location = new System.Drawing.Point(321, 312);
            this.HiredDate.Margin = new System.Windows.Forms.Padding(2);
            this.HiredDate.Name = "HiredDate";
            this.HiredDate.Size = new System.Drawing.Size(75, 21);
            this.HiredDate.TabIndex = 60;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(16, 91);
            this.label38.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(81, 12);
            this.label38.TabIndex = 69;
            this.label38.Text = "Classification";
            // 
            // Classification
            // 
            this.Classification.Location = new System.Drawing.Point(120, 82);
            this.Classification.Margin = new System.Windows.Forms.Padding(2);
            this.Classification.Name = "Classification";
            this.Classification.Size = new System.Drawing.Size(75, 21);
            this.Classification.TabIndex = 68;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(16, 67);
            this.label39.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(29, 12);
            this.label39.TabIndex = 67;
            this.label39.Text = "Title";
            // 
            // Title
            // 
            this.Title.Location = new System.Drawing.Point(120, 58);
            this.Title.Margin = new System.Windows.Forms.Padding(2);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(75, 21);
            this.Title.TabIndex = 66;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(217, 412);
            this.label40.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(69, 12);
            this.label40.TabIndex = 65;
            this.label40.Text = "Department";
            // 
            // DepartMent
            // 
            this.DepartMent.Location = new System.Drawing.Point(120, 35);
            this.DepartMent.Margin = new System.Windows.Forms.Padding(2);
            this.DepartMent.Name = "DepartMent";
            this.DepartMent.Size = new System.Drawing.Size(75, 21);
            this.DepartMent.TabIndex = 64;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(217, 391);
            this.label41.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(49, 12);
            this.label41.TabIndex = 63;
            this.label41.Text = "Division";
            // 
            // Division
            // 
            this.Division.Location = new System.Drawing.Point(121, 10);
            this.Division.Margin = new System.Windows.Forms.Padding(2);
            this.Division.Name = "Division";
            this.Division.Size = new System.Drawing.Size(75, 21);
            this.Division.TabIndex = 62;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(17, 162);
            this.label42.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(89, 12);
            this.label42.TabIndex = 75;
            this.label42.Text = "Emply Workout";
            // 
            // EmplyWorkout
            // 
            this.EmplyWorkout.Location = new System.Drawing.Point(120, 159);
            this.EmplyWorkout.Margin = new System.Windows.Forms.Padding(2);
            this.EmplyWorkout.Name = "EmplyWorkout";
            this.EmplyWorkout.Size = new System.Drawing.Size(75, 21);
            this.EmplyWorkout.TabIndex = 74;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(16, 142);
            this.label43.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(80, 12);
            this.label43.TabIndex = 73;
            this.label43.Text = "Emply Status";
            // 
            // EmplyStatus
            // 
            this.EmplyStatus.Location = new System.Drawing.Point(120, 134);
            this.EmplyStatus.Margin = new System.Windows.Forms.Padding(2);
            this.EmplyStatus.Name = "EmplyStatus";
            this.EmplyStatus.Size = new System.Drawing.Size(75, 21);
            this.EmplyStatus.TabIndex = 72;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(16, 117);
            this.label44.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(72, 12);
            this.label44.TabIndex = 71;
            this.label44.Text = "Contract No";
            // 
            // ContractNo
            // 
            this.ContractNo.Location = new System.Drawing.Point(120, 109);
            this.ContractNo.Margin = new System.Windows.Forms.Padding(2);
            this.ContractNo.Name = "ContractNo";
            this.ContractNo.Size = new System.Drawing.Size(75, 21);
            this.ContractNo.TabIndex = 70;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(452, 51);
            this.label45.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(44, 12);
            this.label45.TabIndex = 76;
            this.label45.Text = "Picture";
            // 
            // WR
            // 
            this.WR.Location = new System.Drawing.Point(87, 39);
            this.WR.Margin = new System.Windows.Forms.Padding(2);
            this.WR.Name = "WR";
            this.WR.Size = new System.Drawing.Size(163, 21);
            this.WR.TabIndex = 77;
            this.WR.Text = "Change WorkReport";
            this.WR.UseVisualStyleBackColor = true;
            this.WR.Click += new System.EventHandler(this.WorkReport_Click);
            // 
            // Apply
            // 
            this.Apply.Location = new System.Drawing.Point(62, 64);
            this.Apply.Margin = new System.Windows.Forms.Padding(2);
            this.Apply.Name = "Apply";
            this.Apply.Size = new System.Drawing.Size(218, 21);
            this.Apply.TabIndex = 78;
            this.Apply.Text = "Apply Change - Personal Info";
            this.Apply.UseVisualStyleBackColor = true;
            this.Apply.Click += new System.EventHandler(this.Apply_Click);
            // 
            // Remove
            // 
            this.Remove.Location = new System.Drawing.Point(62, 90);
            this.Remove.Margin = new System.Windows.Forms.Padding(2);
            this.Remove.Name = "Remove";
            this.Remove.Size = new System.Drawing.Size(218, 21);
            this.Remove.TabIndex = 79;
            this.Remove.Text = "Remove Info - Personal Info";
            this.Remove.UseVisualStyleBackColor = true;
            this.Remove.Click += new System.EventHandler(this.Remove_Click);
            // 
            // Save
            // 
            this.Save.Location = new System.Drawing.Point(62, 115);
            this.Save.Margin = new System.Windows.Forms.Padding(2);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(218, 21);
            this.Save.TabIndex = 80;
            this.Save.Text = "Save new Info - Personal Infio";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(19, 107);
            this.label46.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(72, 12);
            this.label46.TabIndex = 84;
            this.label46.Text = "PASSWORD";
            // 
            // PASSWORD
            // 
            this.PASSWORD.Location = new System.Drawing.Point(97, 105);
            this.PASSWORD.Margin = new System.Windows.Forms.Padding(2);
            this.PASSWORD.Name = "PASSWORD";
            this.PASSWORD.Size = new System.Drawing.Size(75, 21);
            this.PASSWORD.TabIndex = 83;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(19, 87);
            this.label47.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(16, 12);
            this.label47.TabIndex = 82;
            this.label47.Text = "ID";
            // 
            // ID
            // 
            this.ID.Location = new System.Drawing.Point(97, 85);
            this.ID.Margin = new System.Windows.Forms.Padding(2);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(75, 21);
            this.ID.TabIndex = 81;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(4, 73);
            this.label48.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(46, 12);
            this.label48.TabIndex = 85;
            this.label48.Text = "Gender";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(19, 127);
            this.label49.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(54, 12);
            this.label49.TabIndex = 87;
            this.label49.Text = "Authority";
            // 
            // Authority
            // 
            this.Authority.Location = new System.Drawing.Point(97, 126);
            this.Authority.Margin = new System.Windows.Forms.Padding(2);
            this.Authority.Name = "Authority";
            this.Authority.Size = new System.Drawing.Size(75, 21);
            this.Authority.TabIndex = 86;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(69, 15);
            this.numericUpDown1.Margin = new System.Windows.Forms.Padding(2);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            2020,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1990,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(65, 21);
            this.numericUpDown1.TabIndex = 88;
            this.numericUpDown1.Value = new decimal(new int[] {
            1990,
            0,
            0,
            0});
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.comboBox1.Location = new System.Drawing.Point(137, 15);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(67, 20);
            this.comboBox1.TabIndex = 90;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(421, 238);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(338, 187);
            this.panel1.TabIndex = 91;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint_1);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31"});
            this.comboBox2.Location = new System.Drawing.Point(206, 15);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(67, 20);
            this.comboBox2.TabIndex = 92;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Window;
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.Address);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.label33);
            this.panel2.Controls.Add(this.State);
            this.panel2.Controls.Add(this.label32);
            this.panel2.Controls.Add(this.City);
            this.panel2.Controls.Add(this.label31);
            this.panel2.Controls.Add(this.ZipCode);
            this.panel2.Controls.Add(this.label30);
            this.panel2.Controls.Add(this.PEmail);
            this.panel2.Controls.Add(this.label37);
            this.panel2.Controls.Add(this.WEmail);
            this.panel2.Controls.Add(this.label36);
            this.panel2.Controls.Add(this.label40);
            this.panel2.Controls.Add(this.HiredDate);
            this.panel2.Controls.Add(this.ResignDate);
            this.panel2.Controls.Add(this.label41);
            this.panel2.Controls.Add(this.panel8);
            this.panel2.Controls.Add(this.panel9);
            this.panel2.Controls.Add(this.panel10);
            this.panel2.Controls.Add(this.panel11);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel12);
            this.panel2.Location = new System.Drawing.Point(12, 66);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(769, 580);
            this.panel2.TabIndex = 93;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.Info;
            this.panel7.Controls.Add(this.listBox1);
            this.panel7.Location = new System.Drawing.Point(3, 368);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(191, 209);
            this.panel7.TabIndex = 4;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(100, 108);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(75, 28);
            this.listBox1.TabIndex = 94;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.Info;
            this.panel5.Location = new System.Drawing.Point(3, 87);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(190, 108);
            this.panel5.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.Info;
            this.panel4.Location = new System.Drawing.Point(3, 7);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(190, 81);
            this.panel4.TabIndex = 1;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.Info;
            this.panel8.Controls.Add(this.button1);
            this.panel8.Location = new System.Drawing.Point(199, 7);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(217, 138);
            this.panel8.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(198, 34);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(16, 21);
            this.button1.TabIndex = 95;
            this.button1.Text = "+";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel9
            // 
            this.panel9.AutoScroll = true;
            this.panel9.BackColor = System.Drawing.SystemColors.Info;
            this.panel9.Controls.Add(this.maskedTextBox3);
            this.panel9.Controls.Add(this.maskedTextBox2);
            this.panel9.Controls.Add(this.maskedTextBox1);
            this.panel9.Controls.Add(this.button2);
            this.panel9.Controls.Add(this.HPnum);
            this.panel9.Controls.Add(this.label34);
            this.panel9.Controls.Add(this.MPnum);
            this.panel9.Controls.Add(this.label35);
            this.panel9.Controls.Add(this.label9);
            this.panel9.Location = new System.Drawing.Point(199, 147);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(217, 76);
            this.panel9.TabIndex = 2;
            // 
            // maskedTextBox3
            // 
            this.maskedTextBox3.Location = new System.Drawing.Point(117, 110);
            this.maskedTextBox3.Margin = new System.Windows.Forms.Padding(2);
            this.maskedTextBox3.Name = "maskedTextBox3";
            this.maskedTextBox3.Size = new System.Drawing.Size(78, 21);
            this.maskedTextBox3.TabIndex = 102;
            this.maskedTextBox3.Visible = false;
            // 
            // maskedTextBox2
            // 
            this.maskedTextBox2.Location = new System.Drawing.Point(118, 86);
            this.maskedTextBox2.Margin = new System.Windows.Forms.Padding(2);
            this.maskedTextBox2.Name = "maskedTextBox2";
            this.maskedTextBox2.Size = new System.Drawing.Size(78, 21);
            this.maskedTextBox2.TabIndex = 101;
            this.maskedTextBox2.Visible = false;
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(118, 66);
            this.maskedTextBox1.Margin = new System.Windows.Forms.Padding(2);
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(78, 21);
            this.maskedTextBox1.TabIndex = 100;
            this.maskedTextBox1.Visible = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(198, 46);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(16, 21);
            this.button2.TabIndex = 99;
            this.button2.Text = "+";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.Info;
            this.panel10.Location = new System.Drawing.Point(199, 224);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(217, 139);
            this.panel10.TabIndex = 3;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.SystemColors.Info;
            this.panel11.Controls.Add(this.Classification);
            this.panel11.Controls.Add(this.label38);
            this.panel11.Controls.Add(this.ContractNo);
            this.panel11.Controls.Add(this.label44);
            this.panel11.Controls.Add(this.EmplyStatus);
            this.panel11.Controls.Add(this.label43);
            this.panel11.Controls.Add(this.EmplyWorkout);
            this.panel11.Controls.Add(this.label42);
            this.panel11.Controls.Add(this.Title);
            this.panel11.Controls.Add(this.label39);
            this.panel11.Controls.Add(this.Division);
            this.panel11.Controls.Add(this.DepartMent);
            this.panel11.Location = new System.Drawing.Point(200, 368);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(216, 209);
            this.panel11.TabIndex = 4;
            // 
            // panel6
            // 
            this.panel6.AutoScroll = true;
            this.panel6.BackColor = System.Drawing.SystemColors.Info;
            this.panel6.Controls.Add(this.TwoSP);
            this.panel6.Controls.Add(this.OneSP);
            this.panel6.Controls.Add(this.SpousePlus);
            this.panel6.Controls.Add(this.CheckFeMale);
            this.panel6.Controls.Add(this.label48);
            this.panel6.Controls.Add(this.CheckMale);
            this.panel6.Controls.Add(this.BirthPlus);
            this.panel6.Controls.Add(this.Nationality);
            this.panel6.Controls.Add(this.label4);
            this.panel6.Controls.Add(this.label22);
            this.panel6.Controls.Add(this.Spouse);
            this.panel6.Controls.Add(this.label21);
            this.panel6.Controls.Add(this.label20);
            this.panel6.Controls.Add(this.label19);
            this.panel6.Controls.Add(this.label3);
            this.panel6.Controls.Add(this.BirthDate);
            this.panel6.Controls.Add(this.BirthPlace);
            this.panel6.Location = new System.Drawing.Point(3, 196);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(191, 167);
            this.panel6.TabIndex = 3;
            this.panel6.Paint += new System.Windows.Forms.PaintEventHandler(this.panel6_Paint);
            // 
            // TwoSP
            // 
            this.TwoSP.Location = new System.Drawing.Point(91, 189);
            this.TwoSP.Margin = new System.Windows.Forms.Padding(2);
            this.TwoSP.Name = "TwoSP";
            this.TwoSP.Size = new System.Drawing.Size(75, 21);
            this.TwoSP.TabIndex = 98;
            this.TwoSP.Visible = false;
            // 
            // OneSP
            // 
            this.OneSP.Location = new System.Drawing.Point(91, 164);
            this.OneSP.Margin = new System.Windows.Forms.Padding(2);
            this.OneSP.Name = "OneSP";
            this.OneSP.Size = new System.Drawing.Size(75, 21);
            this.OneSP.TabIndex = 97;
            this.OneSP.Visible = false;
            // 
            // SpousePlus
            // 
            this.SpousePlus.Location = new System.Drawing.Point(171, 140);
            this.SpousePlus.Name = "SpousePlus";
            this.SpousePlus.Size = new System.Drawing.Size(16, 21);
            this.SpousePlus.TabIndex = 96;
            this.SpousePlus.Text = "+";
            this.SpousePlus.UseVisualStyleBackColor = true;
            this.SpousePlus.Click += new System.EventHandler(this.SpousePlus_Click);
            // 
            // CheckFeMale
            // 
            this.CheckFeMale.AutoSize = true;
            this.CheckFeMale.Location = new System.Drawing.Point(121, 74);
            this.CheckFeMale.Name = "CheckFeMale";
            this.CheckFeMale.Size = new System.Drawing.Size(66, 16);
            this.CheckFeMale.TabIndex = 95;
            this.CheckFeMale.Text = "Female";
            this.CheckFeMale.UseVisualStyleBackColor = true;
            // 
            // CheckMale
            // 
            this.CheckMale.AutoSize = true;
            this.CheckMale.Location = new System.Drawing.Point(68, 74);
            this.CheckMale.Name = "CheckMale";
            this.CheckMale.Size = new System.Drawing.Size(52, 16);
            this.CheckMale.TabIndex = 94;
            this.CheckMale.Text = "Male";
            this.CheckMale.UseVisualStyleBackColor = true;
            // 
            // BirthPlus
            // 
            this.BirthPlus.Location = new System.Drawing.Point(171, 27);
            this.BirthPlus.Name = "BirthPlus";
            this.BirthPlus.Size = new System.Drawing.Size(16, 21);
            this.BirthPlus.TabIndex = 94;
            this.BirthPlus.Text = "+";
            this.BirthPlus.UseVisualStyleBackColor = true;
            this.BirthPlus.Click += new System.EventHandler(this.BirthPlus_Click);
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.SystemColors.Info;
            this.panel12.Controls.Add(this.comboBox1);
            this.panel12.Controls.Add(this.comboBox2);
            this.panel12.Controls.Add(this.WR);
            this.panel12.Controls.Add(this.Apply);
            this.panel12.Controls.Add(this.Remove);
            this.panel12.Controls.Add(this.Save);
            this.panel12.Controls.Add(this.numericUpDown1);
            this.panel12.Location = new System.Drawing.Point(422, 430);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(337, 147);
            this.panel12.TabIndex = 1;
            // 
            // ACName
            // 
            this.ACName.Location = new System.Drawing.Point(115, 542);
            this.ACName.Margin = new System.Windows.Forms.Padding(2);
            this.ACName.Name = "ACName";
            this.ACName.Size = new System.Drawing.Size(75, 21);
            this.ACName.TabIndex = 36;
            // 
            // Employee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(948, 681);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.Authority);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.PASSWORD);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.ID);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.Account);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.SwiftCode);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.ACBank);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.ACName);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.DriverLicense);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.SSN);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.Passport);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.NickName);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.LastName);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.MiddleName);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.FirstName);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel2);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Employee";
            this.Text = "Employee";
            this.Load += new System.EventHandler(this.Employee_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.MaskedTextBox FirstName;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.MaskedTextBox MiddleName;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.MaskedTextBox LastName;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.MaskedTextBox NickName;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.MaskedTextBox BirthPlace;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.MaskedTextBox BirthDate;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.MaskedTextBox Spouse;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.MaskedTextBox Nationality;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.MaskedTextBox SSN;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.MaskedTextBox Passport;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.MaskedTextBox DriverLicense;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.MaskedTextBox SwiftCode;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.MaskedTextBox ACBank;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.MaskedTextBox Account;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.MaskedTextBox ZipCode;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.MaskedTextBox City;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.MaskedTextBox State;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.MaskedTextBox Address;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.MaskedTextBox MPnum;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.MaskedTextBox HPnum;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.MaskedTextBox WEmail;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.MaskedTextBox PEmail;
        private System.Windows.Forms.MaskedTextBox ResignDate;
        private System.Windows.Forms.MaskedTextBox HiredDate;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.MaskedTextBox Classification;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.MaskedTextBox Title;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.MaskedTextBox DepartMent;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.MaskedTextBox Division;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.MaskedTextBox EmplyWorkout;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.MaskedTextBox EmplyStatus;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.MaskedTextBox ContractNo;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Button WR;
        private System.Windows.Forms.Button Apply;
        private System.Windows.Forms.Button Remove;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.MaskedTextBox PASSWORD;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.MaskedTextBox ID;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.MaskedTextBox Authority;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button BirthPlus;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox CheckFeMale;
        private System.Windows.Forms.CheckBox CheckMale;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.MaskedTextBox ACName;
        private System.Windows.Forms.Button SpousePlus;
        private System.Windows.Forms.MaskedTextBox TwoSP;
        private System.Windows.Forms.MaskedTextBox OneSP;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.MaskedTextBox maskedTextBox3;
        private System.Windows.Forms.MaskedTextBox maskedTextBox2;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
    }
}