﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

//매개변수로받은 ID값과 문자열을통해
namespace TermProject20144675KJH
{
    public partial class WorkReport : Form
    {
        String ID;
        public WorkReport(String getid, String Date, String Info)
        {
            InitializeComponent();
            this.ID = getid;

            /*먼저, 전 폼으로부터 매개변수로 ID값과 문자열을 받았다.
             그렇다면 그값을이용해서 어떻게 근무일지를 작성하면좋을까
             1.ID값을 비교하는건의미가없다.
             2.전 폼은 해당ID사용자가 갖고있는 근무일지기록이있다.
             3.그 근무일지는 달력으로서 표시가된다.
             4.표시된 근무일지의 날짜를 선택하여 근무일지를 연다면은,
             =>해당되는 날짜의 근무기록이 출력되어야할것이다.
             =>만약 근무기록이없는날짜를 선택하여 근무일지를열었다면 빈 근무일지를 열면된다
             **그렇다면 전 폼에서는 선택한날짜의 근무일지기록을 매개변수로 주면될것이다**
             * 그 근무일지기록을 매개변수로 받아, Reports.txt를 비교하여 화면에 표시하고!
             * 수정/삭제/추가는 그 후에 손보자.
             */

            /*파일을받아 읽습니다*/
            StreamReader tsr = new StreamReader("people.txt");
            String[] tempInfo = null;

            while (tsr.Peek() >= 0)
            {
                if (tsr.ReadLine().Equals(ID))
                {
                    tsr.ReadLine();
                    //나머지 사용자 정보를 Split으로 쪼개어 추출합니다
                    tempInfo = tsr.ReadLine().Split('/');
                    
                }
            }
            tsr.Close();


            String[] DateSplit = Date.Split(',');
            this.Year.Text = DateSplit[0];
            this.Month.Text = DateSplit[1];
            this.Days.Text = DateSplit[2];

            
           String[] InfoSplit = Info.Split('/');
           this.AttanceTime.Text = InfoSplit[0];
           this.AttanceMinute.Text = InfoSplit[1];
           this.LeaveTime.Text = InfoSplit[2];
           this.LeaveMinute.Text = InfoSplit[3];
           this.ReportInfo.Text = InfoSplit[4];

            
            this.Division.Text = tempInfo[15];
            this.Position.Text = tempInfo[16];
            this.Name.Text = tempInfo[0];
            
            

           



            StreamReader sr = new StreamReader("Reports.txt");
            StreamWriter sw = new StreamWriter("Temp_Reports.txt");
            StreamWriter thisSw = new StreamWriter("Temp_Point.txt");


            
            while ((sr.Peek() >= 0))
            {
                String s = sr.ReadLine();
                if (s.Equals(ID)==true)
                {
                    thisSw.WriteLine(s);
                    while (sr.Peek() >= 0)
                    {
                        s = sr.ReadLine();
                        if (s.Equals("Name"))
                            break;
                        else
                            thisSw.WriteLine(s);
                    }
                }
                else
                    sw.WriteLine(s);
            }

            sr.Close();
            sw.Close();
            thisSw.Close();

        }

        private void WorkReport_Load(object sender, EventArgs e)
        {

        }

        private void Submit_Click(object sender, EventArgs e)
        {
            

            //구분해줬으면 그럼 추가내용을 묶어줍니다.
            String inputDate = Year.Text + "," + Month.Text + "," + Days.Text;
            String inputInfo = AttanceTime.Text + "/" + AttanceMinute.Text + "/" + LeaveTime.Text + "/" + LeaveMinute.Text + "/" + ReportInfo.Text;


            
            StreamReader sr = new StreamReader("Reports.txt");

            Boolean YorN = false;
            while (sr.Peek() >= 0)
            {
                if (sr.ReadLine().Equals(ID))
                {
                    YorN = true;
                }
            }
            sr.Close();


            if ((YorN) == true)
            {
                //묶어줍니다 !
                StreamWriter target = new StreamWriter("Reports.txt");
                StreamReader other = new StreamReader("Temp_Reports.txt");
                StreamReader point = new StreamReader("Temp_Point.txt");

                while (other.Peek()>=0)
                {
                    target.WriteLine(other.ReadLine());
                }
                target.WriteLine("Name");
                while(point.Peek()>= 0)
                {
                    target.WriteLine(point.ReadLine());
                }
                target.WriteLine(inputDate);
                target.WriteLine(inputInfo);
                target.WriteLine("Name");

                target.Close();
                other.Close();
                point.Close();
            }
            else if((YorN)==false)
            {
                //묶어줍니다 !
                StreamWriter target = new StreamWriter("Reports.txt");
                StreamReader other = new StreamReader("Temp_Reports.txt");
                StreamReader point = new StreamReader("Temp_Point.txt");
                while (other.Peek() >= 0)
                {
                    target.WriteLine(other.ReadLine());
                }
                target.WriteLine("Name");
                while (point.Peek() >= 0)
                {
                    target.WriteLine(point.ReadLine());
                }
                target.WriteLine(ID);
                target.WriteLine(inputDate);
                target.WriteLine(inputInfo);
                target.WriteLine("Name");
                target.Close();
                other.Close();
                point.Close();

            }

           

        }

        private void Modify_Click(object sender, EventArgs e)
        {
            
            //구분해줬으면 그럼 추가내용을 묶어줍니다.
            String inputDate = Year.Text + "," + Month.Text + "," + Days.Text;
            String inputInfo = AttanceTime.Text + "/" + AttanceMinute.Text + "/" + LeaveTime.Text + "/" + LeaveMinute.Text + "/" + ReportInfo.Text;


            //추린 내용에서 Date를 또 추린다
            StreamReader userR = new StreamReader("Temp_Point.txt");
            StreamWriter dateW = new StreamWriter("Temp_Point_Modi.txt");

            while ((userR.Peek() >= 0))
            {
                String s = userR.ReadLine();
                if(s.Equals(inputDate)==false)
                {
                    dateW.WriteLine(s);
                }
                else
                {
                    s = userR.ReadLine();
                }
            }

            dateW.WriteLine(inputDate);
            dateW.WriteLine(inputInfo);

            userR.Close();
            dateW.Close();
            


           
            
            //묶어줍니다 !
            StreamWriter target = new StreamWriter("Reports.txt");
            StreamReader other = new StreamReader("Temp_Reports.txt");
            StreamReader point = new StreamReader("Temp_Point_modi.txt");


            while (other.Peek() >= 0)
            {
                target.WriteLine(other.ReadLine());
            }
            target.WriteLine("Name");
            while (point.Peek() >= 0)
            {
                target.WriteLine(point.ReadLine());
            }


            target.Close();
            other.Close();
            point.Close();
        }

        private void Delete_Click(object sender, EventArgs e)
        {

            //구분해줬으면 그럼 추가내용을 묶어줍니다.
            String inputDate = Year.Text + "," + Month.Text + "," + Days.Text;
            String inputInfo = AttanceTime.Text + "/" + AttanceMinute.Text + "/" + LeaveTime.Text + "/" + LeaveMinute.Text + "/" + ReportInfo.Text;


            //묶어줍니다 !
            StreamWriter target = new StreamWriter("Reports.txt");
            StreamReader other = new StreamReader("Temp_Reports.txt");
            StreamReader point = new StreamReader("Temp_Point.txt");


            while (other.Peek() >= 0)
            {
                target.WriteLine(other.ReadLine());
            }
            target.WriteLine("Name");
            while (point.Peek() >= 0)
            {
                String s = point.ReadLine();
                if (s.Equals(inputDate)==false)
                    target.WriteLine(s);
                else
                    s = point.ReadLine();
                
            }
 

            target.Close();
            other.Close();
            point.Close();

        }
    }
}
