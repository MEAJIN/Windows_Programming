﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace TermProject20144675KJH
{
    public partial class Calen : Form
    {
        String s = "";
        public Calen()
        {
            InitializeComponent();
        }

        private void Calen_Load(object sender, EventArgs e)
        {

        }
        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            String[] str = e.Start.ToShortDateString().Split('-');
            
            s += str[0];
            s += str[1];
            s += str[2];

            textBox1.Text = s;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            StreamWriter sw = new StreamWriter("BirthDay.txt");
            sw.WriteLine(s);
            sw.Close();
            this.Close();

        }

        
    }
}
