﻿namespace TermProject20144675KJH
{
    partial class Manager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Person = new System.Windows.Forms.TextBox();
            this.userName = new System.Windows.Forms.TextBox();
            this.Authority = new System.Windows.Forms.ComboBox();
            this.Search = new System.Windows.Forms.Button();
            this.Change = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "Search Person";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "User Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 112);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "Authority";
            // 
            // Person
            // 
            this.Person.Location = new System.Drawing.Point(117, 49);
            this.Person.Name = "Person";
            this.Person.Size = new System.Drawing.Size(100, 21);
            this.Person.TabIndex = 3;
            this.Person.TextChanged += new System.EventHandler(this.Person_TextChanged);
            // 
            // userName
            // 
            this.userName.Location = new System.Drawing.Point(117, 79);
            this.userName.Name = "userName";
            this.userName.Size = new System.Drawing.Size(100, 21);
            this.userName.TabIndex = 4;
            // 
            // Authority
            // 
            this.Authority.FormattingEnabled = true;
            this.Authority.Items.AddRange(new object[] {
            "Employee",
            "Employer",
            "Manager"});
            this.Authority.Location = new System.Drawing.Point(117, 112);
            this.Authority.Name = "Authority";
            this.Authority.Size = new System.Drawing.Size(100, 20);
            this.Authority.TabIndex = 5;
            // 
            // Search
            // 
            this.Search.Location = new System.Drawing.Point(223, 47);
            this.Search.Name = "Search";
            this.Search.Size = new System.Drawing.Size(75, 23);
            this.Search.TabIndex = 6;
            this.Search.Text = "Search";
            this.Search.UseVisualStyleBackColor = true;
            this.Search.Click += new System.EventHandler(this.Search_Click);
            // 
            // Change
            // 
            this.Change.Location = new System.Drawing.Point(94, 138);
            this.Change.Name = "Change";
            this.Change.Size = new System.Drawing.Size(145, 23);
            this.Change.TabIndex = 7;
            this.Change.Text = "Change Authority";
            this.Change.UseVisualStyleBackColor = true;
            this.Change.Click += new System.EventHandler(this.Change_Click);
            // 
            // Manager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(320, 205);
            this.Controls.Add(this.Change);
            this.Controls.Add(this.Search);
            this.Controls.Add(this.Authority);
            this.Controls.Add(this.userName);
            this.Controls.Add(this.Person);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Manager";
            this.Text = "r";
            this.Load += new System.EventHandler(this.Manager_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Person;
        private System.Windows.Forms.TextBox userName;
        private System.Windows.Forms.ComboBox Authority;
        private System.Windows.Forms.Button Search;
        private System.Windows.Forms.Button Change;
    }
}