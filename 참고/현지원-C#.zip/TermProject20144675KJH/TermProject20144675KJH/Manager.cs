﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;



namespace TermProject20144675KJH
{
    public partial class Manager : Form
    {
        
        public Manager()
        {
            InitializeComponent();


        }

        private void Person_TextChanged(object sender, EventArgs e)
        {

        }

        private void Search_Click(object sender, EventArgs e)
        {
            String[] str=null;

            StreamReader sr = new StreamReader("people.txt");
            while (sr.Peek() >= 0)
            {
                String s = sr.ReadLine();
                if(s.Equals(Person.Text))
                {
                    this.Authority.Text = sr.ReadLine();
                    str = sr.ReadLine().Split('/');
                    break;
                }
            }
            sr.Close();

            this.userName.Text = str[0];
        }
        private void Manager_Load(object sender, EventArgs e)
        {
        }
        private void Change_Click(object sender, EventArgs e)
        {
            /*파일을읽고 수정전 부분을 제외한 모든것을 TEMP 빈공간 파일에 넣고
                다마친후에, Person파일에 넣고, 수정후 내용을 추가하면
                수정의 완성*/
            StreamReader sr = new StreamReader("people.txt");
            //FileMode중 append는 이어쓰기. 파일이 없으면 만든다.
            StreamWriter sw = new StreamWriter("temp.txt");

            String str = "";

            //수정할 ID( ID, 권한, 직원내용 ) 을 제외한 다른 ID들을 TEMP파일에 백업시켜줍니다.
            while (sr.Peek() >= 0)
            {
                String s = sr.ReadLine();
                if (Person.Text.Equals(s))
                {
                    sr.ReadLine();
                    str=sr.ReadLine();
                }
                else
                {
                    sw.WriteLine(s);
                }

            }

            sr.Close();
            sw.Close();

            //그리고 백업시켜준파일을 기존 people.txt에 덮어쓰기합니다.
            System.IO.File.Copy("temp.txt", "people.txt", true);

            //마지막으로 다시 people.txt를 열어서 수정할 내용을 입력하면 수정작업의 완성입니다.
            FileStream addfs = new FileStream("people.txt", FileMode.Append, FileAccess.Write);
            //FileMode중 append는 이어쓰기. 파일이 없으면 만든다.
            StreamWriter addsw = new StreamWriter(addfs, System.Text.Encoding.UTF8);

            addsw.WriteLine(Person.Text);
            addsw.WriteLine(Authority.Text);
            addsw.WriteLine(str);

            addsw.Close();
            addfs.Close();
        }
    }
}
