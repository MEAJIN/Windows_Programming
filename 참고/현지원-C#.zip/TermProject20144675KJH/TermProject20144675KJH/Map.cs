﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace TermProject20144675KJH
{
    public partial class Map : Form
    {
        String s="";
        public Map()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            StreamWriter sw = new StreamWriter("Map.txt");
            if (RB1.Checked == true)
                s = RB1.Text;
            else if (RB2.Checked == true)
                s = RB2.Text;
            else if (RB3.Checked == true)
                s = RB3.Text;
            else if (RB4.Checked == true)
                s = RB4.Text;
            else if (RB5.Checked == true)
                s = RB5.Text;


            sw.WriteLine(s);
            sw.Close();
            this.Close();
        }

        private void Map_Load(object sender, EventArgs e)
        {

        }
    }
}
