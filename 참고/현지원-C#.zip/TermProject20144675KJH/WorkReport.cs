﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace TermProject20144675KJH
{
    public partial class WorkReport : Form
    {
        public WorkReport(String name,String year,String month, String days)
        {
            InitializeComponent();
            this.Year.Text = year;
            this.Month.Text = month;
            this.Days.Text = days;

            StreamReader sr = new StreamReader("Reports.txt");

            String[] info;

            while(sr.Peek()>=0)
            {
                if(sr.ReadLine().Equals(name))
                {
                    info = sr.ReadLine().Split('/');
                }
            }
        }

        private void WorkReport_Load(object sender, EventArgs e)
        {

        }
    }
}
