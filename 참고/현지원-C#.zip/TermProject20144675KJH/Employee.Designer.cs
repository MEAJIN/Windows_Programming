﻿namespace TermProject20144675KJH
{
    partial class Employee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.FirstName = new System.Windows.Forms.MaskedTextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.MiddleName = new System.Windows.Forms.MaskedTextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.LastName = new System.Windows.Forms.MaskedTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.NickName = new System.Windows.Forms.MaskedTextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.BirthPlace = new System.Windows.Forms.MaskedTextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.BirthDate = new System.Windows.Forms.MaskedTextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.Spouse = new System.Windows.Forms.MaskedTextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.Nationality = new System.Windows.Forms.MaskedTextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.SSN = new System.Windows.Forms.MaskedTextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.Passport = new System.Windows.Forms.MaskedTextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.DriverLicense = new System.Windows.Forms.MaskedTextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.SwiftCode = new System.Windows.Forms.MaskedTextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.ACBank = new System.Windows.Forms.MaskedTextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.ACName = new System.Windows.Forms.MaskedTextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.Account = new System.Windows.Forms.MaskedTextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.ZipCode = new System.Windows.Forms.MaskedTextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.City = new System.Windows.Forms.MaskedTextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.State = new System.Windows.Forms.MaskedTextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.Address = new System.Windows.Forms.MaskedTextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.MPnum = new System.Windows.Forms.MaskedTextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.HPnum = new System.Windows.Forms.MaskedTextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.WEmail = new System.Windows.Forms.MaskedTextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.PEmail = new System.Windows.Forms.MaskedTextBox();
            this.ResignDate = new System.Windows.Forms.MaskedTextBox();
            this.HiredDate = new System.Windows.Forms.MaskedTextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.Classification = new System.Windows.Forms.MaskedTextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.Title = new System.Windows.Forms.MaskedTextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.DepartMent = new System.Windows.Forms.MaskedTextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.Division = new System.Windows.Forms.MaskedTextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.EmplyWorkout = new System.Windows.Forms.MaskedTextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.EmplyStatus = new System.Windows.Forms.MaskedTextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.ContractNo = new System.Windows.Forms.MaskedTextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.WR = new System.Windows.Forms.Button();
            this.Apply = new System.Windows.Forms.Button();
            this.Remove = new System.Windows.Forms.Button();
            this.Save = new System.Windows.Forms.Button();
            this.label46 = new System.Windows.Forms.Label();
            this.PASSWORD = new System.Windows.Forms.MaskedTextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.ID = new System.Windows.Forms.MaskedTextBox();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.Authority = new System.Windows.Forms.MaskedTextBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Personal Info";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 179);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 374);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(221, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "Place and Birth Date";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 572);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "Family Info";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 684);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 24);
            this.label5.TabIndex = 4;
            this.label5.Text = "ID";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 818);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 24);
            this.label6.TabIndex = 5;
            this.label6.Text = "Account";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(371, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(138, 24);
            this.label7.TabIndex = 6;
            this.label7.Text = "Contact Info";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(371, 59);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(139, 24);
            this.label8.TabIndex = 7;
            this.label8.Text = "Address Info";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(371, 254);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(128, 24);
            this.label9.TabIndex = 8;
            this.label9.Text = "Phone Num";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(371, 377);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(108, 24);
            this.label10.TabIndex = 9;
            this.label10.Text = "Email Info";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(371, 501);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(93, 24);
            this.label11.TabIndex = 10;
            this.label11.Text = "Job Info";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(385, 537);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(118, 24);
            this.label12.TabIndex = 11;
            this.label12.Text = "Hired Date";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(385, 575);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(133, 24);
            this.label13.TabIndex = 12;
            this.label13.Text = "Resign Date";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(371, 614);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(92, 24);
            this.label14.TabIndex = 13;
            this.label14.Text = "Position";
            // 
            // FirstName
            // 
            this.FirstName.Location = new System.Drawing.Point(170, 213);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(136, 35);
            this.FirstName.TabIndex = 14;
            this.FirstName.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.FirstName_MaskInputRejected);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(26, 216);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(110, 24);
            this.label15.TabIndex = 15;
            this.label15.Text = "FirstName";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(26, 257);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(132, 24);
            this.label16.TabIndex = 17;
            this.label16.Text = "MiddleName";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // MiddleName
            // 
            this.MiddleName.Location = new System.Drawing.Point(170, 254);
            this.MiddleName.Name = "MiddleName";
            this.MiddleName.Size = new System.Drawing.Size(136, 35);
            this.MiddleName.TabIndex = 16;
            this.MiddleName.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MiddleName_MaskInputRejected);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(26, 298);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(111, 24);
            this.label17.TabIndex = 19;
            this.label17.Text = "LastName";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // LastName
            // 
            this.LastName.Location = new System.Drawing.Point(170, 295);
            this.LastName.Name = "LastName";
            this.LastName.Size = new System.Drawing.Size(136, 35);
            this.LastName.TabIndex = 18;
            this.LastName.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.LastName_MaskInputRejected);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(26, 339);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(109, 24);
            this.label18.TabIndex = 21;
            this.label18.Text = "NickName";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // NickName
            // 
            this.NickName.Location = new System.Drawing.Point(170, 336);
            this.NickName.Name = "NickName";
            this.NickName.Size = new System.Drawing.Size(136, 35);
            this.NickName.TabIndex = 20;
            this.NickName.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.NickName_MaskInputRejected);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(26, 462);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(120, 24);
            this.label19.TabIndex = 25;
            this.label19.Text = "Birth Place";
            // 
            // BirthPlace
            // 
            this.BirthPlace.Location = new System.Drawing.Point(170, 459);
            this.BirthPlace.Name = "BirthPlace";
            this.BirthPlace.Size = new System.Drawing.Size(136, 35);
            this.BirthPlace.TabIndex = 24;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(26, 421);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(111, 24);
            this.label20.TabIndex = 23;
            this.label20.Text = "Birth Date";
            // 
            // BirthDate
            // 
            this.BirthDate.Location = new System.Drawing.Point(170, 418);
            this.BirthDate.Name = "BirthDate";
            this.BirthDate.Size = new System.Drawing.Size(136, 35);
            this.BirthDate.TabIndex = 22;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(26, 612);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(88, 24);
            this.label21.TabIndex = 29;
            this.label21.Text = "Spouse";
            // 
            // Spouse
            // 
            this.Spouse.Location = new System.Drawing.Point(170, 609);
            this.Spouse.Name = "Spouse";
            this.Spouse.Size = new System.Drawing.Size(136, 35);
            this.Spouse.TabIndex = 28;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(26, 541);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(114, 24);
            this.label22.TabIndex = 27;
            this.label22.Text = "Nationality";
            // 
            // Nationality
            // 
            this.Nationality.Location = new System.Drawing.Point(170, 538);
            this.Nationality.Name = "Nationality";
            this.Nationality.Size = new System.Drawing.Size(136, 35);
            this.Nationality.TabIndex = 26;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(26, 749);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(54, 24);
            this.label23.TabIndex = 33;
            this.label23.Text = "SSN";
            // 
            // SSN
            // 
            this.SSN.Location = new System.Drawing.Point(188, 746);
            this.SSN.Name = "SSN";
            this.SSN.Size = new System.Drawing.Size(136, 35);
            this.SSN.TabIndex = 32;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(26, 708);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(101, 24);
            this.label24.TabIndex = 31;
            this.label24.Text = "Passport";
            // 
            // Passport
            // 
            this.Passport.Location = new System.Drawing.Point(188, 705);
            this.Passport.Name = "Passport";
            this.Passport.Size = new System.Drawing.Size(136, 35);
            this.Passport.TabIndex = 30;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(26, 790);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(155, 24);
            this.label25.TabIndex = 35;
            this.label25.Text = "Driver License";
            // 
            // DriverLicense
            // 
            this.DriverLicense.Location = new System.Drawing.Point(188, 787);
            this.DriverLicense.Name = "DriverLicense";
            this.DriverLicense.Size = new System.Drawing.Size(136, 35);
            this.DriverLicense.TabIndex = 34;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(26, 940);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(126, 24);
            this.label26.TabIndex = 41;
            this.label26.Text = "Swift Code";
            // 
            // SwiftCode
            // 
            this.SwiftCode.Location = new System.Drawing.Point(188, 937);
            this.SwiftCode.Name = "SwiftCode";
            this.SwiftCode.Size = new System.Drawing.Size(136, 35);
            this.SwiftCode.TabIndex = 40;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(26, 899);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(97, 24);
            this.label27.TabIndex = 39;
            this.label27.Text = "AC Bank";
            // 
            // ACBank
            // 
            this.ACBank.Location = new System.Drawing.Point(188, 896);
            this.ACBank.Name = "ACBank";
            this.ACBank.Size = new System.Drawing.Size(136, 35);
            this.ACBank.TabIndex = 38;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(26, 858);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(105, 24);
            this.label28.TabIndex = 37;
            this.label28.Text = "AC Name";
            // 
            // ACName
            // 
            this.ACName.Location = new System.Drawing.Point(188, 855);
            this.ACName.Name = "ACName";
            this.ACName.Size = new System.Drawing.Size(136, 35);
            this.ACName.TabIndex = 36;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(26, 981);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(119, 24);
            this.label29.TabIndex = 43;
            this.label29.Text = "Account #";
            // 
            // Account
            // 
            this.Account.Location = new System.Drawing.Point(188, 978);
            this.Account.Name = "Account";
            this.Account.Size = new System.Drawing.Size(136, 35);
            this.Account.TabIndex = 42;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(385, 216);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(96, 24);
            this.label30.TabIndex = 51;
            this.label30.Text = "ZipCode";
            // 
            // ZipCode
            // 
            this.ZipCode.Location = new System.Drawing.Point(565, 216);
            this.ZipCode.Name = "ZipCode";
            this.ZipCode.Size = new System.Drawing.Size(142, 35);
            this.ZipCode.TabIndex = 50;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(385, 175);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(49, 24);
            this.label31.TabIndex = 49;
            this.label31.Text = "City";
            // 
            // City
            // 
            this.City.Location = new System.Drawing.Point(565, 175);
            this.City.Name = "City";
            this.City.Size = new System.Drawing.Size(142, 35);
            this.City.TabIndex = 48;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(385, 134);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(66, 24);
            this.label32.TabIndex = 47;
            this.label32.Text = "State";
            // 
            // State
            // 
            this.State.Location = new System.Drawing.Point(565, 134);
            this.State.Name = "State";
            this.State.Size = new System.Drawing.Size(142, 35);
            this.State.TabIndex = 46;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(385, 93);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(93, 24);
            this.label33.TabIndex = 45;
            this.label33.Text = "Address";
            // 
            // Address
            // 
            this.Address.Location = new System.Drawing.Point(565, 93);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(142, 35);
            this.Address.TabIndex = 44;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(385, 339);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(170, 24);
            this.label34.TabIndex = 55;
            this.label34.Text = "Mobile P.num 1";
            // 
            // MPnum
            // 
            this.MPnum.Location = new System.Drawing.Point(565, 339);
            this.MPnum.Name = "MPnum";
            this.MPnum.Size = new System.Drawing.Size(142, 35);
            this.MPnum.TabIndex = 54;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(385, 298);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(145, 24);
            this.label35.TabIndex = 53;
            this.label35.Text = "Home P.Num";
            // 
            // HPnum
            // 
            this.HPnum.Location = new System.Drawing.Point(565, 298);
            this.HPnum.Name = "HPnum";
            this.HPnum.Size = new System.Drawing.Size(142, 35);
            this.HPnum.TabIndex = 52;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(386, 458);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(135, 24);
            this.label36.TabIndex = 59;
            this.label36.Text = "Work E-Mail";
            // 
            // WEmail
            // 
            this.WEmail.Location = new System.Drawing.Point(566, 458);
            this.WEmail.Name = "WEmail";
            this.WEmail.Size = new System.Drawing.Size(142, 35);
            this.WEmail.TabIndex = 58;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(386, 417);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(171, 24);
            this.label37.TabIndex = 57;
            this.label37.Text = "Personal E-Mail";
            // 
            // PEmail
            // 
            this.PEmail.Location = new System.Drawing.Point(566, 417);
            this.PEmail.Name = "PEmail";
            this.PEmail.Size = new System.Drawing.Size(142, 35);
            this.PEmail.TabIndex = 56;
            // 
            // ResignDate
            // 
            this.ResignDate.Location = new System.Drawing.Point(527, 572);
            this.ResignDate.Name = "ResignDate";
            this.ResignDate.Size = new System.Drawing.Size(136, 35);
            this.ResignDate.TabIndex = 61;
            // 
            // HiredDate
            // 
            this.HiredDate.Location = new System.Drawing.Point(527, 531);
            this.HiredDate.Name = "HiredDate";
            this.HiredDate.Size = new System.Drawing.Size(136, 35);
            this.HiredDate.TabIndex = 60;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(386, 776);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(142, 24);
            this.label38.TabIndex = 69;
            this.label38.Text = "Classification";
            // 
            // Classification
            // 
            this.Classification.Location = new System.Drawing.Point(553, 765);
            this.Classification.Name = "Classification";
            this.Classification.Size = new System.Drawing.Size(136, 35);
            this.Classification.TabIndex = 68;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(386, 735);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(53, 24);
            this.label39.TabIndex = 67;
            this.label39.Text = "Title";
            // 
            // Title
            // 
            this.Title.Location = new System.Drawing.Point(553, 724);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(136, 35);
            this.Title.TabIndex = 66;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(386, 694);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(129, 24);
            this.label40.TabIndex = 65;
            this.label40.Text = "Department";
            // 
            // DepartMent
            // 
            this.DepartMent.Location = new System.Drawing.Point(553, 683);
            this.DepartMent.Name = "DepartMent";
            this.DepartMent.Size = new System.Drawing.Size(136, 35);
            this.DepartMent.TabIndex = 64;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(386, 653);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(86, 24);
            this.label41.TabIndex = 63;
            this.label41.Text = "Division";
            // 
            // Division
            // 
            this.Division.Location = new System.Drawing.Point(553, 642);
            this.Division.Name = "Division";
            this.Division.Size = new System.Drawing.Size(136, 35);
            this.Division.TabIndex = 62;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(386, 899);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(165, 24);
            this.label42.TabIndex = 75;
            this.label42.Text = "Emply Workout";
            // 
            // EmplyWorkout
            // 
            this.EmplyWorkout.Location = new System.Drawing.Point(553, 888);
            this.EmplyWorkout.Name = "EmplyWorkout";
            this.EmplyWorkout.Size = new System.Drawing.Size(136, 35);
            this.EmplyWorkout.TabIndex = 74;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(386, 858);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(145, 24);
            this.label43.TabIndex = 73;
            this.label43.Text = "Emply Status";
            // 
            // EmplyStatus
            // 
            this.EmplyStatus.Location = new System.Drawing.Point(553, 847);
            this.EmplyStatus.Name = "EmplyStatus";
            this.EmplyStatus.Size = new System.Drawing.Size(136, 35);
            this.EmplyStatus.TabIndex = 72;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(386, 817);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(135, 24);
            this.label44.TabIndex = 71;
            this.label44.Text = "Contract No";
            // 
            // ContractNo
            // 
            this.ContractNo.Location = new System.Drawing.Point(553, 806);
            this.ContractNo.Name = "ContractNo";
            this.ContractNo.Size = new System.Drawing.Size(136, 35);
            this.ContractNo.TabIndex = 70;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(762, 9);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(82, 24);
            this.label45.TabIndex = 76;
            this.label45.Text = "Picture";
            // 
            // WR
            // 
            this.WR.Location = new System.Drawing.Point(766, 666);
            this.WR.Name = "WR";
            this.WR.Size = new System.Drawing.Size(303, 42);
            this.WR.TabIndex = 77;
            this.WR.Text = "Change WorkReport";
            this.WR.UseVisualStyleBackColor = true;
            this.WR.Click += new System.EventHandler(this.WorkReport_Click);
            // 
            // Apply
            // 
            this.Apply.Location = new System.Drawing.Point(766, 718);
            this.Apply.Name = "Apply";
            this.Apply.Size = new System.Drawing.Size(405, 42);
            this.Apply.TabIndex = 78;
            this.Apply.Text = "Apply Change - Personal Info";
            this.Apply.UseVisualStyleBackColor = true;
            this.Apply.Click += new System.EventHandler(this.Apply_Click);
            // 
            // Remove
            // 
            this.Remove.Location = new System.Drawing.Point(766, 770);
            this.Remove.Name = "Remove";
            this.Remove.Size = new System.Drawing.Size(405, 42);
            this.Remove.TabIndex = 79;
            this.Remove.Text = "Remove Info - Personal Info";
            this.Remove.UseVisualStyleBackColor = true;
            // 
            // Save
            // 
            this.Save.Location = new System.Drawing.Point(766, 820);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(405, 42);
            this.Save.TabIndex = 80;
            this.Save.Text = "Save new Info - Personal Infio";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(26, 76);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(137, 24);
            this.label46.TabIndex = 84;
            this.label46.Text = "PASSWORD";
            // 
            // PASSWORD
            // 
            this.PASSWORD.Location = new System.Drawing.Point(170, 73);
            this.PASSWORD.Name = "PASSWORD";
            this.PASSWORD.Size = new System.Drawing.Size(136, 35);
            this.PASSWORD.TabIndex = 83;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(26, 35);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(29, 24);
            this.label47.TabIndex = 82;
            this.label47.Text = "ID";
            // 
            // ID
            // 
            this.ID.Location = new System.Drawing.Point(170, 32);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(136, 35);
            this.ID.TabIndex = 81;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(26, 503);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(84, 24);
            this.label48.TabIndex = 85;
            this.label48.Text = "Gender";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(26, 117);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(102, 24);
            this.label49.TabIndex = 87;
            this.label49.Text = "Authority";
            // 
            // Authority
            // 
            this.Authority.Location = new System.Drawing.Point(170, 114);
            this.Authority.Name = "Authority";
            this.Authority.Size = new System.Drawing.Size(136, 35);
            this.Authority.TabIndex = 86;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(766, 625);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            2020,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            1990,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 35);
            this.numericUpDown1.TabIndex = 88;
            this.numericUpDown1.Value = new decimal(new int[] {
            1990,
            0,
            0,
            0});
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.comboBox1.Location = new System.Drawing.Point(892, 624);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 32);
            this.comboBox1.TabIndex = 90;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(766, 245);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(502, 374);
            this.panel1.TabIndex = 91;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint_1);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31"});
            this.comboBox2.Location = new System.Drawing.Point(1019, 624);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 32);
            this.comboBox2.TabIndex = 92;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // Employee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1485, 1082);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.Authority);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.PASSWORD);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.ID);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.Remove);
            this.Controls.Add(this.Apply);
            this.Controls.Add(this.WR);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.EmplyWorkout);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.EmplyStatus);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.ContractNo);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.Classification);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.Title);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.DepartMent);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.Division);
            this.Controls.Add(this.ResignDate);
            this.Controls.Add(this.HiredDate);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.WEmail);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.PEmail);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.MPnum);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.HPnum);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.ZipCode);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.City);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.State);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.Account);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.SwiftCode);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.ACBank);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.ACName);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.DriverLicense);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.SSN);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.Passport);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.Spouse);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.Nationality);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.BirthPlace);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.BirthDate);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.NickName);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.LastName);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.MiddleName);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.FirstName);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Employee";
            this.Text = "Employee";
            this.Load += new System.EventHandler(this.Employee_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.MaskedTextBox FirstName;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.MaskedTextBox MiddleName;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.MaskedTextBox LastName;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.MaskedTextBox NickName;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.MaskedTextBox BirthPlace;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.MaskedTextBox BirthDate;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.MaskedTextBox Spouse;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.MaskedTextBox Nationality;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.MaskedTextBox SSN;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.MaskedTextBox Passport;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.MaskedTextBox DriverLicense;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.MaskedTextBox SwiftCode;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.MaskedTextBox ACBank;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.MaskedTextBox ACName;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.MaskedTextBox Account;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.MaskedTextBox ZipCode;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.MaskedTextBox City;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.MaskedTextBox State;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.MaskedTextBox Address;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.MaskedTextBox MPnum;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.MaskedTextBox HPnum;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.MaskedTextBox WEmail;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.MaskedTextBox PEmail;
        private System.Windows.Forms.MaskedTextBox ResignDate;
        private System.Windows.Forms.MaskedTextBox HiredDate;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.MaskedTextBox Classification;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.MaskedTextBox Title;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.MaskedTextBox DepartMent;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.MaskedTextBox Division;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.MaskedTextBox EmplyWorkout;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.MaskedTextBox EmplyStatus;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.MaskedTextBox ContractNo;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Button WR;
        private System.Windows.Forms.Button Apply;
        private System.Windows.Forms.Button Remove;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.MaskedTextBox PASSWORD;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.MaskedTextBox ID;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.MaskedTextBox Authority;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox comboBox2;
    }
}