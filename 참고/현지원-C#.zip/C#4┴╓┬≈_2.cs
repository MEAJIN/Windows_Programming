﻿//20174069 현지원
using System;

class Complex
{
    public double real; //실수부
    public double image; //하수부

    //한 개의 실수를 받아 초기화 하는 생성자
    public Complex(double real)
    {
        this.real = real;
        this.image = 0.0;
    }

    //두 개의 실수를 받아 초기화 하는 생성자
    public Complex(double real, double image)
    {
        this.real = real;
        this.image = image;
    }

    //하나의 복소수를 실수부, 허수부 형태로 변환하는 ToString() 메소드
    public override string ToString()
    {
        return "(" + real + " + " + image + "i" + ")";
    }

    public double Real
    {
        get { return real; }
        set { real = value; }
    }

    public double Imag
    {
        get { return image; }
        set { image = value; }
    }

    //사칙연산 연산자 중복 정의
    public static Complex operator +(Complex f1, Complex f2)
    {
        double r = f1.real + f2.real;
        double i = f1.image + f2.image;
        return new Complex(r, i);
    }

    public static Complex operator -(Complex f1, Complex f2)
    {
        double r = f1.real - f2.real;
        double i = f1.image - f2.image;
        return new Complex(r, i);
    }

    public static Complex operator *(Complex f1, Complex f2)
    {
        double r = (f1.real * f2.real) - (f1.image * f2.image);
        double i = (f1.real * f2.image) + (f1.image * f2.real);
        return new Complex(r, i);
    }

    public static Complex operator /(Complex f1, Complex f2)
    {
        double r = (((f1.real * f2.real) + (f1.image * f2.image)) / ((f2.real * f2.real) + (f2.image * f2.image)));
        double i = (((f1.image * f2.real) - (f1.real * f2.image)) / ((f2.real * f2.real) + (f2.image * f2.image)));
        return new Complex(r, i);
    }

    public void AddComplex(Complex f1, Complex f2)
    {
        Console.WriteLine("f1 + f2 = " + (f1 + f2));
    }

    public void SubComplex(Complex f1, Complex f2)
    {
        Console.WriteLine("f1 - f2 = " + (f1 - f2));
    }

    public void MulComplex(Complex f1, Complex f2)
    {
        Console.WriteLine("f1 * f2 = " + (f1 * f2));
    }

    public void DivComplex(Complex f1, Complex f2)
    {
        Console.WriteLine("f1 ÷ f2 = " + (f1 / f2));
    }
}

class Program
{
    static void Main(string[] args)
    {
        Complex f1, f2; //복소수를 나타낼 클래스 f1, f2 선언

        //생성자를 이용하여 복소수 f1을 5 + 6i 로 초기화
        f1 = new Complex(5.0, 6.0);
        //생성자를 이용하여 복소수 f2를 2 + 4i 로 초기화 
        f2 = new Complex(2.0, 4.0);

        //f1, f2를 복소수의 형태로 출력
        Console.WriteLine("f1 : " + f1.ToString());
        Console.WriteLine("f2 : " + f2.ToString());

        //복소수 f1, f2의 사칙연산 결과를 출력
        f2.AddComplex(f1, f2);
        f2.SubComplex(f1, f2);
        f2.MulComplex(f1, f2);
        f2.DivComplex(f1, f2);
    }
}