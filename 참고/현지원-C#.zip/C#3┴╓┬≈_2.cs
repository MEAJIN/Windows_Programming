﻿using System;

//20174069 현지원
namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            string user;
            bool result = false;

            //배열 생성
            String[] str = { "computer", "science", "ENGINEERING", "android", "VISUALSTUDIO" };

            Console.Write("저장된 배열 = ");
            foreach (string s in str)
            {
                Console.Write("\"" + s + "\", ");
            }

            //사용자에게 단어 입력 받기
            Console.Write("\n검색할 단어를 입력하세요 : ");
            user = Console.ReadLine();

            //for-each문으로 배열 탐색
            foreach (string s in str)
            {
                if (user.Equals(s, StringComparison.OrdinalIgnoreCase))
                {
                    //.Equals 메서드를 사용하여 대소문자 구분 없이 비교
                    result = true;
                    break;
                }
                else
                {
                    result = false;
                }
            }

            //결과 출력
            if (result == true)
            {
                Console.WriteLine("\n검색한 단어 '" + user + "'" + "(이)가 배열에 있습니다.");
            }

            else
            {
                Console.WriteLine("\n검색한 단어 '" + user + "'" + "(이)가 배열에 없습니다.");
            }
        }
    }
}
