﻿using System;

namespace ConsoleApp6
{
    class Holsu
    {
        //내부의 정수 배열 데이터
        private int[] odd = new int[100];

        //인덱서 정의
        public int this[int index]
        {
            get { return odd[index]; }
            set { odd[index] = value; }
        }
    }

    class Jjaksu
    {
        //내부의 정수 배열 데이터
        private int[] even = new int[100];
        
        //인덱서 정의
        public int this[int index]
        {
            get { return even[index]; }
            set { even[index] = value; }
        }
    }

    class Sosu
    {
        //내부의 정수 배열 데이터
        private int[] prime = new int[100];

        //인덱서 정의
        public int this[int index]
        {
            get { return prime[index]; }
            set { prime[index] = value; }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Holsu holsu = new Holsu();
            Jjaksu jjaksu = new Jjaksu();
            Sosu sosu = new Sosu();

            for (int i = 0; i < 100; i++) {
                if(i % 2 == 0) //짝수
                {
                    jjaksu[i] = i; //짝수 인덱서 set 사용
                }

                else //홀수
                {
                    holsu[i] = i; //홀수 인덱서 set 사용
                }
            }

            //소수 
            bool check = true;
            for (int i = 2; i <= 100; i++)
            {
                for (int j = 2; j < i; j++)
                {
                    if ((i % j) == 0)
                    {
                        check = false;
                    }
                }

                if (check == true)
                {
                    sosu[i] = i; //소수 인덱서 set 사용
                }
                check = true;
            }

            Console.WriteLine("Holsu[i] 값 : ");
            for (int i = 0; i < 100; i++) {
                if (i % 2 != 0) 
                    Console.Write(holsu[i] + ", ");               
            }

            Console.WriteLine("\n\n");
            Console.WriteLine("Jjaksu[i] 값 : ");
            for (int i = 2; i < 100; i++) {
                if (i % 2 == 0) 
                    Console.Write(jjaksu[i] + ", ");
            }

            Console.WriteLine("\n\n");
            Console.WriteLine("sosu[i] 값 : ");
            for (int i = 2; i <= 100; i++)
            {
                for (int j = 2; j < i; j++)
                {
                    if ((i % j) == 0)
                    {
                        check = false;
                    }
                }

                if (check == true)
                {
                    Console.Write(sosu[i] + ", ");
                }
                check = true;
            }
            Console.WriteLine("\n\n");
        }
    }
}
