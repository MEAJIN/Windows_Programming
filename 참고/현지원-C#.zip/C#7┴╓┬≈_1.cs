﻿//20174069 현지원
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    class Student
    {
        //1-1)접근지정자가 private인 학번, 이름, 성별, 생년월일 필드를 정의
        private int number;
        private string name;
        private string gender;
        private int birth;

        //1-2) 프로퍼티를 이용하여 필드에 접근 및 수정이 가능하게 함
        public int Number
        {
            get { return number; }
            set { number = value; }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Gender
        {
            get { return gender; }
            set { gender = value; }
        }

        public int Birth
        {
            get { return birth; }
            set { birth = value; }
        }

        //1-3) 학생의 정보를 출력하는 메소드
        public void print()
        {
            Console.WriteLine(number + " " + name + " " + gender + " " + birth);
        }

        static void Main(string[] args)
        {
            int student_num = 0;
            string student_info;
            string[] info_tmp;

            do
            {
                Console.Write("학생 수를 입력하시오 (0 : 종료) : ");
                student_num = int.Parse(Console.ReadLine());

                //최소 4명이기 때문에, 입력값이 4이하이면 break
                if (student_num < 4)
                {
                    Console.WriteLine("최소 4명 입력!");
                    break;
                }

                //객체 배열 생성
                Student[] std;
                std = new Student[student_num];

                for (int i = 0; i < student_num; i++)
                {
                    std[i] = new Student();
                    Console.Write("학생의 정보를 입력하시오 <학번 이름 성별 생년월일> : ");
                    student_info = Console.ReadLine();

                    //공백을 기준으로 문자열을 나눈 후, 각 필드에 저장
                    info_tmp = student_info.Split(' ');
                    std[i].number = int.Parse(info_tmp[0]);
                    std[i].name = info_tmp[1];
                    std[i].gender = info_tmp[2];
                    std[i].birth = int.Parse(info_tmp[3]);
                }

                Console.Write("수정할 학생의 학번을 입력하시오 : ");
                int num = int.Parse(Console.ReadLine());

                Console.WriteLine("수정 전 정보 : ");
                std[num - 1].print(); //학번은 1부터 시작, 인덱스는 0부터 시작하기 때문에 num-1

                //1-5) 프로퍼티를 통하여 특정 학생의 정보를 수정
                Console.Write("학생의 이름을 입력하시오 : ");
                std[num - 1].Name = Console.ReadLine();

                Console.Write("학생의 성별을 입력하시오 : ");
                std[num - 1].Gender = Console.ReadLine();


                Console.Write("학생의 생년월일을 입력하시오 : ");
                std[num - 1].Birth = int.Parse(Console.ReadLine());

                //수정한 정보를 출력
                Console.WriteLine("수정 후 정보 : ");
                std[num - 1].print();

            } while (student_num == 0); //사용자가 0을 입력하면 종료
        }
    }
}
