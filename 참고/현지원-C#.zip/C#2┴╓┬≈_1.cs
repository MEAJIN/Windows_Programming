﻿//20174069 현지원
using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            String name = " \n";
            String[] user_name = { "둘리", "또치", "마이콜" };
            Console.Write("찾고자 하는 이름을 입력하시오 : ");
            name = Console.ReadLine();

            //foreach문
            foreach (String s in user_name)
            {
                if (s == name)
                {
                    Console.WriteLine("일치하는 단어를 찾았음 : " + name);
                    break;
                }
                else
                {
                    Console.WriteLine("일치하는 단어가 없음");
                    break;
                }
            }
            Console.ReadLine(); //콘솔 창 유지를 위해 추가
        }
    }
}

