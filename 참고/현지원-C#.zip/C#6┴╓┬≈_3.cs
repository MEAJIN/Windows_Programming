﻿//20174069 현지원
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    class Calc
    {
        private char op; //연산자
        private int oper1; //피연산자
        private int oper2; //피연산자
        private int result; //결과

        //디폴트 생성자
        public Calc()
        {
            op = '\n';
            oper1 = 0;
            oper2 = 0;
        }

        //연산자 피연산자를 매개변수로 받는 생성자 
        public Calc(char op, int oper1, int oper2)
        {
            this.op = op;
            this.oper1 = oper1;
            this.oper2 = oper2;
        }

        //소멸자
        ~Calc()
        {
            Console.WriteLine("Destructor...");
        }

        //사칙연산 메소드
        public void plus()
        {
            result = oper1 + oper2;
        }

        public void sub()
        {
            result = oper1 - oper2;
        }

        public void mul()
        {
            result = oper1 * oper2;
        }

        public void div()
        {
            result = oper1 / oper2;
        }

        //출력 메소드
        public void print()
        {
            Console.WriteLine("답 = " + result);
        }

        static void Main(string[] args)
        {
            string exper;
            string[] tmp;
            char op;
            int oper1, oper2;

            //사용자에게 수식 입력 받기
            Console.Write("수식을 입력하세요 : ");
            exper = Console.ReadLine();

            //입력 받은 문자열을 공백으로 나누기
            tmp = exper.Split(' ');
            //나눈 문자를 각 변수에 맞는 타입으로 형 변환
            oper1 = int.Parse(tmp[0]);
            op = char.Parse(tmp[1]);
            oper2 = int.Parse(tmp[2]);

            //객체 생성
            Calc calc = new Calc(op, oper1, oper2);

            //계산
            switch (op)
            {
                case '+':
                    calc.plus();
                    calc.print();
                    break;

                case '-':
                    calc.sub();
                    calc.print();
                    break;

                case '*':
                    calc.mul();
                    calc.print();
                    break;

                case '/':
                    calc.div();
                    calc.print();
                    break;
            }
        }
    }
}
