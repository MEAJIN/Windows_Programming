﻿//20174069 현지원
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    using System.Threading;

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("  쓰레드     현재 초");

            ThreadStart ts = new ThreadStart(ThreadBody); 
            Thread t1 = new Thread(ts); 
            Thread t2 = new Thread(ts);
            Thread t3 = new Thread(ts);

            t1.Name = "1";
            t2.Name = "2";
            t3.Name = "3";

            t1.Start();
            t2.Start();
            t3.Start();
        }

        static void ThreadBody()
        {
            Thread myself = Thread.CurrentThread;
            int num = int.Parse(myself.Name); //현재 스레드의 이름을 정수형으로 바꿔줌       
            int time = 1;

            while (true)
            {
                if (myself.Name.Equals("1"))
                {
                    Console.WriteLine("------------------------------");
                    Console.WriteLine("{0}번 쓰레드 \t{1}", myself.Name, time);
                }

                else
                {
                    Console.WriteLine("{0}번 쓰레드", myself.Name);
                }

                time = time + num; //시간 더해주기 
                Thread.Sleep(num * 1000); //1초마다 실행
            }
        }
    }
}
