﻿using System;

//20174069 현지원
namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            //구구단 배열 선언
            int[] mult = new int[9]; //크기가 9인 구구단 배열 선언
            int n = 0, num = 1;

            Console.WriteLine("단을 입력하세요 : "); //사용자에게 단을 입력 받는다
            n = int.Parse(Console.ReadLine());

            //for문을 통해 배열에 결과값 저장
            for (int i = 0; i < 9; i++) {
                mult[i] = (n * (i + 1)); //곱하기 연산 후 배열에 저장
            }

            //for-each문으로 배열에 있는 값 전부 출력
            foreach (var item in mult) {
                Console.WriteLine(n + " * " + (num++) + " = " + item);
            }
        }
    }
}
