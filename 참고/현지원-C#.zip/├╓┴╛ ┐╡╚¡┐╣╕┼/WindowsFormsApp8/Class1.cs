﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp8
{
    class User
    {
        String Id;
        String Psw;
        String Name;
        String Pnum;

        public User()
        {
            Id = "";
            Psw = "";
            Name = "";
            Pnum = "";
        }

        public void setId(String i)
        {
            Id = i;
        }
        public String getId()
        {
            return Id;
        }
        public void setPsw(String p)
        {
            Psw = p;
        }
        public string getPsw()
        {
            return Psw;
        }
        public void setName(String n)
        {
            Name = n;
        }
        public string getName()
        {
            return Name;
        }
        public void setPnum(String pn)
        {
            Pnum = pn;
        }
        public string getPnum()
        {
            return Pnum;
        }
    }
    class Data
    {
        private static Data UserData;
        Dictionary<string, User> dicUser;
        string Cuser; // 접속유저 아이디

        protected Data()
        {
            dicUser = new Dictionary<string, User>();
            Cuser = "";
        }
        public void setCuser(string c)
        {
            Cuser = c;
        }
        public string getCuser()
        {
            return Cuser;
        }
        public Dictionary<string, User> getDicUser() // user dictionary 반환
        {
            return dicUser;
        }

        public static Data UserDat()
        {
            if (UserData == null)
                UserData = new Data();
            return UserData;
        }
    }
}
