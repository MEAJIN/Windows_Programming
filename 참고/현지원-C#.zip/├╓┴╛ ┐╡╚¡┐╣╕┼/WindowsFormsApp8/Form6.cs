﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Data data = Data.UserDat();

            User us = new User();
            us.setId(IdBox.Text);
            us.setPsw(pswBox.Text);
            us.setName(nameBox.Text);
            us.setPnum(pnumBox.Text);

            if(data.getDicUser().ContainsKey(IdBox.Text)==false)
            {
                data.getDicUser().Add(IdBox.Text, us);
                MessageBox.Show("가입 완료!");
                Close();
            }
            else
            {
                MessageBox.Show("존재하는 ID 입니다.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
