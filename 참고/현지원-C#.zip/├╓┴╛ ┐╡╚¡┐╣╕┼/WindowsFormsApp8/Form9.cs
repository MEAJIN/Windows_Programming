﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class Form9 : Form
    {
        int pay1, pay2, pay3, pay4;
        public Form9()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                pay1 = 9000;
                label1.Text = "가격 :  " + Convert.ToString(pay1+pay2+pay3+pay4);
            }
            else if (comboBox1.SelectedIndex == 1)
            {
                pay1 = 10500;
                label1.Text = "가격 :  " + Convert.ToString(pay1);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("결제 완료");
            Close();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex == 0)
            {
                pay2 = 6000;
                label1.Text = "가격 :  " + Convert.ToString(pay1 + pay2 + pay3 + pay4);
            }
            else if (comboBox2.SelectedIndex == 1)
            {
                pay2 = 6000;
                label1.Text = "가격 :  " + Convert.ToString(pay1 + pay2 + pay3 + pay4);
            }
            else if (comboBox2.SelectedIndex == 2)
            {
                pay2 = 6500;
                label1.Text = "가격 :  " + Convert.ToString(pay1 + pay2 + pay3 + pay4);
            }
            else if (comboBox2.SelectedIndex == 3)
            {
                pay2 = 6500;
                label1.Text = "가격 :  " + Convert.ToString(pay1 + pay2 + pay3 + pay4);
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox3.SelectedIndex == 0)
            {
                pay3 = 2500;
                label1.Text = "가격 :  " + Convert.ToString(pay1 + pay2 + pay3 + pay4);
            }
            else if (comboBox3.SelectedIndex == 1)
            {
                pay3 = 2500;
                label1.Text = "가격 :  " + Convert.ToString(pay1 + pay2 + pay3 + pay4);
            }
            else if (comboBox3.SelectedIndex == 2)
            {
                pay3 = 2500;
                label1.Text = "가격 :  " + Convert.ToString(pay1 + pay2 + pay3 + pay4);
            }
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox4.SelectedIndex == 0)
            {
                pay4 = 4500;
                label1.Text = "가격 :  " + Convert.ToString(pay1 + pay2 + pay3 + pay4);
            }
            else if (comboBox4.SelectedIndex == 1)
            {
                pay4 = 3500;
                label1.Text = "가격 :  " + Convert.ToString(pay1 + pay2 + pay3 + pay4);
            }
            else if (comboBox4.SelectedIndex == 2)
            {
                pay4 = 3000;
                label1.Text = "가격 :  " + Convert.ToString(pay1 + pay2 + pay3 + pay4);
            }
        }
    }
}
