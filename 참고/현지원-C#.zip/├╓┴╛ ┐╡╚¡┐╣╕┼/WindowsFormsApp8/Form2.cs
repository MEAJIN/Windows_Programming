﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            PictureBox pic = (PictureBox)sender;
            //MessageBox.Show(pic.Name);

            Form3 frm2 = new Form3(pic.Name, this);
            frm2.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form4 frm3 = new Form4();
            frm3.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
