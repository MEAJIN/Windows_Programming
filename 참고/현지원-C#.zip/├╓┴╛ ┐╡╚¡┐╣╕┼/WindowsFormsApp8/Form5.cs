﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class Form5 : Form
    {
        string loc;
        string dat;
        string tim;
        int num;
        Form4 form4;
        int num1, num2, num3, num4;
        int total;
        int add = 0;

        public Form5()
        {
            InitializeComponent();
        }
        public Form5(string date, string location, int number, Form4 in_form)
        {
            InitializeComponent();
            form4 = in_form;
            dat = date;
            loc = location;
            num = number;
        }
        private void Form5_Load(object sender, EventArgs e)
        {
            label5.Text = "CGV" + loc;
            label7.Text = dat;
            
            if (num==0)
            {
                label9.Text = "17 : 10";
                label8.Text = "잔여좌석 : 92";
            }
            else if (num==1)
            {
                label9.Text = "19 : 30";
                label8.Text = "잔여좌석 : 87";
            }
            else
            {
                label9.Text = "22 : 15";
                label8.Text = "잔여좌석 : 90";
            }
        }
        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown3_ValueChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown4_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button61_Click(object sender, EventArgs e)
        {
            num1 = (int)numericUpDown1.Value;
            num2 = (int)numericUpDown2.Value;
            num3 = (int)numericUpDown3.Value;
            num4 = (int)numericUpDown4.Value;
            total = num1 + num2 + num3 + num4;
            if (total > 7)
            {
                MessageBox.Show("최대 6자리만 선택할 수 있습니다");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            button2.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            button3.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button4.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button5.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            button6.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            button7.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            button8.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            button9.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            button10.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {
            button20.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            button19.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            button18.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            button17.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            button16.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            button15.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            button14.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            button13.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            button12.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            button11.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button30_Click(object sender, EventArgs e)
        {
            button30.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button29_Click(object sender, EventArgs e)
        {
            button29.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button28_Click(object sender, EventArgs e)
        {
            button28.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button27_Click(object sender, EventArgs e)
        {
            button27.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button26_Click(object sender, EventArgs e)
        {
            button26.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button25_Click(object sender, EventArgs e)
        {
            button25.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button24_Click(object sender, EventArgs e)
        {
            button24.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button23_Click(object sender, EventArgs e)
        {
            button23.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button22_Click(object sender, EventArgs e)
        {
            button22.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button21_Click(object sender, EventArgs e)
        {
            button21.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button50_Click(object sender, EventArgs e)
        {
            button50.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button49_Click(object sender, EventArgs e)
        {
            button49.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button48_Click(object sender, EventArgs e)
        {
            button48.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button47_Click(object sender, EventArgs e)
        {
            button47.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button46_Click(object sender, EventArgs e)
        {
            button46.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button45_Click(object sender, EventArgs e)
        {
            button45.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button44_Click(object sender, EventArgs e)
        {
            button44.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button43_Click(object sender, EventArgs e)
        {
            button43.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button42_Click(object sender, EventArgs e)
        {
            button42.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button41_Click(object sender, EventArgs e)
        {
            button41.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button60_Click(object sender, EventArgs e)
        {
            button60.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button59_Click(object sender, EventArgs e)
        {
            button59.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button58_Click(object sender, EventArgs e)
        {
            button58.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button57_Click(object sender, EventArgs e)
        {
            button57.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button56_Click(object sender, EventArgs e)
        {
            button56.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button55_Click(object sender, EventArgs e)
        {
            button55.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button54_Click(object sender, EventArgs e)
        {
            button54.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button53_Click(object sender, EventArgs e)
        {
            button53.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void button52_Click(object sender, EventArgs e)
        {
            button52.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button51_Click(object sender, EventArgs e)
        {
            button51.BackColor = SystemColors.HotTrack;
            add++;
            if (add == total)
            {
                Form7 frm7 = new Form7(num1, num2, num3, num4, this);
                frm7.Show();
            }
        }


    }
}
