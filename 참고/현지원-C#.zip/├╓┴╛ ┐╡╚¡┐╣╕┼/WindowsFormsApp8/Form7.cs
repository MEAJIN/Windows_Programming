﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class Form7 : Form
    {
        Form5 form5;
        int child, youth, adult, pref;
        int a, b, c, d;

        private void button1_Click_1(object sender, EventArgs e)
        {
            Form8 frm8 = new Form8();
            frm8.Show();
            this.Hide();
            form5.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        int total;

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (checkedListBox1.SelectedIndex == 0)
            {
                textBox1.Text = Convert.ToString(total * 0.1);
                textBox2.Text = Convert.ToString(total - (total * 0.1));
            }
            else if (checkedListBox1.SelectedIndex == 1)
            {
                textBox1.Text = Convert.ToString(total * 0.2);
                textBox2.Text = Convert.ToString(total - (total * 0.2));
            }
            else if(checkedListBox1.SelectedIndex==2)
            {
                textBox1.Text = Convert.ToString(total * 0.15);
                textBox2.Text = Convert.ToString(total - (total * 0.15));
            }
            else
            {
                textBox1.Text = "0";
                textBox2.Text = Convert.ToString(total);
            }

        }

        public Form7()
        {
            InitializeComponent();
        }
        public Form7(int num1,int num2, int num3, int num4, Form5 in_form)
        {
            InitializeComponent();
            form5 = in_form;
            adult = num1;
            youth = num2;
            child = num3;
            pref = num4;

        }
        private void Form7_Load(object sender, EventArgs e)
        {
            a = (adult * 9000);
            b = (child * 6000);
            c = (youth * 8000);
            d = (pref * 6000);
            total = a + b + c + d;

            label1.Text = "일반(9000원) : " + Convert.ToString(adult) + "명 =   " + a + "원";
            label2.Text = "어린이(6000원) : " + Convert.ToString(child) + "명 =   " + b + "원";
            label3.Text = "청소년(8000원) : " + Convert.ToString(youth) + "명 =   " + c + "원";
            label4.Text = "우대(6000원) : " + Convert.ToString(pref) + "명 =   " + d + "원";
            label5.Text = "원 결제 금액 :  " + total + "원";
            
        }
    }
}
