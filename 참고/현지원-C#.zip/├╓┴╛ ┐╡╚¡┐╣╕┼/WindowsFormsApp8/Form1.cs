﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Init();
        }

        private void Init()
        {
            Data data = Data.UserDat();

            User us = new User();
            us.setId("psasa1");
            us.setPsw("1234");

            data.getDicUser().Add("psasa1", us);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Data data = Data.UserDat();

            if(textBox1.TextLength < 1)
            {
                MessageBox.Show("아이디가 입력되지 않았습니다.");
            }
            if (textBox2.TextLength < 1)
            {
                MessageBox.Show("비밀번호가 입력되지 않았습니다.");
            }

            if (data.getDicUser().ContainsKey(textBox1.Text))
            {
                if(data.getDicUser()[textBox1.Text].getPsw() == textBox2.Text)
                {
                    this.Visible = false;
                    MessageBox.Show(textBox1.Text + "님 로그인이 완료되었습니다.");

                    data.setCuser(textBox1.Text);

                    Form2 dig = new Form2();
                    dig.ShowDialog();
                    this.Visible = true;
                }
                else
                {
                    MessageBox.Show("비밀번호가 틀립니다.");
                }
            }
            else
            {
                MessageBox.Show("아이디가 없습니다.");
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form6 dig = new Form6();
            dig.ShowDialog();

        }
    }
}
