﻿//20174069 현지원
using System;

namespace ConsoleApp6
{
    //추상 클래스 Shape, 부모 클래스 
    abstract class Shape
    {
        int size;
        protected int Size
        { //프로퍼티
            set { size = value; }
            get { return size; }
        }

        //생성자
        public Shape(int size)
        {
            this.size = size;
        }

        public abstract void Draw(); //추상 메소드 Draw()
    }

    //부모 클래스 Shape를 상속받는 Triangle 클래스
    class Triangle : Shape
    {
        //생성자
        public Triangle(int size) : base(size) { } //base() 키워드를 사용하여 해당 키워드를 사용하는 클래스의 부모 클래스를 가리킴

        //삼각형을 그리는 Draw() 메소드
        public override void Draw()
        {
            Console.WriteLine("삼각형");
            int i, j;
            for (i = 0; i < Size; i++)
            {
                for (j = 0; j < (Size - 1) - i; j++) 
                {
                    Console.Write(" ");
                }
                for (j = 0; j < (i * 2) + 1; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
        }
    }

    //부모 클래스 Shape를 상속받는 Rectangle 클래스
    class Rectangle : Shape
    {
        private int y;

        public Rectangle(int size, int size_y) : base(size) { y = size_y; } //부모 클래스 Shape의 생성자에 y추가

        //사각형을 그리는 Draw() 메소드
        public override void Draw()
        {
            Console.WriteLine("\n사각형");
            int i, j;
            for (i = 0; i < y; i++)
            {
                Console.Write("*");
                for (j = 1; j < Size; j++) 
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            int tri = 0, rect_width = 0, rect_height;
            string[] tmp;
            string s;

            //사용자로부터 크기 입력받기
            Console.Write("삼각형의 크기를 입력하시오 : ");
            tri = int.Parse(Console.ReadLine());

            Console.Write("사각형의 가로, 세로 크기를 입력하시오 : ");
            s = Console.ReadLine();

            tmp = s.Split(',');
            rect_width = int.Parse(tmp[0]);
            rect_height = int.Parse(tmp[1]);

            Triangle t = new Triangle(tri); //Triangle 객체 생성
            t.Draw();

            Rectangle r = new Rectangle(rect_width, rect_height); //Rectangle 객체 생성
            r.Draw();
        }
    }
}