﻿//20174069 현지원
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    class Stack
    {
        private int[] stack;
        int sp = -1;

        //(1)디폴트 생성자를 작성하시오. 이 경우에 스택의 크기는 100이다.
        //디폴트 생성자
        public Stack()
        {
            stack = new int[100]; //스택의 크기는 100
        }

        //매개변수로 스택의 크기를 받는 생성자
        public Stack(int size)
        {
            stack = new int[size];
        }

        //(2)메소드 Push()와 Pop()을 작성하시오.
        public void Push(int data)
        {
            sp++; // top을 1 증가시키고
            stack[sp] = data; //data를 stack에 삽입
        }

        public int Pop()
        {
            return stack[sp--];
        }

        //stack 초기화 함수
        public void init()
        {
            sp = -1;
        }

        //접근자
        public int get_sp()
        {
            return sp;
        }

        static void Main(string[] args)
        {

            int num = 1;

            Stack stack = new Stack();

            //사용자가 0을 입력하면 push 종료
            while (true)
            {
                Console.Write("정수를 입력하시오 <입력의 끝은 0> : ");
                num = int.Parse(Console.ReadLine()); //정수로 변환해서 num에 할당

                if (num == 0) //사용자가 0을 입력하면
                    break; //while문 탈출
                //stack에 push해주기 
                stack.Push(num);
            }

            //출력
            while (stack.get_sp() >= 0)
            {
                Console.Write(stack.Pop() + " ");
            }
        }
    }
}