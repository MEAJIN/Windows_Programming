﻿//20174069 현지원
using System;
using System.Threading;

namespace ATM
{
    class Account //계좌 클래스
    {
        private double balance;
        //생성자
        public Account(double initialDeposit)
        {
            balance = initialDeposit; //잔액 저장
        }

        //프로퍼티
        public double Balance
        {
            get { return balance; } //잔액 조회
        }

        //입금
        public void Deposit(double amount) //총액 계산 및 기록
        {
            //해당 객체 외에 다른 객체가 접근하지 못하도록 함
            lock (this) 
            {
                balance = balance + amount; 
            }
        }

        //출금
        public bool Withdraw(double amount) //총액 계산 및 기록
        {
            //해당 객체 외에 다른 객체가 접근하지 못하도록 함
            lock (this)
            {
                if ((balance - amount) < 0) //출금 후 금액이 0보다 작을 경우
                    return false; //false 반환

                else //0이상일 경우
                {
                    balance = balance - amount; //출금 후
                    return true; //true 반환
                }
                
            }
        }
    }

    //은행원 클래스
    class Teller
    {
        string name; //은행원 이름
        Account account; //처리할 계정
        double amount; //예금액

        //생성자
        public Teller(string name, Account account, double amount)
        {
            this.name = name;
            this.account = account;
            this.amount = amount;
        }

        //잔액 출력 메소드, 인수로 main의 check 변수를 가져옴 
        public void TellerTask(int n)
        {
            account.Deposit(amount);
            //현재 처리중인 동작을 n으로 받아서 알맞은 경우에 따라 출력
            switch (n)
            {
                case 0:
                    Console.WriteLine(name + "님의 현재 잔액은 " + account.Balance + "원 입니다.");
                    break;

                case 1:
                    Console.WriteLine(name + "님의 입금 후 잔액은 " + account.Balance + "원 입니다.");
                    break;

                case 2:
                    Console.WriteLine(name + "님의 출금 후 잔액은 " + account.Balance + "원 입니다.");
                    break;

                case 3:
                    Console.WriteLine(name + "님의 현재 잔 액은 " + account.Balance + "원 입니다.");
                    break;

                case 4:
                    Console.WriteLine("이용해주셔서 감사합니다.");
                    break;
            }
            
        }
    }

    class Program
    {
        static void Main(string[] args)
        {

            Account a = new Account(100000);
            Teller User = new Teller("홍길동", a, 0);
            int check = 0;

            User.TellerTask(check); //초기 잔액 출력

            //최소 한번 실행
            do
            {
                Console.WriteLine("\n1. 입금");
                Console.WriteLine("2. 출금");
                Console.WriteLine("3. 조회");
                Console.WriteLine("4. 종료");

                check = int.Parse(Console.ReadLine());

                switch (check)
                {
                    //입금
                    case 1:
                        Console.Write("입금 금액 : ");
                        a.Deposit(double.Parse(Console.ReadLine()));
                        User.TellerTask(check);
                        break;
                    
                    //출금
                    case 2:
                        Console.Write("출금 금액 : ");
                        if (a.Withdraw(double.Parse(Console.ReadLine())) == true) //출금 후 금액이 0이상일 경우 
                            User.TellerTask(check); //TellerTask 메소드 호출
                        else
                            Console.WriteLine("잔액이 부족합니다.");
                        break;

                    //조회
                    case 3: 
                        User.TellerTask(check);
                        break;

                    //종료
                    case 4:
                        User.TellerTask(check);
                        break; 
                }
            } while (check != 4); //사용자가 4를 입력하면 종료
        }
    }
}
