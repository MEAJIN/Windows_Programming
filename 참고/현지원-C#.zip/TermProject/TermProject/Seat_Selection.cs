﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TermProject
{
    public partial class Seat_Selection : Form
    {
        private Reserve reserve = null;

        private int click_seat = 0;
        int total = 0;
        Button[] btn = new Button[48];
        string seletedTime, left_seat;

        List<string> seat_list = new List<string>(); //선택 되면 "1", 선택 안되면 "0" 저장

        string dir_path = @"../movie"; //상대경로로 파일 디렉토리 경로 지정

        public Seat_Selection(Reserve r)
        {
            InitializeComponent();
            this.reserve = r;
            //제목
            title.Text = reserve.title.Text;

            //극장             
            area.Text = reserve.area.Text;

            label14.Text = area.Text;

            //str[0] = time / str[1] = left_seat
            string[] str = reserve.time.Text.Split(' ');
            seletedTime = str[0];
            left_seat = str[1];

            //잔여석
            label11.Text = str[1];

            //날짜
            date.Text = reserve.date.Text;

            //시간
            time.Text = seletedTime;

            //날짜 + 시간
            label13.Text = date.Text + " | " + seletedTime;

            //사용자 아이디
            user_id.Text = reserve.user_id.Text;         
            
            //이미지 
            string img_path = title.Text;
            pictureBox1.Load(@"../img/" + img_path + ".png");
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;

            //좌석 버튼
            btn[0] = button1;
            btn[1] = button2;
            btn[2] = button3;
            btn[3] = button4;
            btn[4] = button5;
            btn[5] = button6;
            btn[6] = button7;
            btn[7] = button8;
            btn[8] = button9;
            btn[9] = button10;
            btn[10] = button11;
            btn[11] = button12;
            btn[12] = button13;
            btn[13] = button14;
            btn[14] = button15;
            btn[15] = button16;
            btn[16] = button17;
            btn[17] = button18;
            btn[18] = button19;
            btn[19] = button20;
            btn[20] = button21;
            btn[21] = button22;
            btn[22] = button23;
            btn[23] = button24;
            btn[24] = button25;
            btn[25] = button26;
            btn[26] = button27;
            btn[27] = button28;
            btn[28] = button29;
            btn[29] = button30;

            //일반 버튼
            btn[30] = button31;
            btn[31] = button32;
            btn[32] = button33;
            btn[33] = button34;
            btn[34] = button35;
            btn[35] = button36;

            //청소년 버튼
            btn[36] = button37;
            btn[37] = button38;
            btn[38] = button39;
            btn[39] = button40;
            btn[40] = button41;
            btn[41] = button42;

            //대우 버튼
            btn[42] = button43;
            btn[43] = button44;
            btn[44] = button45;
            btn[45] = button46;
            btn[46] = button47;
            btn[47] = button48;

            //이미 예매 된 좌석을 표시하기 위한 파일 읽기
            string time_file = seletedTime.Replace(':', '.');
            string dir = dir_path + "/" + title.Text + "/" + area.Text + "/"  + date.Text + "/" + time_file + ".txt";
            int i = -1;
            
            StreamReader sr = new StreamReader(dir, Encoding.Default);
            while (sr.EndOfStream == false) // 파일이 끝날 때까지 반복
            {
                string s = sr.ReadLine();
                string[] tmp = s.Split('/'); //'/'기준으로 나눈다 

                //한 줄씩 검사                        
                foreach (string check_seat in tmp)
                {
                    //MessageBox.Show(i + " " + check_seat);
                    if (check_seat.Equals("1")) //1이 있으면 
                    {
                        btn[i].BackColor = Color.Gray; //배경 색 변경
                        btn[i].FlatAppearance.BorderColor = Color.Gray; //테두리 색 변경
                        btn[i].Enabled = false; //클릭하지 못하게 
                        seat_list.Add("1");
                    }

                    else
                    {
                        seat_list.Add("0");
                    }
                    i++; //인덱스 증가
                }
            }
            /*
            foreach(string s in seat_list)
            {
                Console.WriteLine(s);
            }
            */
        }

        private void Seat_Selection_Load(object sender, EventArgs e)
        {

        }

        //좌석 버튼 눌렀을 경우
        private void Seat_buttons_Click(object sender, EventArgs e)
        {
            //check_seat(index);
            string s = label24.Text;
            string[] s_tmp = s.Split(' ');

            Console.WriteLine(s_tmp[0]);

            //int m = Int32.Parse(s_tmp[0]);

            for (int i = 0; i < 30; i++)
            {                
                if(s_tmp[0] == "1")
                {
                    if (btn[i].Equals(sender))
                    {
                        //(흰 -> 갈) 버튼 색상 변경, seat_list의 0을 1로 번경 
                        btn[i].BackColor = Color.FromArgb(48, 40, 22); //배경 색 변경
                        seat_list[i] = "1";
                        label23.Text = btn[i].Text;

                        click_seat++;
                    }

                    //다른곳 클릭 할 경우 
                    else
                    {
                        //(갈 -> 흰) 버튼 색상 변경, seat_list의 1을 0로 번경 
                        btn[i].BackColor = Color.FromArgb(112, 111, 109);
                        seat_list[i] = "0";
                        click_seat = 0;
                    }
                }

                else if(s_tmp[0] == "2")
                {
                    int index = Int32.Parse(btn[i].Text);

                    //짝수면 왼쪽
                    if ((index % 2) == 0)
                    {
                        if (btn[i].Equals(sender))
                        {
                            //(흰 -> 갈) 버튼 색상 변경, seat_list의 0을 1로 번경 
                            btn[i].BackColor = Color.FromArgb(48, 40, 22);
                            btn[i - 1].BackColor = Color.FromArgb(48, 40, 22);
                            seat_list[i] = "1";
                            seat_list[i - 1] = "1";
                            label23.Text = btn[i-1].Text + ", " + btn[i].Text;
                        }

                        //다른곳 클릭 할 경우 
                        else
                        {
                            if ((index % 2) == 1)
                            {
                                if (btn[i].Equals(sender))
                                {
                                    //(흰 -> 갈) 버튼 색상 변경, seat_list의 0을 1로 번경 
                                    btn[i].BackColor = Color.FromArgb(48, 40, 22);
                                    btn[i + 1].BackColor = Color.FromArgb(48, 40, 22);
                                    seat_list[i] = "1";
                                    seat_list[i + 1] = "1";
                                    label23.Text = btn[i].Text + ", " + btn[i + 1].Text;
                                }

                                //다른곳 클릭 할 경우 
                                else
                                {
                                    //(갈 -> 흰) 버튼 색상 변경, seat_list의 1을 0로 번경 
                                    btn[i].BackColor = Color.FromArgb(112, 111, 109);
                                    btn[i + 1].BackColor = Color.FromArgb(112, 111, 109);
                                    seat_list[i] = "0";
                                    seat_list[i + 1] = "0";
                                    click_seat = 0;
                                }
                            }
                        }
                    }

                    //홀수
                    else if((index % 2) == 1)
                    {
                        if (btn[i].Equals(sender))
                        {
                            //(흰 -> 갈) 버튼 색상 변경, seat_list의 0을 1로 번경 
                            btn[i].BackColor = Color.FromArgb(48, 40, 22);
                            btn[i + 1].BackColor = Color.FromArgb(48, 40, 22);
                            seat_list[i] = "1";
                            seat_list[i + 1] = "1";
                            label23.Text = btn[i].Text + ", " + btn[i + 1].Text;

                            click_seat++;
                        }

                        //다른곳 클릭 할 경우 
                        else
                        {
                            //(갈 -> 흰) 버튼 색상 변경, seat_list의 1을 0로 번경 
                            btn[i].BackColor = Color.FromArgb(112, 111, 109);
                            btn[i + 1].BackColor = Color.FromArgb(112, 111, 109);
                            seat_list[i] = "0";
                            seat_list[i + 1] = "0";
                            click_seat = 0;
                        }
                    }
                }

                else
                {
                    MessageBox.Show("인원을 선택해 주세요.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }
        }

        //인원 수 버튼 눌렀을 경우
        private void Num_buttons_Click(object sender, EventArgs e)
        {
            Button b = sender as Button;
            int index = (Int32.Parse(((Button)sender).Text));

            for (int i = 30; i <= 35; i++)
            {
                if (btn[i].Equals(sender))
                {
                    btn[i].BackColor = Color.FromArgb(48, 40, 22); //배경 색 변경
                    btn[i].ForeColor = Color.White; //글자 색 변경
                    label24.Text = index.ToString() + " 인";
                    label22.Text = "일반";
                    label25.Text = "13000원";
                    total = index * 13000;
                    label26.Text = index.ToString() + "*" + "13000";
                    label27.Text = total.ToString() + "원";
                }

                else
                {
                    btn[i].BackColor = Color.FromArgb(224, 220, 206); //배경 색 원래대로 변경
                    btn[i].ForeColor = Color.Black; //글자 색 변경
                }
            }

            for (int i = 36; i <= 41; i++)
            {
                if (btn[i].Equals(sender))
                {                    
                    btn[i].BackColor = Color.FromArgb(48, 40, 22); //배경 색 변경
                    btn[i].ForeColor = Color.White; //글자 색 변경
                    label24.Text = index.ToString() + "인";
                    label22.Text = "청소년";
                    label25.Text = "9000원";
                    total = index * 9000;
                    label26.Text = index.ToString() + "*" + "9000";
                    label27.Text = total.ToString() + "원";
                }

                else
                {
                    btn[i].BackColor = Color.FromArgb(224, 220, 206); //배경 색 원래대로 변경
                    btn[i].ForeColor = Color.Black; //글자 색 변경
                }
            }

            for (int i = 42; i <= 47; i++)
            {
                if (btn[i].Equals(sender))
                {                    
                    btn[i].BackColor = Color.FromArgb(48, 40, 22); //배경 색 변경
                    btn[i].ForeColor = Color.White; //글자 색 변경
                    label24.Text = index.ToString() + "인";
                    label22.Text = "우대";
                    label25.Text = "7000원";
                    total = index * 7000;
                    label26.Text = index.ToString() + "*" + "7000";
                    label27.Text = total.ToString() + "원";
                }

                else
                {
                    btn[i].BackColor = Color.FromArgb(224, 220, 206); //배경 색 원래대로 변경
                    btn[i].ForeColor = Color.Black; //글자 색 변경
                }
            }
        }

        //결제 선택 버튼
        //현재 접속 중인 유저 아이디, 선택 영화, 날짜, 시간, 인원, 좌석 파일에 쓰기
        //결제 화면 띄워주기
        private void select_Click(object sender, EventArgs e)
        {
            //파일에 사용자 정보 쓰기
            FileStream fs = new FileStream("Reserve.txt", FileMode.Append, FileAccess.Write);
            //FileMode 중 append : 이어쓰기, 파일이 없으면 파일 생성
            StreamWriter sw = new StreamWriter(fs, System.Text.Encoding.UTF8);

            //아이디 / 영화 제목 / 극장 / 날짜 / 시간 / 인원 / 자리 / 종류 / 가격 
            sw.WriteLine(user_id.Text + "/" + title.Text + "/" + area.Text + "/" + date.Text + "/" + seletedTime + "/" + label24.Text + 
                "/" + label23.Text + "/" + label22.Text + "/" + label27.Text);

            
            sw.Close();
            fs.Close();

            Pay p = new Pay(this);
            p.ShowDialog();

            this.Close();
        }

        //초기화
        private void button53_Click(object sender, EventArgs e)
        {
            for (int i2 = 0; i2 < 30; i2++)
            {
                btn[i2].BackColor = Color.FromArgb(112, 111, 109); //배경 색 변경
                btn[i2].ForeColor = Color.White; //글자 색 변경
            }

            for (int j = 30; j < 48; j++)
            {
                btn[j].BackColor = Color.FromArgb(224, 220, 206); //배경 색 변경
                btn[j].ForeColor = Color.Black; //글자 색 변경
            }

            //이미 예매 된 좌석을 표시하기 위한 파일 읽기
            string time_file = seletedTime.Replace(':', '.');
            string dir = dir_path + "/" + title.Text + "/" + area.Text + "/" + date.Text + "/" + time_file + ".txt";
            int i = -1;

            StreamReader sr = new StreamReader(dir, Encoding.Default);
            while (sr.EndOfStream == false) // 파일이 끝날 때까지 반복
            {
                string s = sr.ReadLine();
                string[] tmp = s.Split('/'); //'/'기준으로 나눈다 

                //한 줄씩 검사                        
                foreach (string check_seat in tmp)
                {
                    //MessageBox.Show(i + " " + check_seat);
                    if (check_seat.Equals("1")) //1이 있으면 
                    {
                        btn[i].BackColor = Color.Gray; //배경 색 변경
                        btn[i].FlatAppearance.BorderColor = Color.Gray; //테두리 색 변경
                        btn[i].Enabled = false; //클릭하지 못하게 
                        seat_list.Add("1");
                    }

                    else
                    {
                        seat_list.Add("0");
                    }
                    i++; //인덱스 증가
                }
            }

            label5.Text = " ";
            label23.Text = " "; //좌석 번호 초기화
            label22.Text = " ";
            label24.Text = " ";
            label25.Text = " ";
            label26.Text = " ";
            label27.Text = " ";

        }

        //영화 선택 버튼
        //뒤로 가기 버튼
        private void button52_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
