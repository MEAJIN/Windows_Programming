﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TermProject
{
    public partial class Pay : Form
    {
        private string payment;
        private string discount;
        private Seat_Selection seat = null;

        private string id, title, area, date, time, num, where, mode, price;

        private void Pay_Load(object sender, EventArgs e)
        {
            //Reserve.txt 읽기
            StreamReader sr = new StreamReader("Reserve.txt", Encoding.Default);

            while (sr.EndOfStream == false) // 파일이 끝날 때까지 반복
            {
                string line = sr.ReadLine();
                string[] str = line.Split('/'); //!기준으로 나눈다 
                id = str[0];
                title = str[1];
                area = str[2];
                date = str[3];
                time = str[4];
                num = str[5];
                where = str[6];
                mode = str[7];
                price = str[8];
            }
            sr.Close();

            if(price.EndsWith("원"))
            {
                int endpos = price.IndexOf("원");
                price = price.Substring(0, endpos);
            }

            label3.Text = price;
        }

        public Pay(Seat_Selection s)
        {
            InitializeComponent();
            this.seat = s;

            string[] cupon = { "3000원", "5000원" };
            //comboBox1.Items.AddRange(cupon);
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            payment = radioButton1.Text;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            payment = radioButton2.Text;
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            payment = radioButton3.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(id + "\n결제가 완료되었습니다!\n" + 
                "결제 하실 금액 : " + label3.Text + "\n" + 
                "할인 쿠폰 : " + discount + "\n" + 
                "최종 결제 수단 : " + radioButton1.Text + "\n" + 
                "최종 결제 금액 : " + label7.Text + "\n");

            MessageBox.Show(id + "의 예매 정보\n" +
                "제목 : " + title + "\n" +
                "지역 : " + area + "\n" +
                "날짜 : " + date + "\n" +
                "인원 : " + num + "\n" +
                "자리 : " + where + "\n");

            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            discount = comboBox1.SelectedItem.ToString();

            if (discount.EndsWith("원"))
            {
                int endpos = discount.IndexOf("원");
                discount = discount.Substring(0, endpos);
            }

            int dis = int.Parse(discount);
            int total = int.Parse(price);

            int result = total - dis;

            label7.Text = result.ToString();
        }
    }
}
