﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TermProject
{
    public partial class Form1 : Form
    {
        //public List<string> title_list;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            /*
            List<string> title_list = new List<string>();
            title_list.Add(title1.Text);
            title_list.Add(title2.Text);
            title_list.Add(title3.Text);
            */

            //파일 읽어서 예매율 순으로 이미지, 제목 레이블 정렬
        }

        //로그인 버튼
        private void login_Click(object sender, EventArgs e)
        {
            Login login = new Login(this); //로그인 폼 띄우기
            login.ShowDialog();
        }

        //회원가입 버튼
        private void join_Click(object sender, EventArgs e)
        {
            //텍스트가 회원가입 일 경우
            if(Join.Text.Equals("회원가입"))
            {
                Join join = new Join(); //회원가입 폼 띄우기
                join.ShowDialog();
            }

            //텍스트가 로그아웃 일 경우
            else if(Join.Text.Equals("로그아웃"))
            {
                Login.Text = "로그인"; 
                Login.Enabled = true; //클릭 가능하도록 
                Join.Text = "회원가입";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Refresh();
        }

        public static implicit operator MenuStrip(Form1 v)
        {
            throw new NotImplementedException();
        }

        //영화 버튼
        private void button2_Click(object sender, EventArgs e)
        {

        }

        //예매 버튼
        private void Reserve_Click(object sender, EventArgs e)
        {


            //로그인을 하지않으면 예매 불가
            if (Login.Text.Equals("로그인"))
            {
                MessageBox.Show("로그인을 해주세요.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            else
            {
                //예매 페이지 버튼과 같은 페이지 띄워주기
                Reserve rs = new Reserve(this);
                rs.ShowDialog();
            }
        }

        //예매 페이지 버튼
        private void button3_Click(object sender, EventArgs e)
        {
            //로그인을 하지않으면 예매 불가
            if (Login.Text.Equals("로그인"))
            {
                MessageBox.Show("로그인을 해주세요.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            else
            {
                //예매 페이지 버튼과 같은 페이지 띄워주기
                Reserve rs = new Reserve(this);
                rs.ShowDialog();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //로그인을 하지않으면 예매 불가
            if (Login.Text.Equals("로그인"))
            {
                MessageBox.Show("로그인을 해주세요.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            else
            {
                //예매 페이지 버튼과 같은 페이지 띄워주기
                Reserve rs = new Reserve(this);
                rs.ShowDialog();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }
    }

    //회원가입 시 사용자들의 정보를 저장할 클래스 
    public class MemberInfo
    {
        public string ID
        {
            get;
            private set;
        }

        public string Name
        {
            get;
            private set;
        }

        public string PW
        {
            get;
            private set;
        }

        public string Birth
        {
            get;
            private set;
        }

        public string Email
        {
            get;
            private set;
        }

        public string Num
        {
            get;
            private set;
        }

        public MemberInfo(string id, string name, string pw, string birth, string email, string num)
        {
            ID = id;
            Name = name;
            PW = pw;
            Birth = birth;
            Email = email;
            Num = num;
        }
    }
}
