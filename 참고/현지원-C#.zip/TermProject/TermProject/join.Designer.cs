﻿namespace TermProject
{
    partial class Join
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.email3 = new System.Windows.Forms.ComboBox();
            this.num2 = new System.Windows.Forms.TextBox();
            this.num1 = new System.Windows.Forms.ComboBox();
            this.num3 = new System.Windows.Forms.TextBox();
            this.email2 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.email1 = new System.Windows.Forms.TextBox();
            this.chk_pw = new System.Windows.Forms.TextBox();
            this.pw = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.id = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.year = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.month = new System.Windows.Forms.ComboBox();
            this.day = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(343, 346);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "회원가입";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(435, 346);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "취소";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // email3
            // 
            this.email3.FormattingEnabled = true;
            this.email3.Location = new System.Drawing.Point(395, 247);
            this.email3.Name = "email3";
            this.email3.Size = new System.Drawing.Size(86, 20);
            this.email3.TabIndex = 55;
            this.email3.SelectedIndexChanged += new System.EventHandler(this.email3_SelectedIndexChanged);
            // 
            // num2
            // 
            this.num2.Location = new System.Drawing.Point(224, 282);
            this.num2.Name = "num2";
            this.num2.Size = new System.Drawing.Size(65, 21);
            this.num2.TabIndex = 54;
            // 
            // num1
            // 
            this.num1.FormattingEnabled = true;
            this.num1.Location = new System.Drawing.Point(147, 282);
            this.num1.Name = "num1";
            this.num1.Size = new System.Drawing.Size(56, 20);
            this.num1.TabIndex = 53;
            // 
            // num3
            // 
            this.num3.Location = new System.Drawing.Point(305, 282);
            this.num3.Name = "num3";
            this.num3.Size = new System.Drawing.Size(65, 21);
            this.num3.TabIndex = 52;
            // 
            // email2
            // 
            this.email2.Location = new System.Drawing.Point(281, 246);
            this.email2.Name = "email2";
            this.email2.Size = new System.Drawing.Size(99, 21);
            this.email2.TabIndex = 51;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("함초롬돋움", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label11.Location = new System.Drawing.Point(252, 246);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(24, 21);
            this.label11.TabIndex = 50;
            this.label11.Text = "@";
            // 
            // email1
            // 
            this.email1.Location = new System.Drawing.Point(147, 246);
            this.email1.Name = "email1";
            this.email1.Size = new System.Drawing.Size(99, 21);
            this.email1.TabIndex = 47;
            // 
            // chk_pw
            // 
            this.chk_pw.Location = new System.Drawing.Point(147, 167);
            this.chk_pw.Name = "chk_pw";
            this.chk_pw.Size = new System.Drawing.Size(151, 21);
            this.chk_pw.TabIndex = 45;
            // 
            // pw
            // 
            this.pw.Location = new System.Drawing.Point(147, 127);
            this.pw.Name = "pw";
            this.pw.Size = new System.Drawing.Size(151, 21);
            this.pw.TabIndex = 44;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("함초롬돋움", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label10.Location = new System.Drawing.Point(48, 282);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(74, 21);
            this.label10.TabIndex = 41;
            this.label10.Text = "전화번호";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("함초롬돋움", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(48, 127);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 21);
            this.label6.TabIndex = 39;
            this.label6.Text = "비밀번호";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("함초롬돋움", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(11, 163);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 21);
            this.label5.TabIndex = 38;
            this.label5.Text = "비밀번호 확인";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("함초롬돋움", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(64, 247);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 21);
            this.label2.TabIndex = 35;
            this.label2.Text = "이메일";
            // 
            // id
            // 
            this.id.Location = new System.Drawing.Point(147, 50);
            this.id.Name = "id";
            this.id.Size = new System.Drawing.Size(151, 21);
            this.id.TabIndex = 43;
            // 
            // name
            // 
            this.name.Location = new System.Drawing.Point(147, 87);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(151, 21);
            this.name.TabIndex = 42;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("함초롬돋움", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(80, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 21);
            this.label1.TabIndex = 34;
            this.label1.Text = "이름";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("함초롬돋움", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.Location = new System.Drawing.Point(64, 50);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 21);
            this.label7.TabIndex = 40;
            this.label7.Text = "아이디 ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("함초롬돋움", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label9.Location = new System.Drawing.Point(48, 206);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 21);
            this.label9.TabIndex = 61;
            this.label9.Text = "생년월일";
            // 
            // year
            // 
            this.year.FormattingEnabled = true;
            this.year.Location = new System.Drawing.Point(147, 210);
            this.year.Name = "year";
            this.year.Size = new System.Drawing.Size(67, 20);
            this.year.TabIndex = 62;
            this.year.SelectedIndexChanged += new System.EventHandler(this.year_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("함초롬돋움", 10F);
            this.label12.Location = new System.Drawing.Point(218, 210);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(22, 18);
            this.label12.TabIndex = 63;
            this.label12.Text = "년";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("함초롬돋움", 10F);
            this.label13.Location = new System.Drawing.Point(306, 211);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(22, 18);
            this.label13.TabIndex = 64;
            this.label13.Text = "월";
            // 
            // month
            // 
            this.month.FormattingEnabled = true;
            this.month.Location = new System.Drawing.Point(246, 210);
            this.month.Name = "month";
            this.month.Size = new System.Drawing.Size(56, 20);
            this.month.TabIndex = 65;
            this.month.SelectedIndexChanged += new System.EventHandler(this.month_SelectedIndexChanged);
            // 
            // day
            // 
            this.day.FormattingEnabled = true;
            this.day.Location = new System.Drawing.Point(334, 210);
            this.day.Name = "day";
            this.day.Size = new System.Drawing.Size(56, 20);
            this.day.TabIndex = 66;
            this.day.SelectedIndexChanged += new System.EventHandler(this.day_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("함초롬돋움", 10F);
            this.label14.Location = new System.Drawing.Point(396, 210);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(22, 18);
            this.label14.TabIndex = 67;
            this.label14.Text = "일";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(330, 48);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 68;
            this.button3.Text = "중복검사";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Join
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(239)))));
            this.ClientSize = new System.Drawing.Size(545, 396);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.day);
            this.Controls.Add(this.month);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.year);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.email3);
            this.Controls.Add(this.num2);
            this.Controls.Add(this.num1);
            this.Controls.Add(this.num3);
            this.Controls.Add(this.email2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.email1);
            this.Controls.Add(this.chk_pw);
            this.Controls.Add(this.pw);
            this.Controls.Add(this.id);
            this.Controls.Add(this.name);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Join";
            this.Text = "Join";
            this.Load += new System.EventHandler(this.join_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox email3;
        private System.Windows.Forms.TextBox num2;
        private System.Windows.Forms.ComboBox num1;
        private System.Windows.Forms.TextBox num3;
        private System.Windows.Forms.TextBox email2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox email1;
        private System.Windows.Forms.TextBox chk_pw;
        private System.Windows.Forms.TextBox pw;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox id;
        private System.Windows.Forms.TextBox name;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox year;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox month;
        private System.Windows.Forms.ComboBox day;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button3;
    }
}