﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TermProject
{
    public partial class Login : Form
    {
        private Form1 main = null;
        public bool logout = false; 

        public Login(Form1 main)
        {
            InitializeComponent();
            this.main = main;
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void Check()
        {
            //User.txt 읽기
            StreamReader sr = new StreamReader("User.txt", Encoding.Default);

            //사용자가 입력한 아이디와 비밀번호를 딕셔너리에 키와 값으로 저장
            Dictionary<string, string> list = new Dictionary<string, string>();

            while (sr.EndOfStream == false) // 파일이 끝날 때까지 반복
            {
                string s = sr.ReadLine();
                string[] str = s.Split('!'); //!기준으로 나눈다 
                list.Add(str[0], str[1]); //str[0] = id / str[1] = pw
            }
          
            foreach (KeyValuePair<string, string> pair in list)
            {
                //아이디 있으면
                if (id.Text == pair.Key)
                {
                    //비밀번호 일치
                    if(pw.Text == pair.Value)
                    {
                        MessageBox.Show("로그인이 완료되었습니다.");
                        main.Login.Text = pair.Key + " 님"; //아이디로 바꿔주기
                        main.Login.Enabled = false;
                        main.Join.Text = "로그아웃";

                        //파일에 로그인 사용자 정보 쓰기
                        FileStream fs = new FileStream("Login_User.txt", FileMode.Append, FileAccess.Write);
                        //FileMode 중 append : 이어쓰기, 파일이 없으면 파일 생성
                        StreamWriter sw = new StreamWriter(fs, System.Text.Encoding.UTF8);

                        sw.WriteLine(id.Text);

                        sw.Close();
                        fs.Close();

                        return;
                    }
                    //비밀번호 불일치
                    else
                    {
                        MessageBox.Show("비밀번호가 일치하지 않습니다.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                //아이디 없으면
                else
                {
                    MessageBox.Show("등록되지 않은 아이디 입니다.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            sr.Close();
        }

        //로그인 버튼
        private void button1_Click(object sender, EventArgs e)
        {
            if(id.Text == "")
            {
                MessageBox.Show("아이디를 입력해 주세요.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            if(pw.Text == "")
            {
                MessageBox.Show("비밀번호를 입력해 주세요.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            else
            {
                Check();
            }      
            this.Close();
        }

        //취소 버튼
        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("취소 하시겠습니까?");
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        //아이디 찾기
        private void button3_Click_1(object sender, EventArgs e)
        {
            Search s = new Search();
            s.ShowDialog();
        }
    }
}
