﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TermProject.Properties;

namespace TermProject
{
    public partial class Join : Form
    {
        //아이디 중복검사 여부 체크 변수
        bool id_check = false;

        //사용자의 정보를 저장하는 딕셔너리 
        //키 : 아이디, 값 : MemberInfo 클래스
        Dictionary<string, MemberInfo> info_dic = new Dictionary<string, MemberInfo>();

        public Join()
        {
            InitializeComponent();
        }

        private void join_Load(object sender, EventArgs e)
        {
            string[] num_data = { "010", "011", "016", "019" }; //전화번호 앞자리
            string[] email_data = { "naver.com", "gmail.com", "daum.com", "직접 입력" }; //이메일 뒷자리
            string[] year_data = { "1980", "1981", "1982", "1983", "1984", "1985",
                "1986", "1987", "1988", "1989", "1990", "1991", "1992", "1993", "1994", "1995",  "1996", "1997",
             "1998", "1999", "2000", "2001", "2002", "2003", "2004", "2004", "2005", "2006", "2007", "2008", "2009"}; //년
            string[] month_data = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" }; //월
            string[] date_data = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12",
            "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23",
            "24", "25", "26", "27", "28", "29", "30", "31"}; //일

            //콤보박스에 데이터 초기화 
            num1.Items.AddRange(num_data);
            email3.Items.AddRange(email_data);
            year.Items.AddRange(year_data);
            month.Items.AddRange(month_data);
            day.Items.AddRange(date_data);
        }

        //회원가입 버튼
        private void button1_Click(object sender, EventArgs e)
        {
            //이름 : 2~5자이내
            if (this.name.Text.Length < 2 || this.name.TextLength > 10)
            {
                MessageBox.Show("이름은 2~10자 이내 이여야 합니다.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.name.Focus();
                return;
            }

            //비밀번호
            if (this.pw.TextLength < 3 || this.pw.TextLength > 12)
            {
                MessageBox.Show("비밀번호는 3~12자 이내로 입력해주세요.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.pw.Focus();
                return;

            }

            if (this.pw.Text != this.chk_pw.Text)
            {
                MessageBox.Show("비밀번호가 일치하지 않습니다.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.pw.Focus();
                return;
            }

            string birth = year.Text + month.Text + day.Text;
            string email = email1.Text + "@" + email2.Text;
            string num = num1.Text + num2.Text + num3.Text;

            if(id_check == false)
            {
                MessageBox.Show("아이디 중복 검사를 해주세요.");
                this.button3.Focus();
                return;
            }

            else {
                info_dic.Add(id.Text, new MemberInfo(id.Text, name.Text, pw.Text, birth, email, num));

                //파일에 사용자 정보 쓰기
                FileStream fs = new FileStream("people.txt", FileMode.Append, FileAccess.Write);
                //FileMode 중 append : 이어쓰기, 파일이 없으면 파일 생성
                StreamWriter sw = new StreamWriter(fs, System.Text.Encoding.UTF8);              

                sw.WriteLine(id.Text);
                sw.WriteLine(pw.Text + " / "+ name.Text + " / " + birth + " / " + email + " / " + num);

                sw.Close();
                fs.Close();

                //파일에 아이디 비밀번호 정보 쓰기
                FileStream fs_idpw = new FileStream("User.txt", FileMode.Append, FileAccess.Write);
                //FileMode 중 append : 이어쓰기, 파일이 없으면 파일 생성
                StreamWriter sw_idpw = new StreamWriter(fs_idpw, System.Text.Encoding.UTF8);

                sw_idpw.WriteLine(id.Text + "!" + pw.Text);

                sw_idpw.Close();
                fs_idpw.Close();

                //파일에 아이디 비밀번호 정보 쓰기
                FileStream fs_info = new FileStream("User_info.txt", FileMode.Append, FileAccess.Write);
                //FileMode 중 append : 이어쓰기, 파일이 없으면 파일 생성
                StreamWriter sw_info = new StreamWriter(fs_info, System.Text.Encoding.UTF8);

                sw_info.WriteLine(name.Text + "/" + num + "/" + id.Text);

                sw_info.Close();
                fs_info.Close();

                MessageBox.Show("회원가입이 완료 되었습니다.");
            }
            this.Close();
        }

        //취소 버튼
        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("취소 하시겠습니까?");
            this.Close();
        }

        private bool Check_ID()
        {
            StreamReader sr = new StreamReader("people.txt", Encoding.Default);
            List<string> id_list = new List<string>();

            while (sr.EndOfStream == false) // 파일이 끝날 때까지 반복
            {
                string s = sr.ReadLine();
                string[] str = s.Split('\n');
                id_list.Add(str[0]);
            }

            foreach (string s in id_list) {
                if(id.Text == s)
                {
                    return true;
                }
            }
            return false; 
        }

        //중복검사 버튼
        private void button3_Click(object sender, EventArgs e)
        {
            //텍스트 박스에 입력을 안하고 중복검사 버튼을 클릭하였을 경우
            if (String.IsNullOrWhiteSpace(id.Text))
            {
                MessageBox.Show("아이디를 입력해 주세요.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            else
            {
                if (Check_ID()) //이미 가입된 아이디 이면
                {
                    MessageBox.Show("이미 존재하는 아이디 입니다.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                else
                {
                    MessageBox.Show("사용가능한 아이디 입니다.");
                }

                id_check = true;
            }
        }

        //년
        private void year_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        //월
        private void month_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        //일
        private void day_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        //이메일
        private void email3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (email3.Text == "직접 입력")
            {
                email2.Text = "";
            }
            else
            {
                email2.Text = email3.SelectedItem.ToString();
            }
        }
    }
}