﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TermProject
{
    public partial class Reserve : Form
    {
        private Form1 main = null;   

        //잔여 좌석 저장
        public List<string> seat_info = new List<string>();

        string dir_path = @"../movie"; //상대경로로 파일 디렉토리 경로 지정

        public Reserve(Form1 main)
        {
            InitializeComponent();
            this.main = main;
            user_id.Text = main.Login.Text + "!";

            try
            {
                listBox1.Items.Clear();
                string dir = dir_path;
                //디렉토리가 존재하면
                if (System.IO.Directory.Exists(dir))
                {                   
                    //DirectoryInfo 클래스를 생성
                    System.IO.DirectoryInfo moive_name = new System.IO.DirectoryInfo(dir);
                    //foreach 구문을 이용하여 폴더 내부에 있는 폴더 정로를 가져옴
                    foreach (var item in moive_name.GetDirectories())
                    {
                        listBox1.Items.Add(item.Name); //리스트 박스에 영화 이름 출력
                    }
                }
            }
            catch
            {
                MessageBox.Show("폴더 오류!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Reserve_Load(object sender, EventArgs e)
        {

        }

        //영화
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            string img_path = listBox1.SelectedItem.ToString();
            pictureBox1.Load(@"../img/" + img_path + ".png");
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;

            //영화 선택하면 극장 출력
            try
            {
                listBox2.Items.Clear();
                //영화 제목 -> 극장
                string dir = dir_path + "/" + listBox1.SelectedItem.ToString();
                //극장 폴더 디렉토리가 존재하면
                if (System.IO.Directory.Exists(dir))
                {
                    //극장 폴더 읽기 
                    System.IO.DirectoryInfo movie_area = new System.IO.DirectoryInfo(dir);
                    foreach (var item in movie_area.GetDirectories())
                    {
                        listBox2.Items.Add(item.Name);
                    }
                }
            }
            catch
            { }

            title.Text = listBox1.SelectedItem.ToString();
        }

        //극장
        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            //극장 선택하면 날짜 출력
            try
            {
                listBox3.Items.Clear();
                //영화 제목 -> 극장 -> 날짜
                string dir = dir_path + "/" + listBox1.SelectedItem.ToString() + "/" + listBox2.SelectedItem.ToString();
                //날짜 폴더 디렉토리가 존재하면
                if (System.IO.Directory.Exists(dir))
                {
                    //날짜 폴더 읽기 
                    System.IO.DirectoryInfo movie_date = new System.IO.DirectoryInfo(dir);
                    foreach (var item in movie_date.GetDirectories())
                    {
                        listBox3.Items.Add(item.Name);
                    }
                }
            }
            catch
            { }

            area.Text = listBox2.SelectedItem.ToString();
        }

        //날짜
        private void listBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

            //날짜 선택하면 시간 출력
            try
            {
                listBox4.Items.Clear();
                
                //영화 제목 -> 극장 -> 날짜 -> 시간.txt
                string dir = dir_path + "/" + listBox1.SelectedItem.ToString() + "/" + listBox2.SelectedItem.ToString() + "/" + listBox3.SelectedItem.ToString();
                List<string> path = new List<string>();
                

                //시간 폴더 디렉토리가 존재하면
                if (System.IO.Directory.Exists(dir)) 
                {
                    //시간 파일 읽기
                    System.IO.DirectoryInfo movie_time = new System.IO.DirectoryInfo(dir);
                    //시간 폴더 내부에 있는 파일 정보를 가져옴 
                    int check = 0;
                    foreach (var item in movie_time.GetFiles())
                    {
                        string time = item.Name;
                        string time_file; //텍스트 파일 주소
                        int count_tmp = 0;
                        int count = 0;
                        //시간.txt 읽기
                        time_file = dir + "/" + time;

                        //MessageBox.Show(time_file);
                        
                        //잔여 좌석을 확인하기 위한 파일 읽기
                        StreamReader sr = new StreamReader(time_file, Encoding.Default);
                        while (sr.EndOfStream == false) // 파일이 끝날 때까지 반복
                        {                           
                            string s = sr.ReadLine();
                            string[] str = s.Split('/'); //'/'기준으로 나눈다 
                            //한 줄씩 검사
                            foreach(string check_seat in str)
                            {
                                if(check_seat.Equals("1")) //1이 있으면 
                                {
                                    count++; //자리 증가
                                    count_tmp = count; //count값 count_tmp에 저장 //count_tmp는 한줄을 읽을 때 마다 초기화 된다. -> check변수로 해결
                                }
                                //MessageBox.Show(count + "<- count : seat ->" + check_seat);
                            }
                            check += count_tmp; //한줄 읽을 때 마다 count_tmp 누적
                            count = 0; //count 초기화
                        }                       
                        
                        string seat_info = (30 - check).ToString(); 
                        string tmp = time.Substring(0, 5);
                        string tt = tmp.Replace('.', ':');

                        listBox4.Items.Add(tt + " (" + seat_info + "/30)");
                        check = 0; //다른 파일로 넘어가므로 초기화
                    }
                }
            }
            catch
            { }

            date.Text = listBox3.SelectedItem.ToString();
        }

        private void listBox4_SelectedIndexChanged(object sender, EventArgs e)
        {   
            try
            {
                time.Text = listBox4.SelectedItem.ToString();
            }
            catch
            {

            }
        }

        //좌석 선택 버튼 클릭
        private void button1_Click(object sender, EventArgs e)
        {
            Seat_Selection s = new Seat_Selection(this);
            s.ShowDialog();

            this.Close();
        }
    }
}
