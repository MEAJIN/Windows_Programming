﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TermProject
{
    public partial class Search : Form
    {
        string num, name;
        string search_num, search_name, search_id;

        private void Search_Load(object sender, EventArgs e)
        {
            //Reserve.txt 읽기
            StreamReader sr = new StreamReader("User_info.txt", Encoding.Default);

            //이름 / 전화번호 / 아이디
            while (sr.EndOfStream == false) // 파일이 끝날 때까지 반복
            {
                string line = sr.ReadLine();
                string[] str = line.Split('/'); //!기준으로 나눈다 
                search_name = str[0];
                search_num = str[1];
                search_id = str[2];
            }
            Console.WriteLine(search_name + search_num);
            sr.Close();            
        }

        public Search()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            name = textBox1.Text;
            num = textBox2.Text;
            
            if (name == search_name && num == search_num)
            {
                label3.Text = name + "님의 아이디는 " + search_id + " 입니다.";
            }
            else if (name == search_name && num != search_num)
            {
                label3.Text = "전화번호가 일치하지 않습니다.";
            }
            else if (name != search_name)
            {
                label3.Text = "없는 사용자 입니다.";
            }
        }
    }
}
