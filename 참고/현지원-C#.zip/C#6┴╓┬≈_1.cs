﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    class Student
    {
        private string Name; //이름
        private string S_num; //학번
        private int Grade; //학년
        private int Mid_Score = 0; //중간 점수
        private int Final_Score = 0; //기말 점수
        private double sum = 0.0; //총점
        private double avg = 0.0; //평균

        //이름, 학번, 학년을 입력받은 값으로 초기화 해주는 생성자
        public Student(string Name, string S_num, int Grade)
        {
            this.Name = Name;
            this.S_num = S_num;
            this.Grade = Grade;
        }

        //합계를 구하는 메소드
        public double Sum()
        {
            sum = Mid_Score + Final_Score;
            return sum;
        }

        //평균을 구하는 메소드
        public double Avarage()
        {
            avg = (sum / 2.0);
            return avg;
        }

        //중간 점수를 할당하는 메소드
        public void set_Mid(int Mid_Score)
        {
            this.Mid_Score = Mid_Score;
        }

        //기말 점수를 할당하는 메소드
        public void set_Final(int Final_Score)
        {
            this.Final_Score = Final_Score;
        }

        static void Main(string[] args)
        {
            string student, score;
            string[] info;
            string[] score_info;
            string name, s_num;
            int grade, mid_score, final_score;
            Console.WriteLine("이름, 학번, 학년 입력");
            student = Console.ReadLine();

            //''를 기준으로 문자열을 나눈 후 할당
            info = student.Split(' ');
            name = info[0];
            s_num = info[1];
            grade = int.Parse(info[2]); //문자열 배열이기 때문에 정수형으로 변환 하여 할당

            //객체 생성과 함께 생성자 호출 
            Student s = new Student(name, s_num, grade);

            Console.WriteLine("중간, 기말 점수 입력");
            score = Console.ReadLine();

            //' '를 기준으로 문자열을 나눈 후 할당
            score_info = score.Split(' ');
            mid_score = int.Parse(score_info[0]);
            final_score = int.Parse(score_info[1]);

            s.set_Mid(mid_score);
            s.set_Final(final_score);

            Console.WriteLine("이름 : " + s.Name + ", 학번 : " + s.S_num + ", 학년 : " + s.Grade);
            Console.WriteLine("총점 : " + s.Sum() + ", 평균 : {0:f2}", s.Avarage());
        }
    }
}
