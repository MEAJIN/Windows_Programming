﻿//20174069 현지원
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    class Parking
    {
        //필드 선언
        private int car_num;
        private string car_model;
        private int in_time, charge;

        //기본 생성자
        public Parking()
        {
            car_num = 0;
            car_model = "\n";
            in_time = 0;
        }

        //사용자로부터 차량번호, 모델명, 들어온 시간을 입력 받아 할당하는 car_in함수
        public void car_in(int car_num, string car_model, int in_time)
        {
            this.car_num = car_num;
            this.car_model = car_model;
            this.in_time = in_time;
        }

        //요금을 계산하는 car_out 함수
        public void car_out(int car_num, int out_time)
        {
            charge = (out_time - in_time) * 3;
            Console.WriteLine("car has been out. parking fee = " + charge + "$");
        }

        static void Main(string[] args)
        {
            int input;
            string car_info;
            string[] tmp_info;
            string model; 
            int in_time = 0, out_time = 0, num = 0, search_num = 0, index = 0;

            //객체 배열 생성
            Parking[] car = new Parking[10];

            do
            {
                Console.Write("enter number(0 : car in, 1 : car out) : ");
                input = int.Parse(Console.ReadLine());

                if(input == 0)
                {
                    Console.Write("enter car information(5885,k5,1) : ");
                    car_info = Console.ReadLine();

                    //,를 기준으로 문자열 나누기
                    tmp_info = car_info.Split(',');
                    //각 타입에 맞게 형 변환하여 저장
                    num = int.Parse(tmp_info[0]);
                    model = tmp_info[1];
                    in_time = int.Parse(tmp_info[2]);

                    //객체 생성
                    car[index] = new Parking();
                    //car_in 함수 호출
                    car[index].car_in(num, model, in_time);
                    if (index > 10)
                    {
                        Console.WriteLine("최대 10대 주차 가능");
                    }
                    index++;
                }

                else if(input == 1)
                {
                    Console.Write("enter car number : ");
                    search_num = int.Parse(Console.ReadLine());

                    Console.Write("enter exit time : ");
                    out_time = int.Parse(Console.ReadLine());

                    //차량 객체 탐색
                    foreach (Parking c in car)
                    {
                        if(c == null)
                        {
                            break;
                        }
                        //입력한 번호와 차량 번호가 같으면
                        if(c.car_num == search_num)
                        {
                            //car_out 함수 호출
                            c.car_out(search_num, out_time);
                        }
                    }
                }
            } while (input == 0 || input == 1); //사용자가 0,1 이외의 값을 입력하면 종료

            Console.WriteLine("exit");
        }
    }
}
