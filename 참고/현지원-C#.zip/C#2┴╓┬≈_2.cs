﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 0, rank = 1;
            string mem_info;
            double total = 0.0, avr = 0.0, kor, eng, math;

            //학생 수를 입력받음
            Console.Write("학생 수를 입력하세요 : ");
            num = int.Parse(Console.ReadLine()); //문자열로 입력 받기 때문에 정수형으로 변환

            //2차원 object형 배열 선언
            object[,] info = new object[num, 7];

            //성적을 입력받고 배열에 저장
            Console.WriteLine("\n[ 성명, 국어점수, 영어점수, 수학점수 ] 순으로 입력하세요. \n");

            for (int i = 0; i < num; i++)
            {
                mem_info = Console.ReadLine(); //학생 수 만큼 한줄 씩 입력 받아 mem_info에 저장
                string[] tmp = mem_info.Split(',');

                for (int j = 0; j < tmp.Length; j++)
                {
                    info[i, j] = tmp[j]; //,를 기준으로 나누어 info 배열에 저장, Boxing 발생
                }

                //점수 : string -> double
                kor = Convert.ToDouble(tmp[1]);
                eng = Convert.ToDouble(tmp[2]);
                math = Convert.ToDouble(tmp[3]);

                //학생의 이름, 국어, 영어, 수학, 총점, 평균, 석차 계산
                total = kor + eng + math;
                avr = total / 3;

                info[i, 4] = total;
                info[i, 5] = avr;
                info[i, 6] = rank;
            }

            //석차 
            for (int i = 0; i < num - 1; i++)  {
                double N_avr = (double)info[i,5]; //언박싱

                for (int j = i+1; j < num; j++) {
                    double tmp_avr =(double)info[j, 5];

                    if (tmp_avr < N_avr) {
                        info[j, 6] = (int)info[j, 6] + 1;
                    }

                    else if(tmp_avr > N_avr){
                        info[i, 6] = (int)info[i, 6] + 1;
                    }
                }
            }

            //학생의 이름, 국어, 영어, 수학, 총점, 평균, 석차 출력
            Console.WriteLine("\n==================== 결 과 ====================\n");
            for (int i = 0; i < num; i++) {
                string average = string.Format("{0:f1}", info[i, 5]); //소수점 첫째자리 까지만 출력 
                Console.Write("이름 : " + info[i, 0] + ", 국어 : " + info[i,1] + ", 영어 : " + info[i, 2] + ", 수학 : " + info[i, 3] + ", 총점 : " + info[i, 4] + ", 평균 : " + average + ", 석차 : " + info[i, 6]);
                Console.WriteLine();
            }

            Console.ReadLine(); //콘솔 창 유지를 위해 추가
        }
    }
}