﻿//20174069 현지원
using System;

class Fraction
{
    public int numberator; //분자
    public int denominator; //분모

    //한 개의 정수를 받아 초기화 하는 생성자
    public Fraction(int a)  {
        numberator = a;
        denominator = 1;
    }

    //두 개의 정수를 받아 초기화 하는 생성자
    public Fraction(int a, int b)  { 
        numberator = a;
        denominator = b;
    }

    //하나의 분수를 분자/분모 형태로 변환하는 ToString() 메소드
    public override string ToString() { 
        return "(" + numberator + " / " + denominator + ")";
    }

    //최대공약수를 구하는 메소드
    public int GratestCommondDivisor(int numberator, int denominator ) { 
        while(denominator != 0) {
            int tmp = numberator % denominator;
            numberator = denominator;
            denominator = tmp;
        }
        return numberator;
    }

    //기약분수 메소드
    public void irreducibleFraction (Fraction f, int gcd)  {
        //최대공약수로 분자와 분모를 나누어 기약분수로 표현
        Console.WriteLine("기약분수로 표현한 분수식 : " + (f.numberator / gcd) + "/" + (f.denominator / gcd));
    }

    //사칙연산 연산자 중복 정의
    public static Fraction operator+ (Fraction f1, Fraction f2) {
        int n = (f1.numberator * f2.denominator) + (f2.numberator * f1.denominator);
        int d = f1.denominator * f2.denominator;
        return new Fraction(n, d);
    }

    public static Fraction operator -(Fraction f1, Fraction f2)
    {
        int n = (f1.numberator * f2.denominator) - (f2.numberator * f1.denominator);
        int d = f1.denominator * f2.denominator;
        return new Fraction(n, d);
    }

    public static Fraction operator *(Fraction f1, Fraction f2)
    {
        int n = f1.numberator * f2.numberator;
        int d = f1.denominator * f2.denominator;
        return new Fraction(n, d);
    }

    public static Fraction operator /(Fraction f1, Fraction f2)
    {
        int n = f1.numberator * f2.denominator;
        int d = f1.denominator * f2.numberator;
        return new Fraction(n, d);
    }

    public void AddFraction(Fraction f1, Fraction f2)
    {
        Console.WriteLine("f1 + f2 = " + (f1 + f2));
    }

    public void SubFraction(Fraction f1, Fraction f2)
    {
        Console.WriteLine("f1 - f2 = " + (f1 - f2));
    }

    public void MulFraction(Fraction f1, Fraction f2)
    {
        Console.WriteLine("f1 * f2 = " + (f1 * f2));
    }

    public void DivFraction(Fraction f1, Fraction f2)
    {
        Console.WriteLine("f1 ÷ f2 = " + (f1 / f2));
    }
}

class Program {
    //선언된 클래스 Fraction의 메소드를 테스티하기 위해 테스트 클래스 선언
    static void Main(string[] args)
    {
        Fraction f1, f2; //분수를 나타낼 클래스 f1, f2 선언
        
        //생성자를 이용하여 분수식 f1을 5/6로 초기화
        f1 = new Fraction(5, 6);
        //생성자를 이용하여 분수식 f2를 2/4로 초기화 
        f2 = new Fraction(2, 4);

        //f1, f2를 분수식의 형태로 출력
        Console.WriteLine("분수식 f1 : " + f1.ToString());
        Console.WriteLine("분수식 f2 : " + f2.ToString());

        int gcd1 = f1.GratestCommondDivisor(f1.numberator, f1.denominator);
        int gcd2 = f1.GratestCommondDivisor(f2.numberator, f2.denominator);

        //분수식 f1, f2의 최대공약수를 출력
        Console.WriteLine("분수식 f1의 최대공약수 : " +gcd1);
        Console.WriteLine("분수식 f2의 최대공약수 : " + gcd2);

        //분수식 f1, f2의 기약분수를 출력
        f1.irreducibleFraction(f1, gcd1);
        f2.irreducibleFraction(f2, gcd2);

        //분수식 f1, f2의 사칙연산 결과를 출력
        f2.AddFraction(f1, f2);
        f2.SubFraction(f1, f2);
        f2.MulFraction(f1, f2);
        f2.DivFraction(f1, f2);
    }
}

