﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form2 : Form
    {

        RadioButton[] optionButton = new RadioButton[7];

        Button selectedButton;
        Form1 form1;

        int i, j;

        string option = null;
        public Form2(Button button, Form1 form1)
        {
            selectedButton = button;

            i = (selectedButton.Location.X - form1.x) / form1.width;
            j = (selectedButton.Location.Y - form1.y) / form1.height;

            this.form1 = form1;
            InitializeComponent();
            
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            checkState();

            if (selectedButton.Text == "" && form1.state == "EMPTY")
            {
                radioButton2.Enabled = true;
                radioButton3.Enabled = true;
                radioButton4.Enabled = true;
                radioButton5.Enabled = true;
                radioButton6.Enabled = true;
                radioButton7.Enabled = true;
            }
            if (selectedButton.Text == "")
                button2.Enabled = true;
            //else if(selectedButton.Text == "" && ())
        }

        private void rbOption(object sender, EventArgs e)
        {
            RadioButton rbtn = sender as RadioButton;

            if (rbtn.Checked == false)
                option = null;

            switch (rbtn.Text)
            {
                case "길": option = "L";break;
                case "주택": option = "H"; break;
                case "맨션": option = "M"; break;
                case "아파트": option = "A"; break;
                case "발전소": option = "E"; break;
                case "급수원": option = "W"; break;
                case "오수처리장": option = "S"; break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (option == null)
                MessageBox.Show("설치할 건물을 선택해주세요");
            form1.build(option, selectedButton);
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (selectedButton.Text == "")
                MessageBox.Show("건물이 설치되어 있지 않습니다.");
            form1.destroy(selectedButton.Text, selectedButton);
            this.Close();
        }

        private void checkState()
        {
            if (form1.state != "EMPTY")
            {
                if (i - 1 >= 0 && form1.block[i - 1, j].Text == "L")
                    return;
                else if (i + 1 < form1.block.GetLength(1) && form1.block[i + 1, j].Text == "L")
                    return;
                else if (j - 1 >= 0 && form1.block[i, j - 1].Text == "L")
                    return;
                else if (j + 1 < form1.block.GetLength(0) && form1.block[i, j + 1].Text == "L")
                    return;
                MessageBox.Show("건물을 설치할 수 없는 위치입니다.");
                this.Close();
            }
        }
    }
}
