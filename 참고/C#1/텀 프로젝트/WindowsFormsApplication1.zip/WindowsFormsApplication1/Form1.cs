﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Timers;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public static int row = 50;
        public static int col = 50;
        public Button[,] block = new Button[row, col];

        public int x = 10;
        public int y = 100;
        public int width = 20;
        public int height = 20;

        int countBuilding = 0;
        int countLoad = 0;
        int countBlock = row * col;
        int countApart = 0;
        int countTime = 0;

        int allElec = 0;
        int allWater = 0;
        int allSewage = 0;

        int useElec = 0;
        int useWater = 0;
        int useSewage = 0;

        Dictionary<string, int> Elec = new Dictionary<string, int>()
        {
            {"H", 10 }, {"M", 40 }, {"A", 80 }, {"E",200 }, {"W", 0 }, {"S", 0 }
        };
        Dictionary<string, int> Water = new Dictionary<string, int>()
        {
            {"H", 10 }, {"M", 40 }, {"A", 80 }, {"E",0 }, {"W", 200 }, {"S", 0 }
        };
        Dictionary<string, int> Sewage = new Dictionary<string, int>()
        {
            {"H", 10 }, {"M", 40 }, {"A", 80 }, {"E",0 }, {"W", 0 }, {"S", 200 }
        };

        public string state = "EMPTY";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    block[i, j] = new Button();
                    block[i, j].Size = new System.Drawing.Size(width, height);
                    block[i, j].Location = new Point(x +(width*i), y+(height*j));
                    block[i, j].Text = "";
                    block[i, j].Click += new System.EventHandler(onClick);
                    this.Controls.Add(block[i, j]);
                }
            }

            setInfo();

            this.AutoSize = true;
            timer1.Start();
        }
              

        public void onClick(object sender, EventArgs e)
        {
            Button but = (Button)sender;

            Form frm2 = new Form2(but, this);
            frm2.Owner = this;
            frm2.ShowDialog();
        }

        public void setInfo()
        {
            label2.Text = countBuilding.ToString();
            label4.Text = countLoad.ToString();
            label6.Text = countBlock.ToString();
            label8.Text = useElec.ToString();
            label10.Text = allElec.ToString();
            label12.Text = useWater.ToString();
            label14.Text = allWater.ToString();
            label16.Text = useSewage.ToString();
            label18.Text = allSewage.ToString();
        }

        public void build(string Text, Button btn)
        {

            switch (Text)
            {
                case "E":
                case "W":
                case "S":
                    allElec += Elec[Text]; useElec += Elec[Text];
                    allWater += Water[Text]; useWater += Water[Text];
                    allSewage += Sewage[Text]; useSewage += Sewage[Text];
                    break;
                case "A":
                case "M":
                case "H":
                    if (useElec < Elec[Text] || useWater < Water[Text] || useSewage < Sewage[Text])
                    {
                        MessageBox.Show("자원이 부족합니다.");
                        return;
                    }
                    useElec -= Elec[Text];
                    useWater -= Water[Text];
                    useSewage -= Sewage[Text];
                    break;
            }
            if(Text =="A")
            {
                countApart += 1;
                btn.Tag = countTime;
            }

            countBlock -= 1;

            btn.Text = Text;

            if (Text == "L")
                countLoad += 1;
            else
                countBuilding += 1;

            if (countBlock != row * col)
                state = "NE";
            else
                state = "EMPTY";

            setInfo();

        }

        public void destroy(string Text, Button btn)
        {
            btn.Text = "";
            //btn.BackColor = Color.Bisque;

            if (Text == "L")
                countLoad -= 1;
            else
                countBuilding -= 1;

            switch (Text)
            {
                case "E":
                case "W":
                case "S":
                    allElec -= Elec[Text]; useElec -= Elec[Text];
                    allWater -= Water[Text]; useWater -= Water[Text];
                    allSewage -= Sewage[Text]; useSewage -= Sewage[Text];
                    break;
                case "A":
                    useElec += (Elec[Text] + (((countTime - Int32.Parse(btn.Tag.ToString()))/2) * 2));
                    useWater += (Elec[Text] + (((countTime - Int32.Parse(btn.Tag.ToString())) / 2) * 2));
                    useSewage += (Elec[Text] + (((countTime - Int32.Parse(btn.Tag.ToString())) / 2) * 2));
                    countApart -= 1;
                    break;
                case "M":
                case "H":
                    useElec += Elec[Text];
                    useWater += Water[Text];
                    useSewage += Sewage[Text];
                    break;
            }
            countBlock += 1;

            if (countBlock != row * col)
                state = "NE";
            else
                state = "EMPTY";

            setInfo();
        }

        public void Time(object sender, EventArgs e)
        {
            
            countTime += 1;
            if(countTime % 2 == 0 && countApart != 0)
            {
                useElec -= (countApart * 2);
                useWater -= (countApart * 2);
                useSewage -= (countApart * 2);
                setInfo();
            }

            if(useElec <0 || useWater < 0||useSewage < 0)
            {
                MessageBox.Show("자원이 부족합니다.");
            }
            
            label19.Text = countTime.ToString();

        }
    }
}
